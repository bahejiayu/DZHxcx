// pages/de_time/de_time.js
var app = getApp();
var http = app.globalData.http;
Page({

  /**
   * 页面的初始数据
   */
  data: {
      date_list:[],
    index_:0,
    time_list:[],

  },
  cur_all:function(){
    var that=this;
    var list_ = that.data.date_list;    
    for (var i = 0; i < list_[that.data.index_].hour.length;i++){
      list_[that.data.index_].hour[i].status = 0;
      };

      this.setData({
        date_list: list_
      })
  },
  tog_deta:function(e){
     var that=this;
      this.setData({
        index_:e.target.dataset.index,
        time_list: that.data.date_list[e.target.dataset.index].hour
      });
  },
  tog_time:function(e){
      var that=this;
    var list_ = that.data.date_list;
    
    if (list_[that.data.index_].hour[e.target.dataset.index].status==1){
      list_[that.data.index_].hour[e.target.dataset.index].status=0
    }else{
      list_[that.data.index_].hour[e.target.dataset.index].status=1
    }
    that.setData({
      date_list: list_
    })


  },
  btn:function(){
    wx.showLoading({
      title: '修改中',
    })
    var that=this;
    wx.request({
      url: http +'/api/member/service_time_edit', //仅为示例，并非真实的接口地址
      data: {
        day_time: JSON.stringify(that.data.date_list),
        access_token:wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
            wx.showToast({
              title: '修改成功',
            })
        console.log(res.data)
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      wx.showLoading({
        title: '加载中',
      })
    var that=this;
    // 获取日期
    wx.request({
      url: http +'/api/member/service_time', //仅为示例，并非真实的接口地址
      data: {
        access_token:wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
        console.log(res.data);
            if(res.data.code==1){
                that.setData({
                  date_list:res.data.data,
                  time_list: res.data.data[0].hour
                })
            }   
      }
    })



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})