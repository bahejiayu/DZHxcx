// pages/follow/follow.js


var app = getApp();
var http = app.globalData.http;
var cur_page=1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    video_list:[],
    url:http,
    is_syr: false
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    cur_page=1;
      var that=this;
      wx.showLoading({
        title: '加载中',
      })






    // 判断是不是手艺人
    wx.request({
      url: http + '/api/member/add_content_tip', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        access_token: wx.getStorageSync('token')
      },
      success(res) {
        console.log(res.data);
        if (res.data.data[0].flag == 1) {
          that.setData({
            is_syr: true
          })
        } else {
          that.setData({
            is_syr: false
          })
        }
      }
    });


    wx.request({
      url: http +'/api/index/index', //仅为示例，并非真实的接口地址
      data: {
        page: 1,
        limit:4,
        follow:1,
        access_token:wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
        console.log(res.data)
        if (res.data.code==1){
          that.setData({
            video_list: res.data.data[0].list
          });
        }
      }
    });
  
  },
  up_video: function () {
    var that = this;
    if (!wx.getStorageSync('token')) {
      wx.showToast({
        title: '请前往个人中心登陆',
        icon: 'none'
      });
      return false;
    }

    if (that.data.is_syr) {
      wx.chooseVideo({
        sourceType: ['album', 'camera'],
        maxDuration: 60,
        compressed: false,
        camera: 'back',
        success(res) {
          wx.showLoading({
            title: '上传中,请耐心等待',
          })
          console.log(res);
          if ((res.size / 1024 / 1024)>20){
            wx.hideLoading();
                wx.showToast({
                  title: '视频大小不能超过20M',
                  icon:'none'
                });
                return false;
         }
          wx.navigateTo({
            url: '../chk_video/chk_video?link=' + res.tempFilePath,
          });
          wx.hideLoading();
          
        }
      })
    } else {
      that.setData({
        show_t: true
      })
    }
  },
  sure_: function () {
    this.setData({
      show_t: false
    });
    wx.navigateTo({
      url: '../apply_craft/apply_craft',
    });
  },
  go_list: function (e) {
    console.log(e.target.dataset.index);
    var that = this;
    wx.setStorageSync('index_list', that.data.video_list);
    wx.navigateTo({
        url: '../video/video?index=' + e.target.dataset.index + '&page=' + e.target.dataset.page,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that=this;
    if (wx.getStorageSync('page') == '关注') {
      wx.removeStorageSync('page');
      that.setData({
        video_list: wx.getStorageSync('index_list')
      });
    };
    wx.request({
      url: http + '/api/login/token_ex', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token')

      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data);
        if (res.data.code != 1 && wx.getStorageSync('token')) {
          wx.clearStorageSync();
          wx.showToast({
            title: '登陆超时,请重新登陆',
            icon: 'none'
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {




  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

    var that = this;
    cur_page++;
    wx.showLoading({
      title: '加载更多',
    })
    wx.request({
      url: http + '/api/index/index', //仅为示例，并非真实的接口地址
      data: {
        page: cur_page,
        limit: 4,
        follow: 1,
        access_token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
        console.log(res.data)
        if (res.data.code == 1) {
          that.setData({
            video_list: that.data.video_list.concat(res.data.data[0].list)
          });
        }
      }
    });



  
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})