// pages/follow/follow.js


var app = getApp();
var http = app.globalData.http;
var cur_page = 1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    video_list: [],
    url: http,
    w: '0',
    video_list: []
  },
  go_list: function (e) {
    console.log(e.target.dataset);
    var that = this;
    wx.setStorageSync('index_list', that.data.video_list);
    // wx.navigateTo({
    //   url: '../video/video?index=' + e.target.dataset.index + '&page=' + e.target.dataset.page,
    // })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getSystemInfo({
      success: function (e) {
        that.setData({
          w: e.screenWidth,
        })
        console.log(e)
      }
    })
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: http + '/api/index/index', //仅为示例，并非真实的接口地址
      data: {
        page: 1,
        limit: 4,
        like: 1,
        access_token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
        if (res.data.code == 1) {
          for (var i = 0; i < res.data.data[0].list.length + 1; i++) {
            if (((i + 1) % 3) == 0) {
              var index_ = (i - 1);
              // console.log(res.data.data[0].list)
              console.log(res.data.data[0].list[index_])
              res.data.data[0].list[index_].b = true;
            }
          }
          console.log(res.data)

          that.setData({
            video_list: res.data.data[0].list
          });
        }
      }
    });
  },
  go_list: function (e) {
    console.log(e.target.dataset.index);
    var that = this;
    wx.setStorageSync('index_list', that.data.video_list);
    wx.navigateTo({
      url: '../video/video?index=' + e.target.dataset.index + '&page=' + e.target.dataset.page,
  
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (wx.getStorageSync('page') == '喜欢') {
      wx.removeStorageSync('page');
      that.setData({
        video_list: wx.getStorageSync('index_list')
      });
    };
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {




  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

    var that = this;
    cur_page++;
    wx.showLoading({
      title: '加载更多',
    })
    wx.request({
      url: http + '/api/index/index', //仅为示例，并非真实的接口地址
      data: {
        page: cur_page,
        limit: 4,
        like: 1,
        access_token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
        console.log(res.data)
        if (res.data.code == 1) {
          that.setData({
            video_list: that.data.video_list.concat(res.data.data[0].list)
          });
        }
      }
    });




  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})