// pages/join_shop/join_shop.js

var app = getApp();
var http = app.globalData.http;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    shop_id: ''
  },
  get_id: function(e) {
    this.setData({
      shop_id: e.detail.value
    })
  },
  sub_mit: function() {
    var that = this;
    if (that.data.shop_id == '') {
      wx.showToast({
        title: '请输入店铺ID',
        icon: 'none'
      });
      return false;
    };
    wx.showLoading({
      title: '申请中',
    })

    wx.request({
      url: http + '/api/shop/add_shop', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        shop_id: that.data.shop_id
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function(res) {
        console.log(res.data);
        wx.hideLoading();
        if (res.data.code == 1) {
          wx.showToast({
            title: '已申请，请等待反馈',
            icon:'none'
          })
        } else {
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }


      }
    })



  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})