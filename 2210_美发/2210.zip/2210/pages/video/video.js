// pages/my_like/my_like.js
var app = getApp();
var back_ = false;
var http = app.globalData.http;
var s_h = 0;
var e_h = 0;
var s_X = 0;
var e_X = 0;

var is_ps = false;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    h: '0',
    play_status: false,
    txt: "",
    left_: 0,
    hua: 0,
    curr_index: 0,
    is_ps: false,
    url: http,
    id_: '',
    list_: [],
    sp_id: '',
    st_: [
      false, false, false, false
    ],
    m_dh: false,
    page: '',
    fx_id: '',
    show_fx: false,
    uid: '',
    fx_id: '',
    show_ser_style: false
  },
  get_uid: function(e) {
    this.setData({
      post_uid: e.target.dataset.uid,
    })
  },
  show_fx: function(e) {
    var that = this;
    if (!wx.getStorageSync('token')) {
      that.setData({
        show_login: true
      });
      return false;
    }
    this.setData({
      show_fx: true,
      uid: e.target.dataset.uid
    });

   
    wx.request({
      url: http + '/api/member/share', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        share_uid: e.target.dataset.uid
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data);
        if (res.data.code == 1) {
          that.setData({
            fx_id: res.data.data[0].share_id
          })
        }
      }
    })


  },
  go_login:function(){
    this.setData({
      show_login: false
    });
      wx.reLaunch({
        url: '../my/my',
      });
  },
  go_ev: function(e) {
    wx.navigateTo({
      url: '../evaluate_list/evaluate_list?id=' + e.target.dataset.id,
    })
  },
  yy: function(e) {
    var that = this;
    if (!wx.getStorageSync('token')) {
        that.setData({
          show_login:true
        });
      return false;
    }

    this.setData({
      id_: e.target.dataset.id,
      sp_id: e.target.dataset.sp,
      show_ser_style: true
    });

  },
  other_ser: function() {
    var that = this;
    this.setData({
      show_ser_style: false
    });
    wx.navigateTo({
      url: '../he/he?uid=' + that.data.id_ + '&yy=1',
    })
  },
  cur_ser: function() {
    var that = this;
    this.setData({
      show_ser_style: false
    });

    wx.navigateTo({
      url: '../time_/time_?uid=' + that.data.id_,
    })
  },
  like_tog: function(e) {
    var that = this;
    if (!wx.getStorageSync('token')) {
      that.setData({
        show_login: true
      });
      return false;
    }


  
    var g_arr = that.data.list_;
    console.log(g_arr[e.target.dataset.index].info.is_like);
    if (g_arr[e.target.dataset.index].info.is_like == 0) {
      g_arr[e.target.dataset.index].info.is_like = 1;
      g_arr[e.target.dataset.index].info.like_counet++;

    } else {
      g_arr[e.target.dataset.index].info.is_like = 0;
      g_arr[e.target.dataset.index].info.like_counet--;
    };
    this.setData({
      list_: g_arr
    });
    wx.setStorageSync('index_list', that.data.list_);
    wx.request({
      url: http + '/api/member/like', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        to_cid: e.target.dataset.id
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data)
      }
    })
  },
  gz_btn: function(e) {
    var that = this;
    if (!wx.getStorageSync('token')) {
      that.setData({
        show_login: true
      });
      return false;
    }


    var that = this;
    var g_arr = that.data.list_;
    console.log(g_arr[e.target.dataset.index].info.is_like);
    if (g_arr[e.target.dataset.index].info.is_follow == 0) {
      g_arr[e.target.dataset.index].info.is_follow = 1;


    } else {
      g_arr[e.target.dataset.index].info.is_follow = 0;

    };
    this.setData({
      list_: g_arr
    });
    wx.setStorageSync('index_list', that.data.list_);
    wx.request({
      url: http + '/api/member/follow', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        to_uid: e.target.dataset.id
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data);
        if (res.data.code == 1) {
          wx.showToast({
            title: '关注成功',
            icon: 'none'
          });
        }
      }
    })
  },
  go_he: function(e) {
    if (back_ == true) {
      wx.navigateBack({
        delta: 1,
      })

    } else {
      wx.navigateTo({
        url: '../he/he?uid=' + e.target.dataset.uid,
      })
    }

  },
  hc: function() {
    wx.showLoading({
      title: '正在缓冲',
    })
  },
  jx_bf: function() {
    wx.hideLoading();
  },
  tog_status: function(e) {
    var that = this;


    var index_ = e.target.dataset.index;
    var arr = that.data.list_;
    console.log(arr[index_].is_zt);

    console.log(wx.createVideoContext("v" + index_))
    if (arr[index_].is_zt) {
      wx.createVideoContext("v" + index_).play();
      // wx.createVideoContext("v" + index_).requestFullScreen({
      //   direction:0
      // });

      arr[index_].is_zt = false;
      that.setData({
        list_: arr
      });
    } else {
      wx.createVideoContext("v" + index_).pause();

      arr[index_].is_zt = true;
      that.setData({
        list_: arr
      });


    };
    // that.setData({
    //   is_ps: !that.data.is_ps
    // })


  },
  start_: function(e) {
    this.setData({
      m_dh: true
    })
    s_h = e.touches[0].pageY;
    s_X = e.touches[0].pageX;


    // console.log(s_h)
  },
  end_: function (e) {
    var that = this;
    // that.setData({
    //   is_ps: false
    // });
    var arr_ = that.data.list_;
    var index_ = e.target.dataset.index;
    for (var i = 0; i < arr_.length; i++) {
      // wx.createVideoContext("v" + i).pause();
    };
    // wx.createVideoContext("v" + i).play();





    var arr = that.data.list_;
    e_h = e.changedTouches[0].pageY;
    // console.log(e_h - s_h)
    if (e_h - s_h < 0 && Math.abs(e_h - s_h) >= 40) {
      var z_ = that.data.hua - that.data.h;
      var big_length = (that.data.list_.length - 1) * that.data.h;
      console.log(big_length)
      if (Math.abs(that.data.hua) == big_length) {
        wx.showToast({
          title: '没有更多视频',
          icon: 'none'
        });
        return false;
      };


      // 下一个
      var c_i = that.data.curr_index;
      c_i++
      wx.createVideoContext("v" + (index_ + 1)).play();

      that.setData({
        hua: z_,
        curr_index: c_i
      });


    } else if (e_h - s_h > 0 && Math.abs(e_h - s_h) >= 40) {
      if (that.data.hua == 0) {
        wx.showToast({
          title: '下滑切换视频',
          icon: 'none'
        });
        return false;
      }
      // 上一个
      var z_ = that.data.hua + that.data.h
      var c_i = that.data.curr_index;
      c_i--;
      wx.createVideoContext("v" + (index_ - 1)).play();
      that.setData({
        hua: z_,
        curr_index: c_i
      });
    };
    that.setData({
      left_: 0
    });
  },
  // end_: function(e) {
  //   var that = this;
  //   e_X = e.changedTouches[0].pageX;
  //   e_h = e.changedTouches[0].pageY;

  //   if (s_X > e_X) {
  //     console.log(1)
  //     if (s_X - e_X ) {
  //       if (e_h > s_h) {
  //         if (e_h - s_h > 30) {
  //           console.log('嘻嘻嘻')

  //           return false;
  //         }
  //       };

  //       if (s_h > e_h) {
  //         if (s_h - e_h > 30) {
  //           console.log('嘻嘻嘻')

  //           return false;
  //         }
  //       }
  //       if (back_ == true) {
  //         wx.navigateBack({
  //           delta: 1,
  //         });
  //         return false;

  //       }

  //         wx.navigateTo({
  //           url: '../he/he?uid=' + e.target.dataset.uid,
  //         })

  //       return false;
  //     }
  //   }else{
  //     console.log(2)
  //   }



  //   var arr_ = that.data.list_;
  //   var index_ = e.target.dataset.index;
  //   var arr = that.data.list_;
  //   if ((e_h - s_h < 0 && Math.abs(e_h - s_h) >= 30)) {

  //     if (e_X > s_X) {
  //       if (e_X - s_X > 20) {
  //         console.log('嘻嘻嘻')

  //         return false;
  //       }
  //     }
  //     if (s_X > e_X) {
  //       if (s_X - e_X > 20) {
  //         return false;
  //       }
  //     }



  //     var z_ = that.data.hua - that.data.h;
  //     var big_length = (that.data.list_.length - 1) * that.data.h;
  //     console.log(big_length)
  //     if (Math.abs(that.data.hua) == big_length) {
  //       wx.showToast({
  //         title: '没有更多视频',
  //         icon: 'none'
  //       });
  //       return false;
  //     };
  //     // 下一个
  //     var c_i = that.data.curr_index;
  //     c_i++
  //     wx.createVideoContext("v" + (index_ + 1)).play();

  //     that.setData({
  //       hua: z_,
  //       curr_index: c_i
  //     });
  //     that.setData({
  //       left_: 0
  //     });
  //     return false;
  //   } else if (e_h - s_h > 0 && Math.abs(e_h - s_h) >= 30) {


  //     if (e_X > s_X) {
  //       if (e_X - s_X > 20) {
  //         console.log('嘻嘻嘻')

  //         return false;
  //       }
  //     }
  //     if (s_X > e_X) {
  //       if (s_X - e_X > 20) {
  //         return false;
  //       }
  //     }



  //     if (that.data.hua == 0) {
  //       wx.showToast({
  //         title: '下滑切换视频',
  //         icon: 'none'
  //       });
  //       return false;
  //     }
  //     // 上一个
  //     var z_ = that.data.hua + that.data.h
  //     var c_i = that.data.curr_index;
  //     c_i--;
  //     wx.createVideoContext("v" + (index_ - 1)).play();
  //     that.setData({
  //       hua: z_,
  //       curr_index: c_i
  //     });

  //     that.setData({
  //       left_: 0
  //     });
  //     return false;
      
  //   };
  
  // },
  get_up: function(e) {
    wx.hideLoading();
    // console.log(e.detail.currentTime);
    // console.log(e.detail.duration);
    this.setData({
      left_: (e.detail.currentTime * 100) / e.detail.duration
    })
    // console.log((e.detail.currentTime * 100) / e.detail.duration)
  },
  test_: function() {
    console.log(132)
    wx.showToast({
      title: '1',
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      page: options.page
    });
    if (options.t) {
      back_ = true;
    } else {
      back_ = false;
    }

    var that = this;
    var data_list = wx.getStorageSync('index_list');



    for (var i = 0; i < data_list.length; i++) {
      data_list[i].at = false;
      data_list[i].is_zt = false;
    };
    console.log(data_list)
    that.setData({
      list_: data_list
    })
    wx.getSystemInfo({

      success: function(e) {
        that.setData({
          h: e.windowHeight,
        })
        console.log(e)
      }
    });
    that.setData({
      curr_index: options.index,
      hua: parseInt('-' + options.index * that.data.h)
    })

    // var my_viode_ = wx.createVideoContext('v');
    // console.log(my_viode_)
    // my_viode_.requestFullScreen({
    //   direction:0
    // })

    // that.setData({
    //   txt: JSON.stringify(wx.createVideoContext('video_'))
    // })

  },
  // tog_paly: function() {
  //   console.log(123)
  //   wx.showToast({
  //     title: '123',
  //   })
  //   var that = this;
  //   var my_viode_ = wx.createVideoContext('video_');
  //   console.log(my_viode_)
  //   my_viode_.play();
  //   console.log(that.data.play_status)
  //   if (that.data.play_status == true) {
  //     my_viode_.pause();
  //     that.setData({
  //       play_status: false
  //     })
  //   } else {
  //     my_viode_.play();
  //     that.setData({
  //       play_status: true
  //     })
  //   }
  // },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    if (wx.getStorageSync('phone_yy')) {
      wx.showLoading({
        title: '预约中',
      })
      that.setData({
        b_time: wx.getStorageSync('b_time'),
      });
      var phone_ = wx.getStorageSync('phone_yy');
      wx.removeStorageSync('b_time');
      wx.removeStorageSync('phone_yy');
      wx.request({
        url: http + '/api/order/place', //仅为示例，并非真实的接口地址
        data: {
          access_token: wx.getStorageSync('token'),
          type: 2,
          will_time: that.data.b_time,
          content_id: that.data.sp_id,
          phone: phone_
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          wx.hideLoading();
          console.log(res.data);
          if (res.data.code == 1) {
            wx.request({
              url: http + '/api/order/pay', //仅为示例，并非真实的接口地址
              data: {
                access_token: wx.getStorageSync('token'),
                pay_sn: res.data.data[0].pay_sn
              },
              header: {
                'content-type': 'application/json' // 默认值
              },
              success(res) {
                console.log(res.data);
                if (res.data.code == 1) {
                  wx.requestPayment({
                    'timeStamp': res.data.data[0].timeStamp,
                    'nonceStr': res.data.data[0].nonceStr,
                    'package': res.data.data[0].package,
                    'signType': res.data.data[0].signType,
                    'paySign': res.data.data[0].paySign,
                    'success': function(res) {
                      console.log('支付成功');
                      wx.showToast({
                        title: '预约成功',
                      });
                      setTimeout(function() {
                        wx.navigateTo({
                          url: '../my_order/my_order?o=1',
                        });

                      }, 1500);

                    },
                    'fail': function(res) {
                      console.log('支付失败');
                      return;
                    },

                  });
                }
              }
            })

          } else {
            wx.showToast({
              title: res.data.message,
              icon: 'none'
            })
          }
        }
      })
    }

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    console.log('页面卸载');
    var that = this;
    wx.setStorageSync('index_list', that.data.list_);
    wx.setStorageSync('page', that.data.page);


  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
    var that = this;
    this.setData({
      show_fx: false
    })
    console.log('/pages/he/he?share_id=' + that.data.fx_id + '&uid=' + that.data.uid)
    return {
      title: '米莱美视界',
      path: '/pages/he/he?share_id=' + that.data.fx_id + '&uid=' + that.data.uid,
    }

  }
})