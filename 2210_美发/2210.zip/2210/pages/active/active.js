// pages/active/active.js

var app = getApp();
var http = app.globalData.http;

Page({

  /**
   * 页面的初始数据
   */
  data: {
      time_list:[],
      active_list:[],
      url:http,
      time_:'',
      name_:'',
      i_cur:0,
      id_:"",
    scroll_this:'',
    is_syr: false,
    goods_id:''
    

  },
  sure_: function () {
    this.setData({
      show_t: false
    });
    wx.navigateTo({
      url: '../apply_craft/apply_craft',
    });
  },
  et:function(){
      this.setData({
        scroll_this:'ib'
      })
  },
  yy:function(e){
    var that=this;
    if (that.data.active_list[e.target.dataset.index].over==0){
            wx.showToast({
              title: '抱歉人数以满',
              icon:'none'
            });
            return false;
        } 
      this.setData({
        id_:e.target.dataset.uid,
        goods_id: e.target.dataset.id
      });
    console.log(that.data.id_)
      wx.navigateTo({
        url: '../time_/time_?uid='+that.data.id_,
      })
  },
  tog_active:function(e){
    var that=this
    wx.showLoading({
      title: '加载中',
    });
    this.setData({
      time_: e.target.dataset.time,
      name_: e.target.dataset.name,
      i_cur: e.target.dataset.index
    })
    wx.request({
      url: http + '/api/promotion/pro_list', //仅为示例，并非真实的接口地址
      data: {
        id: e.target.dataset.id
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data);
        wx.hideLoading();
        if (res.data.code == 1) {
          that.setData({
            active_list: res.data.data[0].list
          })
        }else{
          that.setData({
            active_list:[]
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
        // 获取活动列表

    var that=this;







    // 判断是不是手艺人
    wx.request({
      url: http + '/api/member/add_content_tip', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        access_token: wx.getStorageSync('token')
      },
      success(res) {
        console.log(res.data);
        if (res.data.data[0].flag == 1) {
          that.setData({
            is_syr: true
          })
        } else {
          that.setData({
            is_syr: false
          })
        }
      }
    });





    wx.request({
      url: http +'/api/promotion/index', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data)
          if(res.data.code==1){
              that.setData({
                time_list:res.data.data,
                time_: res.data.data[0].name,
                name_: res.data.data[0].flag
              });

              var get_i='';
            for (var i = 0; i < that.data.time_list.length;i++){
              if (that.data.time_list[i].flag =="活动进行中"){
                console.log(i)
                    that.setData({
                      scroll_this: 'b' + (i - 2),
                      i_cur:i
                    });
                get_i=i;
              }
            };





            wx.request({
              url: http +'/api/promotion/pro_list', //仅为示例，并非真实的接口地址
              data: {
                id: that.data.time_list[get_i].id,
              },
              header: {
                'content-type': 'application/json' // 默认值
              },
              success(res) {
                console.log(res.data);
                    if(res.data.code==1){
                            that.setData({
                              active_list: res.data.data[0].list
                            })
                    }
              }
            })









          }

      }
    })












  },
  up_video: function () {
    var that = this;
    if (!wx.getStorageSync('token')) {
      wx.showToast({
        title: '请前往个人中心登陆',
        icon: 'none'
      });
      return false;
    }

    if (that.data.is_syr) {
      wx.chooseVideo({
        sourceType: ['album', 'camera'],
        compressed:false,
        maxDuration: 60,
        camera: 'back',
        success(res) {
          wx.showLoading({
            title: '上传中,请耐心等待',
          })
          console.log(res.tempFilePath);
          console.log(res);
          if ((res.size / 1024 / 1024) > 20) {
            wx.hideLoading();
            wx.showToast({
              title: '视频大小不能超过20M',
              icon: 'none'
            });
            return false;
          }

          wx.navigateTo({
            url: '../chk_video/chk_video?link=' + res.tempFilePath,
          });
          wx.hideLoading();
          
        }
      })
    } else {
      that.setData({
        show_t: true
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (wx.getStorageSync('phone_yy')) {
      wx.showLoading({
        title: '预约中',
      })
      that.setData({
        b_time: wx.getStorageSync('b_time'),
      });
      wx.removeStorageSync('b_time');

      var phone_ = wx.getStorageSync('phone_yy');
      wx.removeStorageSync('phone_yy');



      wx.request({
        url: http + '/api/order/place', //仅为示例，并非真实的接口地址
        data: {
          access_token: wx.getStorageSync('token'),
          type: 1,
          will_time: that.data.b_time,
          promotion_id: that.data.goods_id,
          phone: phone_
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          wx.hideLoading();
          console.log(res.data);
              if(res.data.code==1){
                wx.request({
                  url: http +'/api/order/pay', //仅为示例，并非真实的接口地址
                  data: {
                    access_token:wx.getStorageSync('token'),
                    pay_sn: res.data.data[0].pay_sn
                  },
                  header: {
                    'content-type': 'application/json' // 默认值
                  },
                  success(res) {
                    console.log(res.data);
                    if(res.data.code==1){
                      wx.requestPayment({
                        'timeStamp': res.data.data[0].timeStamp,
                        'nonceStr': res.data.data[0].nonceStr,
                        'package': res.data.data[0].package,
                        'signType': res.data.data[0].signType,
                        'paySign': res.data.data[0].paySign,
                        'success': function (res) {
                          console.log('支付成功');    
                          wx.showToast({
                            title: '预约成功',
                          });
                          setTimeout(function(){
                                wx.navigateTo({
                                  url: '../my_order/my_order?o=1',
                                })

                          },1500)

                        },
                        'fail': function (res) {
                          console.log('支付失败');
                          return;
                        },
                     
                      });
                    }
                  }
                })
              }else{
                    wx.showToast({
                      title: '发起支付失败',
                      icon:'none'
                    })
              }
        }
      })
    };

    wx.request({
      url: http+'/api/login/token_ex', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token')

      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data);
        if (res.data.code != 1 && wx.getStorageSync('token')) {
          wx.clearStorageSync();
          
          wx.showToast({
            title: '登陆超时,请重新登陆',
            icon: 'none'
          })
        }
      }
    });

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})