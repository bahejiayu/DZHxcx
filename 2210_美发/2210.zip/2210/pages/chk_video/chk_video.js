// pages/my_like/my_like.js

var app = getApp();
var http = app.globalData.http;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    h: '0',
    play_status: false,
    txt:"",
    video_src:'',
    video_poster:'',
    video_time:''
  },
  play_: function() {
    wx.showToast({
      title: '123',
    })
  },
  zt: function() {
    wx.showToast({
      title: '321',
    })
  },
  get_up: function (e) {

      this.setData({
        video_time: e.detail.duration
      })
    console.log(e.detail.duration);
   
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log(options.poster)
    var that = this;
    that.setData({
      video_src:options.link,
    })
    wx.getSystemInfo({

      success: function(e) {
        that.setData({
          h: e.windowHeight,
        })
        console.log(e)
      }
    });
    that.setData({
      txt: JSON.stringify(wx.createVideoContext('video_'))
    })

  },
  up_video:function(){
    var that=this;
    if (that.data.video_time>15){
            wx.showToast({
              title: '视频时长不能超过15秒',
              icon:'none'
            });
            return false;
      }


    wx.showModal({
      title: '上传须知',
      content: '个人最多上传20个作品,视频过多可前往"个人作品"中心删除',
      showCancel: false,//是否显示取消按钮
      confirmText: "我知道了",//默认是“确定”
      success: function (res) {
        if (res.cancel) {
          //点击取消,默认隐藏弹框
        } else {
          //点击确定
          wx.navigateTo({
            url: '../fb_video/fb_video?link=' + that.data.video_src,
          });
        }
      },
    })

       
  },
  tog_paly: function() {
      console.log(123)
    wx.showToast({
      title: '123',
    })
    var that = this;
    var my_viode_ = wx.createVideoContext('video_');
    my_viode_.play();
    console.log(that.data.play_status)
    if (that.data.play_status == true) {
      my_viode_.pause();
      that.setData({
        play_status:false
      })
    } else {
      my_viode_.play();
      that.setData({
        play_status: true
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})