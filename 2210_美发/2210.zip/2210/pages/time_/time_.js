// pages/de_time/de_time.js
var app = getApp();
var http = app.globalData.http;
var time_ = '';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    date_list: [],
    index_: 0,
    time_list: [],
    uid: '',
    time_index: '',
    show_phone:false,
    phone_txt:''
  },
  get_phone:function(e){
      this.setData({
        phone_txt:e.detail.value
      })

  },
  tog_deta: function(e) {
    var that = this;
    this.setData({
      index_: e.target.dataset.index,
      time_list: that.data.date_list[e.target.dataset.index].hour
    });
  },
  tog_time: function(e) {
    var that = this;

    var list_ = that.data.date_list;

    // console, log(list_[that.data.index_].hour[e.target.dataset.index].status)
    if (list_[that.data.index_].hour[e.target.dataset.index].status != 1) {
      return false;
    }



    that.setData({
      time_index: e.target.dataset.index
    })
    if (list_[that.data.index_].hour[e.target.dataset.index].cur == true) {
      list_[that.data.index_].hour[e.target.dataset.index].cur = false;
      that.setData({
        date_list: list_
      })
      return false;
    }



    for (var i = 0; i < list_.length; i++) {
      for (var j = 0; j < list_[i].hour.length; j++) {
        console.log(list_[i].hour[j].cur);
        list_[i].hour[j].cur = false;
      }
    };


    list_[that.data.index_].hour[e.target.dataset.index].cur = true;
    that.setData({
      date_list: list_
    });



  },
  btn: function() {
    var that = this;
    console.log('time_index=' + that.data.time_index)
    console.log('cur=' + that.data.date_list[that.data.index_].hour[that.data.time_index].cur)

    if (that.data.time_index === '') {
      wx.showToast({
        title: '请选择预约时间',
        icon: 'none'
      });
      console.log(231);

      return false;
    }

    if (that.data.date_list[that.data.index_].hour[that.data.time_index].cur != true) {
      console.log(123)
      wx.showToast({
        title: '请选择预约时间',
        icon: 'none'
      });
      return false;
    }
    console.log(that.data.date_list[that.data.index_].day + '-' + that.data.date_list[that.data.index_].hour[that.data.time_index].hour)
    wx.setStorageSync('b_time', that.data.date_list[that.data.index_].day + ' ' + that.data.date_list[that.data.index_].hour[that.data.time_index].hour);


    that.setData({
      show_phone:true
    })


  },
  cancel_:function(){
    wx.setStorageSync('phone_yy', 'false')
    wx.navigateBack({
      delta: 1
    });
  },
  sure_:function(){
    var that=this;
    var pattern = /^((1[3,5,7,8][0-9])|(14[5,7])|(17[0,6,7,8])|(19[7]))\d{8}$/;
    if (!pattern.test(that.data.phone_txt)){
          wx.showToast({
            title: '请输正确的手机格式',
            icon:'none'
          });
          return false;
      };
    wx.setStorageSync('phone_yy', that.data.phone_txt)
    wx.navigateBack({
      delta: 1
    });


  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log('uid=' + options.uid)
    this.setData({
      uid: options.uid

    })
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    // 获取日期
    wx.request({
      url: http + '/api/member/service_time', //仅为示例，并非真实的接口地址
      data: {
        uid: that.data.uid
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
        console.log(res.data);
        if (res.data.code == 1) {
          that.setData({
            date_list: res.data.data,
            time_list: res.data.data[0].hour
          })
        }
      }
    })



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})