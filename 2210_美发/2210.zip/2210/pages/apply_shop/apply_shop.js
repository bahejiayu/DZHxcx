// pages/apply_craft/apply_craft.js
var app = getApp();
var http = app.globalData.http;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone_: '',
    id_card_: '',
    shop_name_: '',
    shop_address_: '',
    shop_desc_: '',
    f_nav: [],
    hand_card: [],
    url: http,
    zz: [],
    shop_img: [],
    show_tip: false,
    book_list:[]
  },
  del_card: function (e) {
    var index_ = e.target.dataset.index;
    var del_list = this.data.hand_card;
    del_list.splice(index_, 1);
    this.setData({
      hand_card: del_list
    });

  },
  del_zz: function (e) {
    var index_ = e.target.dataset.index;
    var del_list = this.data.zz;
    del_list.splice(index_, 1);
    this.setData({
      zz: del_list
    });

  },
  del_shop: function (e) {
    var index_ = e.target.dataset.index;
    var del_list = this.data.shop_img;
    del_list.splice(index_, 1);
    this.setData({
      shop_img: del_list
    });
  },
  del_book:function(e){
    var index_ = e.target.dataset.index;
    var del_list = this.data.book_list;
    del_list.splice(index_, 1);
    this.setData({
      book_list: del_list
    });
  },
  get_phone: function (e) {
    this.setData({
      phone_: e.detail.value
    })
  },
  get_id_card: function (e) {
    this.setData({
      id_card_: e.detail.value
    })
  },
  get_shop_name: function (e) {
    this.setData({
      shop_name_: e.detail.value
    })
  },
  get_shop_address: function (e) {
    this.setData({
      shop_address_: e.detail.value
    })
  },
  get_shop_desc: function (e) {
    this.setData({
      shop_desc_: e.detail.value
    })
  },
  submit: function () {
    var that = this;
 





    if (that.data.shop_name_ == '') {
      wx.showToast({
        title: '请填写店铺名称',
        icon: 'none'
      })
      return false;
    }

    if (that.data.shop_address_ == '') {
      wx.showToast({
        title: '请填写店铺地址',
        icon: 'none'
      })
      return false;
    }
    if (that.data.zz.length<=0){
      wx.showToast({
        title: '请上传营业执照',
        icon: 'none'
      })
      return false;
    }

    if (that.data.shop_img.length < 3) {
      wx.showToast({
        title: '最少上传3张店铺照片',
        icon: 'none'
      })
      return false;
    }


    if (that.data.hand_card.length < 2) {
      wx.showToast({
        title: '请上传身份证两面',
        icon: 'none'
      })
      return false;
    }

    // if (that.data.book_list.length <= 0) {
    //   wx.showToast({
    //     title: '请上传相关证书',
    //     icon: 'none'
    //   })
    //   return false;
    // }


    // 获取经营范围
    var cid;

    for (var i = 0; i < that.data.f_nav.length; i++) {
      if (that.data.f_nav[i].cur) {
        cid = that.data.f_nav[i].id;
      }
    };
    console.log(cid);

    wx.showLoading({
      title: '提交中',
    })
    wx.request({
      url: http + '/api/shop/apply_shop', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        shop_name: that.data.shop_name_,
        shop_address: that.data.shop_address_,
        cid: cid,
        id_cards: that.data.hand_card,
        license_image: that.data.zz,
        shop_images: that.data.shop_img,
        cer_images: that.data.book_list
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data);
        if (res.data.code == 1) {
          that.setData({
            show_tip: true
          })
        } else {
          wx.showToast({
            title: res.data.message,
            icon: "none"
          });
        }
      }
    });
  },
  again_wait: function () {
    this.setData({
      show_tip: false
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 获取经营范围
    wx.request({
      url: http + '/api/index/category', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        if (res.data.code == 1) {
          for (var i = 0; i < res.data.data.length; i++) {
            if (i == 0) {
              res.data.data[i].cur = true;
            } else {
              res.data.data[i].cur = false;

            }
          }
          console.log(res.data);



          that.setData({
            f_nav: res.data.data
          })
        }
      }
    });
  },
  // 上传身份证
  up_card: function () {
    var that = this;
    // if (that.data.hand_card.length > 0) {
    //   wx.showToast({
    //     title: '不能重复上传',
    //     icon: 'none'
    //   });
    //   return false;
    // };
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths[0];
        wx.showLoading({
          title: '上传中',
        })
        wx.uploadFile({
          url: http + '/api/index/upload_image', //仅为示例，非真实的接口地址
          filePath: tempFilePaths,
          name: 'image',
          method: "POST",
          success: function (res) {
            wx.hideLoading();
            console.log(JSON.parse(res.data));
            var data_ = JSON.parse(res.data);
            if (data_.code == 1) {
              var list_img_up =that.data.hand_card;
              list_img_up.push(data_.data[0].image_name);
              that.setData({
                hand_card: list_img_up
              })

            } else {
              wx.showToast({
                title: '上传失败',
                icon: 'none'
              })
            }
          }
        })
      }
    })
  },
  // 上传营业执照
  up_zz: function () {
    var that = this;
    if (that.data.zz.length > 0) {
      wx.showToast({
        title: '不能重复上传',
        icon: 'none'
      });
      return false;
    };
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths[0];
        wx.showLoading({
          title: '上传中',
        })
        wx.uploadFile({
          url: http + '/api/index/upload_image', //仅为示例，非真实的接口地址
          filePath: tempFilePaths,
          name: 'image',
          method: "POST",
          success: function (res) {
            wx.hideLoading();
            console.log(JSON.parse(res.data));
            var data_ = JSON.parse(res.data);
            if (data_.code == 1) {
              var list_img_up = [];
              list_img_up.push(data_.data[0].image_name);
              that.setData({
                zz: list_img_up
              })

            } else {
              wx.showToast({
                title: '上传失败',
                icon: 'none'
              })
            }
          }
        })
      }
    })
  },
  // 上传店铺照
  up_shop: function () {
    var that = this;
    if (that.data.zz.length > 6) {
      wx.showToast({
        title: '最多上传六张',
        icon: 'none'
      });
      return false;
    };
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths[0];
        wx.showLoading({
          title: '上传中',
        })
        wx.uploadFile({
          url: http + '/api/index/upload_image', //仅为示例，非真实的接口地址
          filePath: tempFilePaths,
          name: 'image',
          method: "POST",
          success: function (res) {
            wx.hideLoading();
            console.log(JSON.parse(res.data));
            var data_ = JSON.parse(res.data);
            if (data_.code == 1) {
              var list_img_up = that.data.shop_img;
              list_img_up.push(data_.data[0].image_name);
              that.setData({
                shop_img: list_img_up
              })

            } else {
              wx.showToast({
                title: '上传失败',
                icon: 'none'
              })
            }
          }
        })
      }
    })

  },
  up_book:function(){
    var that = this;
 
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths[0];
        wx.showLoading({
          title: '上传中',
        })
        wx.uploadFile({
          url: http + '/api/index/upload_image', //仅为示例，非真实的接口地址
          filePath: tempFilePaths,
          name: 'image',
          method: "POST",
          success: function (res) {
            wx.hideLoading();
            console.log(JSON.parse(res.data));
            var data_ = JSON.parse(res.data);
            if (data_.code == 1) {
              var list_img_up = that.data.book_list;
              list_img_up.push(data_.data[0].image_name);
              that.setData({
                book_list: list_img_up
              })

            } else {
              wx.showToast({
                title: '上传失败',
                icon: 'none'
              })
            }
          }
        })
      }
    })
  },
  tog_fw: function (e) {
    var list_ = this.data.f_nav;
    for (var i = 0; i < list_.length; i++) {
      list_[i].cur = false;
    };
    list_[e.target.dataset.index].cur = true;
    console.log(e.target.dataset.index)
    this.setData({
      f_nav: list_
    })


  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})