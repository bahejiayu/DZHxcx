// pages/case/case.js
var app = getApp();
var http = app.globalData.http;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    service: '',
    two_level: '',
    service_price: '',
    share_price: '',
    ser_list: []
  },
  del_: function(e) {
    var that=this;
    wx.showModal({
      title: '提示',
      content: '是否确认删除',
      success: function(res) {
        if (res.confirm) {
          wx.showLoading({
            title: '正在删除',
          })
          wx.request({
            url: http +'/api/member/del_service', //仅为示例，并非真实的接口地址
            data: {
              access_token:wx.getStorageSync('token'),
              id:e.target.dataset.id
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success(res) {
              wx.hideLoading();
              console.log(res.data)
                if(res.data.code==1){
                      wx.showToast({
                        title: '删除成功',
                      });
                  that.get_list();








                }else{
                  wx.showToast({
                    title: res.data.message,
                    icon:'none'
                  })
                }
            }
          })
        }
      },
    })



  },
  get_service: function(e) {
    this.setData({
      service: e.detail.value
    });
  },
  get_two_level: function(e) {
    this.setData({
      two_level: e.detail.value
    });
  },
  get_service_price: function(e) {
    this.setData({
      service_price: e.detail.value
    });
  },
  get_share_price: function(e) {
    this.setData({
      share_price: e.detail.value
    });
  },
  sub_mit: function() {
    if (!wx.getStorageSync('token')) {
      wx.showToast({
        title: '请前往个人中心登陆',
        icon: 'none'
      });
      return false;
    }

    var that = this;
    if (that.data.service == "") {
      wx.showToast({
        title: '请输入项目名称',
        icon: 'none'
      });
      return false;
    }
    if (that.data.service_price == "") {
      wx.showToast({
        title: '请输入服务价格',
        icon: 'none'
      });
      return false;
    }
    if (that.data.share_price == "") {
      wx.showToast({
        title: '请输入分享佣金',
        icon: 'none'
      });
      return false;
    }



    wx.showLoading({
      title: '添加中',
    })
    wx.request({
      url: http + '/api/member/add_service', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        service: that.data.service,
        two_level: that.data.two_level,
        service_price: that.data.service_price,
        share_price: that.data.share_price
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
        console.log(res.data)
        if (res.data.code == 1) {
          wx.showToast({
            title: '提交成功,请等待审核',
            icon:'none'
          })
          that.setData({
            service: '',
            two_level: '',
            service_price: '',
            share_price: '',
          });
        } else {
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
      }
    })











  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

    var that = this;
    this.get_list();

  },
  get_list:function(){
    var that=this;
    wx.request({
      url: http + '/api/member/service', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data);
        if (res.data.code == 1) {
          that.setData({
            ser_list: res.data.data
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})