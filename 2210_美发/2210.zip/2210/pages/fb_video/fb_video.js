// pages/fb_video/fb_video.js

var app = getApp();
var http = app.globalData.http;
var get_data = {}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    video_src: '',
    title: "",
    price: '',
    fx: '',
    f_nav: [],
    cl_r: '10000',
    label_: false,
    label_txt:'',
    fw:""

  },
  bindPickerChange: function(e) {
    var that = this;
    console.log(e.detail.value);
    console.log(that.data.f_nav[that.data.cl_r].all_data[e.detail.value].id);
    this.setData({
      label_: that.data.f_nav[that.data.cl_r].all_data[e.detail.value].id,
      label_txt: that.data.f_nav[that.data.cl_r].all_data[e.detail.value].title
    })

  },
  get_fw:function(e){
    this.setData({
      fw: e.detail.value
    });
  },
  get_t: function(e) {
    var that = this;
    this.setData({
      cl_r: e.target.dataset.index
    });

    // wx.request({
    //   url: http + '/api/index/category_detail', //仅为示例，并非真实的接口地址
    //   data: {
    //     id: e.target.dataset.id,

    //   },
    //   header: {
    //     'content-type': 'application/json' // 默认值
    //   },
    //   success(res) {
    //     console.log(res.data);
    //     if (res.data.code = 1) {
    //         that.setData({
    //           all_data:res.data.data
    //         });
    //         var list_=[];
    //       for (var i = 0; i < res.data.data.length;i++){
    //         list_.push(res.data.data[i].title)
    //         };
    //       console.log(list_)
    //         that.setData({
    //           arr:list_
    //         })
    //     }
    //   }
    // });


  },
  get_title: function(e) {
    this.setData({
      title: e.detail.value
    });
  },
  get_price: function(e) {
    this.setData({
      price: e.detail.value
    });
  },
  get_fx: function(e) {
    this.setData({
      fx: e.detail.value
    });
  },
  sub_mit: function() {
    var that = this;
    if (that.data.title == '') {
      wx.showToast({
        title: '请输入作品标题',
        icon: 'none'
      });
      return false;
    }
    if (that.data.fw == '') {
      wx.showToast({
        title: '请输服务项目',
        icon: 'none'
      });
      return false;
    }

    if (that.data.price == '') {
      wx.showToast({
        title: '请输入价格',
        icon: 'none'
      });
      return false;
    }
    if (isNaN(that.data.price)) {
      wx.showToast({
        title: '价格只能是数字',
        icon: 'none'
      });
      return false;
    }

    if (that.data.fx == '') {
      wx.showToast({
        title: '请输入分享返佣金额',
        icon: 'none'
      });
      return false;
    }
    if (isNaN(that.data.fx)) {
      wx.showToast({
        title: '佣金只能是数字',
        icon: 'none'
      });
      return false;
    }


    if (that.data.label_ == false) {
      wx.showToast({
        title: '请选择标签',
        icon: 'none'
      });
      return false;
    };





    wx.showLoading({
      title: '上传中',
    })
    // 上传视频
    wx.uploadFile({
      url: http + '/api/index/upload_video', //仅为示例，非真实的接口地址
      filePath: that.data.video_src,
      name: 'video',
      success(res) {
        // const data = res.data
        console.log(JSON.parse(res.data));
        var data_ = JSON.parse(res.data);
      
        if (data_.code == 1) {
          wx.request({
            url: http +'/api/member/add_content', //仅为示例，并非真实的接口地址
            data: {
              access_token: wx.getStorageSync('token'),
              cid: that.data.label_,
              video_url: data_.data[0].video_url,
              video_cover: data_.data[0].vider_cover,
              title: that.data.title,
              price: that.data.price,
              share_price: that.data.fx,
              video_dir: data_.data[0].video_dir,
              service_name:that.data.fw

            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success(res) {
              wx.hideLoading();
             
              if(res.data.code==1){
                wx.showToast({
                  title: '上传成功,请耐心等待审核',
                  icon:'none'
                });
                setTimeout(function(){
                  wx.reLaunch({
                      url:"../index/index"
                  });
                },1500)
              }else{
                wx.showToast({
                  title: res.data.message,
                  icon:'none'
                });
              }              
              console.log(res.data)
            }
          })

        }
      }
    })
















  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var class_index = 0;

    wx.request({
      url: http + '/api/index/category', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data);
        if (res.data.code == 1) {
          that.setData({
            f_nav: res.data.data
          });
          get_data = res.data.data;

          function get_class() {

            wx.request({
              url: http + '/api/index/category_detail', //仅为示例，并非真实的接口地址
              data: {
                id: get_data[class_index].id,

              },
              header: {
                'content-type': 'application/json' // 默认值
              },
              success(res) {
                if (res.data.code == 1) {
                  console.log(res.data);
                  var ls_list = get_data;
                  ls_list[class_index].all_data = res.data.data;
                  var key_data = [];
                  for (var i = 0; i < res.data.data.length; i++) {
                    key_data.push(res.data.data[i].title)
                  }
                  ls_list[class_index].picker = key_data;
                  that.setData({
                    f_nav: ls_list
                  })
                  console.log(ls_list);

                  if (class_index >= get_data.length - 1) {

                    return false;
                  } else {
                    class_index++;
                    get_class();
                  }
                }
              }
            });
          };
          get_class();
        }
      }
    });


    var that = this;
    // http://tmp/wxa352e3cb1b683a96.o6zAJs2h9Bg4094AokGnZ5IPelGQ.sKL6MaQgHLS61b88892d57f9e1ca0f6fcb493246773d.mp4
    this.setData({
      video_src: options.link
    });




  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})