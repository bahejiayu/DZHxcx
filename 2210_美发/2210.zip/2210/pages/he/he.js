// pages/my_like/my_like.js
var app = getApp();
var http = app.globalData.http;
var cur_page = 1;
Page({



  /**
   * 页面的初始数据
   */
  data: {
    w: '0',
    he_data: {},
    video_list: [],
    url: http,
    type_: 1,
    uid: '',
    y_: false,
    ser_data: [],
    show_id: '',
    id_: '',
    b_time:'',
    txt_:'请选择',
    show_t:false,
    name_:'',
    show_b:false,
    is_syr:false,
    is_fx_:false,
    phone_:'',
    shop_img:[]

  },
  go_ev: function (e) {
    wx.navigateTo({
      url: '../evaluate_list/evaluate_list?id=' + e.target.dataset.id,
    })
  },
  look_img:function(e){
    var arr_ = this.data.shop_img;

    for (var i = 0; i < arr_.length;i++){
      arr_[i] = http + arr_[i];
    }


    wx.previewImage({
      urls: arr_,
      current: e.target.dataset.cur
    });
  },
  up_video: function () {
    var that = this;
    if (!wx.getStorageSync('token')) {
      wx.showToast({
        title: '请前往个人中心登陆',
        icon: 'none'
      });
      return false;
    }



    if (that.data.is_syr) {
      wx.chooseVideo({
        sourceType: ['album', 'camera'],
        maxDuration: 60,
        compressed: false,
        camera: 'back',
        success(res) {
          wx.showLoading({
            title: '上传中,请耐心等待',
          })
          console.log(res.tempFilePath);
          console.log(res);
          if ((res.size / 1024 / 1024) > 20) {
            wx.hideLoading();
            wx.showToast({
              title: '视频大小不能超过20M',
              icon: 'none'
            });
            return false;
          }
          wx.navigateTo({
            url: '../chk_video/chk_video?link=' + res.tempFilePath,
          });
          wx.hideLoading();
        }
      })
    } else {
      that.setData({
        show_t: true
      })
    }
  },
  go_:function(){
      this.setData({
        show_b:false
      })
    // wx.reLaunch({
    //   url: '../index/index',
    // });
  },
  go_time:function(e){
    var that=this;
        wx.navigateTo({
          url: '../time_/time_?uid='+that.data.uid,
        })
  },
  toggle_chk: function(e) {
    var that = this;
    if (that.data.id_ == e.target.dataset.id) {
      that.setData({
        id_: ''
      });
    } else {
      that.setData({
        id_: e.target.dataset.id
      });
    }

  },
  show_list: function(e) {
    var that = this;
    if (that.data.show_id == e.target.dataset.txt) {
      that.setData({
        show_id: ''
      })
    } else {
      that.setData({
        show_id: e.target.dataset.txt
      })
    }




  },
  yue: function() {
    this.setData({
      y_: true
    })
  },
  h_y: function() {
    this.setData({
      y_: false
    })
  },
  tog_type: function(e) {
    var that = this;
    this.setData({
      type_: e.target.dataset.type
    });
    wx.showLoading({
      title: '加载中',
    });
    if (that.data.type_ == 1) {
      wx.request({
        url: http + '/api/member/my_content', //仅为示例，并非真实的接口地址
        data: {
          page: 1,
          limit: 6,
          access_token: wx.getStorageSync('token'),
          uid: that.data.uid
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          console.log(res.data)

          wx.hideLoading();
          if (res.data.code == 1) {
            for (var i = 0; i < res.data.data.length + 1; i++) {
              if (((i + 1) % 3) == 0) {
                var index_ = (i - 1);
                // console.log(res.data.data[0].list)
                console.log(res.data.data[index_])
                res.data.data[index_].b = true;
              }
            }
            cur_page = 1;
            that.setData({
              video_list: res.data.data
            });
          }
        }
      });
    } else {
      wx.request({
        url: http + '/api/member/my_like', //仅为示例，并非真实的接口地址
        data: {
          page: 1,
          limit: 6,
          access_token: wx.getStorageSync('token'),
          uid: that.data.uid
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          console.log(res.data)

          wx.hideLoading();
          if (res.data.code == 1) {
            for (var i = 0; i < res.data.data.length + 1; i++) {
              if (((i + 1) % 3) == 0) {
                var index_ = (i - 1);
                console.log(res.data.data[index_])
                res.data.data[index_].b = true;
              }
            };
            that.setData({
              video_list: res.data.data
            });
          }
        }
      });
    }




  },
  bo: function(e) {
    wx.makePhoneCall({
      phoneNumber: e.target.dataset.p,
    });
  },
  go_list: function(e) {
    console.log(e.target.dataset.index);
    var that = this;
    wx.setStorageSync('index_list', that.data.video_list);
    if (e.target.dataset.t == 1) {
      wx.navigateTo({
        url: '../video/video?index=' + e.target.dataset.index + "&t=1" + '&page=' + e.target.dataset.page,
      })
    } else {
      wx.navigateTo({
        url: '../video/video?index=' + e.target.dataset.index + '&page=' + e.target.dataset.page,
      })

    }

  },
  gz_btn: function(e) {
    if (!wx.getStorageSync('token')) {
      wx.showToast({
        title: '请前往个人中心登陆',
        icon: 'none'
      });
      return false;
    }
    var that = this;
    if (that.data.he_data.is_follow.is_me == 1) {
      wx.showToast({
        title: '不能关注自己',
        icon: 'none'
      });
      return false;
    }


    var g_data = that.data.he_data;
    if (g_data.is_follow.is_follow == 1) {
      g_data.is_follow.is_follow = 0;
    } else {
      g_data.is_follow.is_follow = 1;

    }

    that.setData({
      he_data: g_data
    });



    console.log(that.data.he_data.is_follow.is_follow)

    wx.request({
      url: http + '/api/member/follow', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        to_uid: e.target.dataset.id
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data);
        if(res.data.code == 1) {

        }else{
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
      }
    })
  },
  sure_: function () {
    wx.reLaunch({
      url: '../my/my',
    });
 
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    // 分享
    console.log(options,'............')
    if (options.yy==1){
      that.setData({
        y_:true
      })

    }else{
      that.setData({
        y_: false
      })
    }
    wx.request({
      url: http + '/api/member/add_content_tip', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        access_token: wx.getStorageSync('token')
      },
      success(res) {
        console.log(res.data);
        if (res.data.data[0].flag == 1) {
          that.setData({
            is_syr: true
          })
        } else {
          that.setData({
            is_syr: false
          })
        }
      }
    });
    
    if(options.share_id){
          that.setData({
            is_fx_:true
          })
    
        if(wx.getStorageSync('token')){
        
          wx.request({
            url: http +'/api/member/after_share', //仅为示例，并非真实的接口地址
            data: {
              share_id: options.share_id,
              access_token: wx.getStorageSync('token')
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success(res) {
              console.log(res.data);
                if(res.data.code==1){
                  that.setData({
                    show_b: true,
                    name_: res.data.data[0].nickname

                  })
                }
            }
          });
        }else{

          wx.login({
            success: function (res) {
              if (res.code) {
             
                var code_ = res.code;
                wx.request({
                  url: http + '/api/login/wxlogin', //仅为示例，并非真实的接口地址
                  data: {
                    code: code_,
                  },
                  header: {
                    'content-type': 'application/json' // 默认值
                  },
                  success(res) {
                
                    console.log(res.data);
                  if(res.data.code==1){
                    console.log(res.data.data[0].access_token);
                    var my_token = res.data.data[0].access_token;
                    wx.request({
                      url: http + '/api/member/after_share', //仅为示例，并非真实的接口地址
                      data: {
                        share_id: options.share_id,
                        access_token: my_token
                      },
                      header: {
                        'content-type': 'application/json' // 默认值
                      },
                      success(res) {
                        console.log(res.data.data[0].nickname);
                            if(res.data.code==1){
                                  that.setData({
                                    show_t:true,
                                    name_: res.data.data[0].nickname
                                  })
                            }
                      }
                    });
                    
                  }
                 
                  }
                })


              }
            }
          })



        }
      }else{
        that.setData({
          is_fx_:false
        })
      }




    that.setData({
      uid: options.uid
    })
    wx.getSystemInfo({

      success: function(e) {
        that.setData({
          w: e.screenWidth,
        })
        console.log(e)
      }
    });
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: http + '/api/member/home_page', //仅为示例，并非真实的接口地址
      data: {
        uid: that.data.uid,
        access_token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data);
        wx.hideLoading();
        if (res.data.code == 1) {
          that.setData({
            he_data: res.data.data[0],
            shop_img: JSON.parse(res.data.data[0].shop_images||'[]')
          })
        };


      }
    })


    // 获取服务项目

    wx.request({
      url: http + '/api/member/service_index', //仅为示例，并非真实的接口地址
      data: {
        uid: that.data.uid
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        if (res.data.code == 1) {
          that.setData({
            ser_data: res.data.data[0]
          })
        }
        console.log(res.data.data[0]);

      }
    })







    // 获取作品
    wx.request({
      url: http + '/api/member/my_content', //仅为示例，并非真实的接口地址
      data: {
        page: 1,
        limit: 6,
        access_token: wx.getStorageSync('token'),
        uid: that.data.uid
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {

        if (res.data.code == 1) {
          for (var i = 0; i < res.data.data.length + 1; i++) {
            if (((i + 1) % 3) == 0) {
              var index_ = (i - 1);
              // console.log(res.data.data[0].list)
              console.log(res.data.data[index_])
              res.data.data[index_].b = true;
            }
          }

          that.setData({
            video_list: res.data.data
          });
          console.log(res.data.data)

        }
      }
    });












  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

    var that=this;
    if (wx.getStorageSync('page') == '个人') {
      wx.removeStorageSync('page');
      that.setData({
        video_list: wx.getStorageSync('index_list')
      });
    };


    
      that.setData({
       txt_: wx.getStorageSync('b_time')||'请选择',
       
      })
        if(wx.getStorageSync('b_time')){
            that.setData({
              b_time: wx.getStorageSync('b_time'),
              
            });
          wx.removeStorageSync('b_time');
        }
    if (wx.getStorageSync('phone_yy')) {
      that.setData({
        phone_yy: wx.getStorageSync('phone_yy'),

      });
      wx.removeStorageSync('phone_yy');
    }
  },
  btn:function(){
      var that=this;
      if(that.data.id_==''){
            wx.showToast({
              title: '请选择服务项目',
              icon:'none'
            });
            return false;
      };


    if (that.data.b_time == '') {
      wx.request({
        url: http + '/api/order/place', //仅为示例，并非真实的接口地址
        data: {
          access_token: wx.getStorageSync('token'),
          type: 3,
          service_id: that.data.id_
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          wx.hideLoading();
          console.log(res.data);
          if (res.data.code == 1) {
            wx.request({
              url: http + '/api/order/pay', //仅为示例，并非真实的接口地址
              data: {
                access_token: wx.getStorageSync('token'),
                pay_sn: res.data.data[0].pay_sn
              },
              header: {
                'content-type': 'application/json' // 默认值
              },
              success(res) {
                console.log(res.data);
                if (res.data.code == 1) {
                  wx.requestPayment({
                    'timeStamp': res.data.data[0].timeStamp,
                    'nonceStr': res.data.data[0].nonceStr,
                    'package': res.data.data[0].package,
                    'signType': res.data.data[0].signType,
                    'paySign': res.data.data[0].paySign,
                    'success': function (res) {
                      console.log('支付成功');
                      wx.showToast({
                        title: '预约成功',
                      });
                      setTimeout(function () {
                        wx.navigateTo({
                          url: '../my_order/my_order?o=1',
                        })

                      }, 1500)

                    },
                    'fail': function (res) {
                      console.log('支付失败');
                      return;
                    },

                  });
                }
              }
            })
          } else {
            wx.showToast({
              title: '发起支付失败',
              icon: 'none'
            })
          }
        }
      })
    
    }else{
      wx.request({
        url: http + '/api/order/place', //仅为示例，并非真实的接口地址
        data: {
          access_token: wx.getStorageSync('token'),
          type: 3,
          will_time: that.data.b_time,
          service_id: that.data.id_,
          phone:that.data.phone_yy
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          wx.hideLoading();
          console.log(res.data);
          if (res.data.code == 1) {
            wx.request({
              url: http + '/api/order/pay', //仅为示例，并非真实的接口地址
              data: {
                access_token: wx.getStorageSync('token'),
                pay_sn: res.data.data[0].pay_sn
              },
              header: {
                'content-type': 'application/json' // 默认值
              },
              success(res) {
                console.log(res.data);
                if (res.data.code == 1) {
                  wx.requestPayment({
                    'timeStamp': res.data.data[0].timeStamp,
                    'nonceStr': res.data.data[0].nonceStr,
                    'package': res.data.data[0].package,
                    'signType': res.data.data[0].signType,
                    'paySign': res.data.data[0].paySign,
                    'success': function (res) {
                      console.log('支付成功');
                      wx.showToast({
                        title: '预约成功',
                      });
                      setTimeout(function () {
                        wx.navigateTo({
                          url: '../my_order/my_order?o=1',
                        })

                      }, 1500)

                    },
                    'fail': function (res) {
                      console.log('支付失败');
                      return;
                    },

                  });
                }
              }
            })
          } else {
            wx.showToast({
              title: '发起支付失败',
              icon: 'none'
            })
          }
        }
      })
    }







  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {





    var that = this;
    cur_page++;
    wx.showLoading({
      title: '加载中',
    });
    if (that.data.type_ == 1) {
      wx.request({
        url: http + '/api/member/my_content', //仅为示例，并非真实的接口地址
        data: {
          page: cur_page,
          limit: 6,
          access_token: wx.getStorageSync('token'),
          uid: that.data.uid
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          console.log(res.data)

          wx.hideLoading();
          if (res.data.code == 1) {
            for (var i = 0; i < res.data.data.length; i++) {
              if (((i + 1) % 3) == 0) {
                var index_ = (i - 1);
                // console.log(res.data.data[0].list)
                console.log(res.data.data[index_])
                res.data.data[index_].b = true;
              }
            }

            that.setData({
              video_list: that.data.video_list.concat(res.data.data)
            });
          }
        }
      });
    } else {
      wx.request({
        url: http + '/api/member/my_like', //仅为示例，并非真实的接口地址
        data: {
          page: cur_page,
          limit: 6,
          access_token: wx.getStorageSync('token'),
          uid: that.data.uid
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          console.log(res.data)

          wx.hideLoading();
          if (res.data.code == 1) {
            for (var i = 0; i < res.data.data.length; i++) {
              if (((i + 1) % 3) == 0) {
                var index_ = (i - 1);
                // console.log(res.data.data[0].list)
                console.log(res.data.data[index_])
                res.data.data[index_].b = true;
              }
            }

            that.setData({
              video_list: that.data.video_list.concat(res.data.data)
            });
          }
        }
      });
    }
















  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})