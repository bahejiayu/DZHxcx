// pages/my_order/my_order.js


var app = getApp();
var http = app.globalData.http;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    order_list:[],
    url:http,
    cur_tit:'',
    cur_page:1,
    is_sure:false
  },
  up_data: function () {
    var that = this;
    wx.request({
      url: http + '/api/order/index', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        status: that.data.cur_tit,
        page: 1,
        limit: 5
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
        console.log(res.data);
        if (res.data.code == 1) {
          that.setData({
            order_list: res.data.data[0].order,
            cur_page:1
          })
          console.log(that.data.order_list)
        };
      }
    });

  },
  pay_:function(e){
    var that=this;
   
      wx.request({
        url: http + '/api/order/pay', //仅为示例，并非真实的接口地址
        data: {
          access_token: wx.getStorageSync('token'),
          pay_sn: e.target.dataset.pay
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          console.log(res.data);
          if (res.data.code == 1) {
            wx.requestPayment({
              'timeStamp': res.data.data[0].timeStamp,
              'nonceStr': res.data.data[0].nonceStr,
              'package': res.data.data[0].package,
              'signType': res.data.data[0].signType,
              'paySign': res.data.data[0].paySign,
              'success': function (res) {
                console.log('支付成功');
                wx.showToast({
                  title: '支付成功',
                });
                that.up_data();
              },
              'fail': function (res) {
                console.log('支付失败');
                return false;
              },

            });
          }
        }
      })
  },
  // 取消订单
  cancel_order:function(e){
    var that = this;
    wx.showModal({
      title: '提示',
      content: '是否确认取消',
      showCancel: true,//是否显示取消按钮
      cancelText: "否",//默认是“取消”
      confirmText: "是",//默认是“确定”
      success: function (res) {
        if (res.cancel) {
          //点击取消,默认隐藏弹框
        } else {
          //点击确定
          wx.showLoading({
            title: '取消中',
          });

          wx.request({
            url: http + '/api/order/cancel_order', //仅为示例，并非真实的接口地址
            data: {
              access_token: wx.getStorageSync('token'),
              order_id: e.target.dataset.order
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success(res) {
              wx.hideLoading();
              console.log(res.data);
              if (res.data.code == 1) {
                wx.showToast({
                  title: '已取消',
                  icon: 'none'
                });
                that.up_data();

              }
            }
          })
        }
      },
    })




  },
  // 删除订单
  del_order:function(e){
    var that = this;
    wx.showModal({
      title: '提示',
      content: '是否确认删除',
      showCancel: true,//是否显示取消按钮
      cancelText: "否",//默认是“取消”
      confirmText: "是",//默认是“确定”
      success: function (res) {
        if (res.cancel) {
          //点击取消,默认隐藏弹框
        } else {
          //点击确定
          wx.showLoading({
            title: '删除中',
          });
          wx.request({
            url: http + '/api/order/del_order', //仅为示例，并非真实的接口地址
            data: {
              access_token: wx.getStorageSync('token'),
              order_id: e.target.dataset.order
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success(res) {
              wx.hideLoading();
              console.log(res.data)
              if (res.data.code == 1) {
                wx.showToast({
                  title: '删除成功',
                  icon: 'none'
                })
              };
              that.up_data();
            }
          })
        }
      },
    })
  

   
  },
// 到店确认
  qx:function(){
      this.setData({
        is_sure:false
      });

  },
  qd:function(){
    var that=this;
    wx.showLoading({
      title: '正在确认',
    })
    wx.request({
      url: http + '/api/order/receive', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        order_id: that.data.s_id
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        that.setData({
          is_sure:false
        })
        wx.hideLoading();
        console.log(res.data)
        if (res.data.code == 1) {
          wx.showToast({
            title: '完成',
            icon: 'none'
          });
          that.up_data();
          
        }else{
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          });
        }
      }
    })

  },
  sure_btn: function (e) {
        this.setData({
          is_sure:true,
          s_id: e.target.dataset.order
        });
        return false;

    wx.showLoading({
      title: '正在确认',
    })
    wx.request({
      url: http + '/api/order/receive', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        order_id: e.target.dataset.order
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
        console.log(res.data)
        if (res.data.code == 1) {
          wx.showToast({
            title: '完成',
            icon: 'none'
          })
        }
      }
    })
  },
  tog_list:function(e){
    var that=this;
    wx.showLoading({
      title: '加载中',
    })
    that.setData({
      cur_tit: e.target.dataset.sts

    })
    that.setData({
      cur_page: 1
    });
    wx.request({
      url: http + '/api/order/index', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        status:e.target.dataset.sts,
        page:1,
        limit:5
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
        console.log(res.data);
        if (res.data.code == 1) {
          that.setData({
            order_list: res.data.data[0].order
          })
          console.log(that.data.order_list)
        }else{
          that.setData({
            order_list:[]
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      var that=this;
    if (options.o==1){
      wx.showModal({
        title: '提示',
        content: '为了您能安全的到认证店铺地址享受购买的服务,请不要与手艺人另约服务地点。',
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      }


    // wx.request({
    //   url: http +'/api/order/index', //仅为示例，并非真实的接口地址
    //   data: {
    //     access_token:wx.getStorageSync('token'),
    //     page: 1,
    //     limit: 5
    //   },
    //   header: {
    //     'content-type': 'application/json' // 默认值
    //   },
    //   success(res) {
    //     console.log(res.data);
    //     if(res.data.code==1){
    //         that.setData({
    //           order_list: res.data.data[0].order
    //         })
    //       console.log(that.data.order_list)
    //     }
    //   }
    // })
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.up_data();



  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    var page_ = that.data.cur_page;
    page_++;
    that.setData({
      cur_page:page_
    });
    wx.showLoading({
      title: '加载更多',
    })
    wx.request({
      url: http + '/api/order/index', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        status: that.data.cur_tit,
        page: that.data.cur_page,
        limit: 5
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
        console.log(res.data);
        if (res.data.code == 1) {
          that.setData({
            order_list: that.data.order_list.concat(res.data.data[0].order) 
          })
          console.log(that.data.order_list)
        }
      }
    });

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})