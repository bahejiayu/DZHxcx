// pages/get_now/get_now.js
var app = getApp();
var http = app.globalData.http;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    get_name:'',
    get_card:'',
    get_blank:"",
    get_phone:'',
    get_price:''
  },
  get_name:function(e){
      this.setData({
        get_name:e.detail.value
      })
  },
  get_card: function (e) {
    this.setData({
      get_card: e.detail.value
    })
  },
  get_blank: function (e) {
    this.setData({
      get_blank: e.detail.value
    })
  },
  get_phone: function (e) {
    this.setData({
      get_phone: e.detail.value
    })
  },
  get_price: function (e) {
    this.setData({
      get_price: e.detail.value
    })
  },
  sub_mit:function(){
    var that=this;
    if (that.data.get_name==''){
          wx.showToast({
            title: '请输入持卡人姓名',
            icon:'none'
          });
          return false;
      }

    if (that.data.get_card == '') {
      wx.showToast({
        title: '请输入银行卡',
        icon: 'none'
      });
      return false;
    }
    if (that.data.get_blank == '') {
      wx.showToast({
        title: '请输入所属银行',
        icon: 'none'
      });
      return false;
    }

    if (that.data.get_phone == '') {
      wx.showToast({
        title: '请输入手机号',
        icon: 'none'
      });
      return false;
    }

    if (that.data.get_price == '') {
      wx.showToast({
        title: '请输入提现金额',
        icon: 'none'
      });
      return false;
    };
    wx.showLoading({
      title: '提交中',
    })
    wx.request({
      url: http +'/api/account/apply',
      header: {
        'content-type': 'application/json' // 默认值
      },
      data:{
        type:2,
        name: that.data.get_name,
        card_num: that.data.get_card,
        bank: that.data.get_blank,
        mobile: that.data.get_phone,
        mission: that.data.get_price,
        access_token:wx.getStorageSync('token')
      },
      success:function(res){
        wx.hideLoading();
        if (res.data.code==1){
              wx.showToast({
                title: '已提交申请',
                icon:'none'
              });
              that.setData({
                get_name: '',
                get_card: '',
                get_blank: "",
                get_phone: '',
                get_price: ''
              })
        }else{
          wx.showToast({
            title: res.data.message,
            icon: 'none'
          })
        }
        
      }
    });


  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})