// pages/my_account/my_account.js
var app = getApp();
var http = app.globalData.http;
var curr_page=1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data_: {}
  },
  formatDateTime: function(timeStamp) {
    var date = new Date();
    date.setTime(timeStamp * 1000);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    var minute = date.getMinutes();
    var second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    return y + '-' + m + '-' + d + ' ' + h + ":" + minute + ':' + second;
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: http + '/api/account/index', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        page: 1,
        limit:10

      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function(res) {
        wx.hideLoading();
        if (res.data.code == 1) {

          for (var i = 0; i < res.data.data[0].account_detail.length; i++) {
            res.data.data[0].account_detail[i].time = that.formatDateTime(res.data.data[0].account_detail[i].create_time);
          }
          that.setData({
            data_: res.data.data[0]
          });
        }
        console.log(res.data);
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    curr_page=1;
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    curr_page++;
  var that=this;
    wx.showLoading({
      title: '加载更多',
    })
    wx.request({
      url: http + '/api/account/index', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        page: curr_page,
        limit: 10
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.code == 1) {

          for (var i = 0; i < res.data.data[0].account_detail.length; i++) {
            res.data.data[0].account_detail[i].time = that.formatDateTime(res.data.data[0].account_detail[i].create_time);
          }
                        // that.data.data_.account_detail.concat(res.data.data[0].account_detail)
          var old_data = that.data.data_;
          var new_data = that.data.data_.account_detail.concat(res.data.data[0].account_detail);
          old_data.account_detail = new_data;
          that.setData({
            data_: old_data
          });
        }
        console.log(res.data);
      }
    })

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})