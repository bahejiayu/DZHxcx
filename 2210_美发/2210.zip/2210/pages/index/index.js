
//                    _ooOoo_
//                   o8888888o
//                   88" . "88
//                   (| -_- |)
//                   O\  =  /O
//                ____/`---'\____
//              .'  \\|     |//  `.
//             /  \\|||  :  |||//  \
//            /  _||||| -:- |||||-  \
//            |   | \\\  -  /// |   |
//            | \_|  ''\---/''  |   |
//            \  .-\__  `-`  ___/-. /
//          ___`. .'  /--.--\  `. . __
//       ."" '<  `.___\_<|>_/___.'  >'"".
//      | | :  `- \`.;`\ _ /`;.`/ - ` : | |
//      \  \ `-.   \_ __\ /__ _/   .-` /  /
// ======`-.____`-.___\_____/___.-`____.-'======
//                    `=---='
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//          佛祖保佑       永无BUG
//          佛曰:    
//                  写字楼里写字间，写字间里程序员；    
//                  程序人员写程序，又拿程序换酒钱。    
//                  酒醒只在网上坐，酒醉还来网下眠；    
//                  酒醉酒醒日复日，网上网下年复年。    
//                  但愿老死电脑间，不愿鞠躬老板前；    
//                  奔驰宝马贵者趣，公交自行程序员。    
//                  别人笑我忒疯癫，我笑自己命太贱；    
//                  不见满街漂亮妹，哪个归得程序员？



  // *  ┏┓　　　┏┓
  //   *┏┛┻━━━┛┻┓
  //   *┃　　　　　　　┃ 　
  //   *┃　　　━　　　┃
  //   *┃　┳┛　┗┳　┃
  //   *┃　　　　　　　┃
  //   *┃　　　┻　　　┃
  //   *┃　　　　　　　┃
  //   *┗━┓　　　┏━┛
  //   *　　┃　　　┃神兽保佑
  // *　　┃　　　┃代码无BUG！
  //   *　　┃　　　┗━━━┓
  //   *　　┃　　　　　　　┣┓
  //   *　　┃　　　　　　　┏┛
  //   *　　┗┓┓┏━┳┓┏┛
  //   *　　　┃┫┫　┃┫┫
  //   *　　　┗┻┛　┗┻┛ 
  //   *　　　
  //   */
  var app = getApp();  
  var http = app.globalData.http;
  var cur_page = 1;
  Page({
    /**
     * 页面的初始数据
     */
    data: {
      url: http,
      show_l: false,
      f_nav: [],
      t_nav: [],
      cl_r: 1000,
      video_list: [],
      sort: 0,
      longitude: '',
      latitude: '',
      id_: '',
      is_syr: false,
      show_t: false,
      f_id:''
    },
    up_video: function() {
      var that = this;
      if (!wx.getStorageSync('token')) {
        wx.showToast({
          title: '请前往个人中心登陆',
          icon: 'none'
        });
        return false;
      }



      if (that.data.is_syr) {
        wx.chooseVideo({
          sourceType: ['album', 'camera'],
          maxDuration: 60,
          compressed: false,
          camera: 'back',
          success(res) {
            wx.showLoading({
              title: '上传中,请耐心等待',
            })
            console.log(res.tempFilePath);
            console.log(res);
            if ((res.size / 1024 / 1024) > 20) {
              wx.hideLoading();
              wx.showToast({
                title: '视频大小不能超过20M',
                icon: 'none'
              });
              return false;
            }
            wx.navigateTo({
              url: '../chk_video/chk_video?link=' + res.tempFilePath,
            });
            wx.hideLoading();
          }
        })
      } else {
        that.setData({
          show_t: true
        })
      }
    },
    sure_: function() {
      this.setData({
        show_t: false
      });
      wx.navigateTo({
        url: '../apply_craft/apply_craft',
      });
    },
    go_list: function(e) {
      console.log(e.target.dataset.index);
      var that = this;
      wx.setStorageSync('index_list', that.data.video_list);
      wx.navigateTo({
        url: '../video/video?index=' + e.target.dataset.index + '&page=' + e.target.dataset.page,
      })
    },
    get_list: function(e) {
      var that = this;
      wx.showLoading({
        title: '加载中',
      });
      this.setData({
        f_id:e.target.dataset.id
      })
      wx.request({
        url: http + '/api/index/index', //仅为示例，并非真实的接口地址
        data: {
          cid: e.target.dataset.id,
          lat: that.data.latitude,
          lng: that.data.longitude,
          sort: that.data.sort,
          page: cur_page,
          limit: 4,
          access_token: wx.getStorageSync('token')

        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          wx.hideLoading();
          console.log(res.data)
          if (res.data.code = 1) {
            that.setData({
              video_list: res.data.data[0].list
            })
          }

        }
      })
    },
    tog_sort: function(e) {
      var that = this;
      cur_page = 1;
      this.setData({
        sort: e.target.dataset.sort
      });
      wx.request({
        url: http + '/api/index/index', //仅为示例，并非真实的接口地址
        header: {
          'content-type': 'application/json' // 默认值
        },
        data: {
          cid: that.data.id_,
          lat: that.data.latitude,
          lng: that.data.longitude,
          sort: that.data.sort,
          page: cur_page,
          limit: 4,
          access_token: wx.getStorageSync('token')

        },
        success(res) {
          wx.hideLoading();
          console.log(res.data);
          if (res.data.code = 1) {
            that.setData({
              video_list: res.data.data[0].list,

            })
          }
        }
      });



    },
    show_l: function(e) {
      var that = this;
      this.setData({
        show_l: !that.data.show_l
      })
    },
    get_t: function(e) {
      cur_page = 1;
      this.setData({
        cl_r: e.target.dataset.index,
        id_: e.target.dataset.id || ""
      })
      var id_ = e.target.dataset.id;
      var that = this;
      if (e.target.dataset.index == 1000) {
        wx.request({
          url: http + '/api/index/index', //仅为示例，并非真实的接口地址
          header: {
            'content-type': 'application/json' // 默认值
          },
          data: {
            page: cur_page,
            limit: 4,
            access_token: wx.getStorageSync('token')


          },
          success(res) {
            wx.hideLoading();
            console.log(res.data);
            if (res.data.code = 1) {
              that.setData({
                video_list: res.data.data[0].list,
                sort: 0,
                t_nav: [],
                show_l: false
              })
            }
          }
        });






      } else {
        wx.request({
          url: http + '/api/index/category_detail', //仅为示例，并非真实的接口地址
          data: {
            id: id_,

          },
          header: {
            'content-type': 'application/json' // 默认值
          },
          success(res) {
            console.log(res.data);
            if (res.data.code = 1) {
              that.setData({
                t_nav: res.data.data
              })
            }
          }
        });
      }




    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
      var that = this;
      cur_page = 1;



      // 判断是不是手艺人
      wx.request({
        url: http + '/api/member/add_content_tip', //仅为示例，并非真实的接口地址
        header: {
          'content-type': 'application/json' // 默认值
        },
        data: {
          access_token: wx.getStorageSync('token')
        },
        success(res) {
          console.log(res.data);
          if (res.data.data[0].flag == 1) {
            that.setData({
              is_syr: true
            })
          } else {
            that.setData({
              is_syr: false
            })
          }
        }
      });




      // 获取视频的一级分类

      wx.getLocation({
        type: 'gcj02',
        success: function(res) {
          var latitude = res.latitude
          var longitude = res.longitude
          that.setData({
            longitude: longitude,
            latitude: latitude
          });
        },
      })

      wx.request({
        url: http + '/api/index/category', //仅为示例，并非真实的接口地址
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          console.log(res.data);
          if (res.data.code == 1) {
            that.setData({
              f_nav: res.data.data
            })
          }
        }
      });


      // 获取视频列表
      wx.showLoading({
        title: '加载中',
      })


      wx.request({
        url: http + '/api/index/index', //仅为示例，并非真实的接口地址
        header: {
          'content-type': 'application/json' // 默认值
        },
        data: {
          cid: that.data.id_,
          lat: that.data.latitude,
          lng: that.data.longitude,
          sort: that.data.sort,
          page: cur_page,
          limit: 4,
          access_token: wx.getStorageSync('token')
        },
        success(res) {
          wx.hideLoading();
          console.log(res.data);
          if (res.data.code = 1) {
            that.setData({
              video_list: res.data.data[0].list,

            })
          }
        }
      });




    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
      var that = this;
      if (wx.getStorageSync('page') == '首页') {
        wx.removeStorageSync('page');
        that.setData({
          video_list: wx.getStorageSync('index_list')
        });
      };



      wx.request({
        url: http + '/api/login/token_ex', //仅为示例，并非真实的接口地址
        data: {
          access_token: wx.getStorageSync('token')

        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          console.log(res.data);
          if (res.data.code != 1 && wx.getStorageSync('token')) {
            wx.clearStorageSync();

            wx.showToast({
              title: '登陆超时,请重新登陆',
              icon: 'none'
            })
          }
        }
      })



    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {
      var that = this;
      cur_page++;
      wx.showLoading({
        title: '加载更多',
      })
      wx.request({
        url: http + '/api/index/index', //仅为示例，并非真实的接口地址
        header: {
          'content-type': 'application/json' // 默认值
        },
        data: {
          cid: that.data.id_,
          lat: that.data.latitude,
          lng: that.data.longitude,
          sort: that.data.sort,
          page: cur_page,
          limit: 4,
          access_token: wx.getStorageSync('token')
        },
        success(res) {
          wx.hideLoading();
          console.log(res.data);
          if (res.data.code = 1) {
            that.setData({
              video_list: that.data.video_list.concat(res.data.data[0].list),

            })
          }
        }
      });


    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
     
    }
  })