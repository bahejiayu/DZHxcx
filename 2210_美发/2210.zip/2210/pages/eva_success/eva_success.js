// pages/eva_success/eva_success.js
var app = getApp();
var http = app.globalData.http;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id_:'',
    url: http,
    data_info:'',
    show_fx:false,
    uid:'',
    fx_id:""

  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      id_: options.id
    });



    var that = this;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: http + '/api/order/commentbefore', //仅为示例，并非真实的接口地址
      data: {
        order_id: that.data.id_
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading();
        console.log(res.data);
        if (res.data.code == 1) {
          that.setData({
            data_info: res.data.data
          })
        }
      }
    })
  },
  show_fx: function (e) {
    this.setData({
      show_fx: true,
     
    });

    var that = this;
    wx.request({
      url: http + '/api/member/share', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token'),
        order_id: that.data.id_
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data);
        if (res.data.code == 1) {
          that.setData({
            fx_id: res.data.data[0].share_id,
            uid: res.data.data[0].uid
          })
        }
      }
    })


  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;
    this.setData({
      show_fx: false
    })
    console.log('/pages/he/he?share_id=' + that.data.fx_id + '&uid=' + that.data.uid)
    return {
      title: '米莱美视界',
      path: '/pages/he/he?share_id=' + that.data.fx_id + '&uid=' + that.data.uid,
    }
  }
})