// pages/my/my.js
var app = getApp();
var http = app.globalData.http;
Page({

    /**
   * 页面的初始数据
   */
  data: {
      user_info:null,
      other_info:{},
      is_syr: false,
      ke_phone:''
  },
  go_me:function(){
    var that=this;
      wx.navigateTo({
        url: '../he/he?uid='+that.data.user_info.id,
      })
  },
  up_video: function () {
    var that = this;
    if (!wx.getStorageSync('token')) {
      wx.showToast({
        title: '请前往个人中心登陆',
        icon: 'none'
      });
      return false;
    }

    if (that.data.is_syr) {
      wx.chooseVideo({
        sourceType: ['album', 'camera'],
        maxDuration: 60,
        camera: 'back',
        compressed: false,
        success(res) {
          wx.showLoading({
            title: '上传中,请耐心等待',
          })
          console.log(res.tempFilePath);
          console.log(res);
          if ((res.size / 1024 / 1024) > 20) {
            wx.hideLoading();
            wx.showToast({
              title: '视频大小不能超过20M',
              icon: 'none'
            });
            return false;
          }
          wx.navigateTo({
            url: '../chk_video/chk_video?link=' + res.tempFilePath,
          });
          wx.hideLoading();
          
        }
      })
    } else {
      that.setData({
        show_t: true
      })
    }
  },
  sure_: function(){
    // console.log(1)
    this.setData({
      show_t: false
    });
    wx.navigateTo({
      url: '../apply_craft/apply_craft',
    });
  },

  bo: function (e) {
    var that=this;
    wx.makePhoneCall({
      phoneNumber: that.data.ke_phone
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      // wx.clearStorageSync()
      var that=this;


    wx.request({
      url: http +'/api/index/kefu',
      header: {
        'content-type': 'application/json' // 默认值
      },
      success:function(res){
          console.log(res.data);
              if(res.data.code==1){
                    that.setData({
                      ke_phone: res.data.data[0].kefu
                    })
              }
      },
    })


    // 判断是不是手艺人
    wx.request({
      url: http + '/api/member/add_content_tip', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        access_token: wx.getStorageSync('token')
      },
      success(res) {
        console.log(res.data);
        if (res.data.data[0].flag == 1) {
          that.setData({
            is_syr: true
          })
        } else {
          that.setData({
            is_syr: false
          })
        }
      }
    });


      if(wx.getStorageSync('token')){
            that.setData({
              user_info: wx.getStorageSync('user_obj')
            })
      };
  },
  login_: function (e) {
    var that = this;
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo']) {
          console.log(11111)
          wx.login({
            success: function (res) {
              if (res.code) {
               wx.showLoading({
                 title: '登陆中',
               });
                var code_ = res.code;
                var nickname_ = e.detail.userInfo.nickName;
                var headimage_ = e.detail.userInfo.avatarUrl;
                var sex_ = e.detail.userInfo.gender;
                wx.request({
                  url: http +'/api/login/wxlogin', //仅为示例，并非真实的接口地址
                  data: {
                    code: code_,
                    nickname: nickname_,
                    headimage: headimage_,
                    sex: sex_
                  },
                  header: {
                    'content-type': 'application/json' // 默认值
                  },
                  success(res) {
                    wx.hideLoading();
                    console.log(res.data);
                      if(res.data.code==1){
                        wx.setStorageSync('user_obj',res.data.data[0].user);
                        wx.setStorageSync('token',res.data.data[0].access_token);
                        that.setData({
                          user_info: wx.getStorageSync('user_obj')
                        })
                        wx.request({
                          url: http + '/api/member/index', //仅为示例，并非真实的接口地址
                          data: {
                            access_token: wx.getStorageSync('token')
                          },
                          header: {
                            'content-type': 'application/json' // 默认值
                          },
                          success(res) {
                            console.log(res.data)
                            if (res.data.code == 1) {
                              that.setData({
                                other_info: res.data.data[0]
                              })
                            }
                          }
                        })
                      }else{
                            wx.showToast({
                              title: '登陆失败',
                              icon:'none'
                            });
                      }
                  }
                })


              }
            }
          })
        }else{
          console.log(222)
        }
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    console.log(333)
    wx.request({
      url: http + '/api/member/index', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data)
            if(res.data.code==1){
                  that.setData({
                    other_info:res.data.data[0]
                  })
            }
      }
    });
    wx.request({
      url: http + '/api/login/token_ex', //仅为示例，并非真实的接口地址
      data: {
        access_token: wx.getStorageSync('token')

      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data);
        if (res.data.code != 1 && wx.getStorageSync('token')) {
          wx.clearStorageSync();
          
          wx.showToast({
            title: '登陆超时,请重新登陆',
            icon: 'none'
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})