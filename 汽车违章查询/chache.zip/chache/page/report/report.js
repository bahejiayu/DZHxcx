  var app= getApp()
  var http = app.globalData.http
  var appid = app.globalData.appid
  var secret = app.globalData.secret
  var loginObj= {}
  var touchDot = 0;//触摸时的原点 
  var time = 0;// 时间记录，用于滑动时且时间小于1s则执行左右滑动 
  var interval = "";// 记录/清理时间记录 
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    lastX: 0,          //滑动开始x轴位置
        lastY: 0,          //滑动开始y轴位置
        text: "没有滑动",
         currentGesture: 0, //标识手势
         currentTab:0,
         winWidth: 0,
         winHeight: 0,
         data_length:7,
         all_data:{},
         all_h:0,
         all_kong:true,
         dfk_data: {},
         dfk_h: 0,
         dfk_kong: true,
         cx_data: {},
         cx_h: 0,
         cx_kong: true,
         yc_data: {},
         yc_h: 0,
         yc_kong: true,
         z:0,
         vin:''
    
  },
  ser_vin:function(){ 
    var that=this;
    wx.request({
      url: http + '/Api/Order/getOrderlist', //仅为示例，并非真实的接口地址
      data: {
        vin:that.data.vin,
        uid: wx.getStorageSync('key').id,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.status == 1) {
          for (var i = 0; i < res.data.arr.length; i++) {
            res.data.arr[i].apifields = JSON.parse(res.data.arr[i].apifields);
            res.data.arr[i].carmsg = JSON.parse(res.data.arr[i].carmsg);

          }
          if (res.data.arr.length > 0) {
            that.setData({
              all_data: res.data.arr,
              all_kong: true,
              currentTab:0
            })
          } else {
            that.setData({
              currentTab:0,
              all_kong: false
            })
          }
        }
      }
    })

  },
  show_err:function(e){
    console.log(JSON.parse(e.target.dataset.res).reason) 
    // wx.showToast({
    //   title: JSON.parse(e.target.dataset.res).reason,
    //   icon: 'none',
    //   duration: 2000
    // })
    wx.showModal({
      title: '提示',
      content: JSON.parse(e.target.dataset.res).reason,
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })





  },
  get_vin:function(e){
      console.log(e.detail.value)
      this.setData({
        vin: e.detail.value
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */

  del:function(e){
    var that = this;
    
    wx.showModal({
      title: '提示',
      content: '是否确认删除该报告',
      success: function (res) {
        wx.showLoading({
          title: '删除中',
        })
        if (res.confirm) {
          console.log('用户点击确定')

          wx.request({
            url: http + '/Api/Order/delete', //仅为示例，并非真实的接口地址
            data: {
              oid: e.target.dataset.oid,
              uid: wx.getStorageSync('key').id
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success: function (res) {
              that.qq();
              wx.hideLoading()
            }
          })


        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })



      
    
  },
  
     initSystemInfo: function () {
       var that = this;

       wx.getSystemInfo({
         success: function (res) {
           that.setData({
             winWidth: res.windowWidth,
             winHeight: res.windowHeight
           });
         }
       });
     },
     get_cur:function(e){
       var that = this;
       
        this.setData({
          currentTab:e.target.dataset.index
        })
        if (e.target.dataset.index==0){
          // 请求全部订单

          wx.request({
            url: http + '/Api/Order/getOrderlist', //仅为示例，并非真实的接口地址
            data: {
              // w:'{"status":""}',
              uid: wx.getStorageSync('key').id,
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success: function (res) {
              console.log(res.data)
              if (res.data.status == 1) {
                for (var i = 0; i < res.data.arr.length; i++) {
                  res.data.arr[i].apifields = JSON.parse(res.data.arr[i].apifields);
                  res.data.arr[i].carmsg = JSON.parse(res.data.arr[i].carmsg);

                }
                if (res.data.arr.length > 0) {
                  that.setData({
                    all_data: res.data.arr,
                    all_kong: true,
                  })
                } else {
                  that.setData({
                    all_kong: false,
                    all_data: [],
                  })
                }
              }
            }
          })
        }


     },   
   
   

   bindChange:function(e){
   
     var that = this;
     if(e.detail.current==0){
          that.setData({
            z:that.data.all_h
          })
     } else if (e.detail.current == 1){
       that.setData({
         z:that.data.dfk_h
       })
          
     } else if (e.detail.current == 2){
       that.setData({
         z:that.data.cx_h
       })
     }else{
       that.setData({
         z:that.data.yc_h
       })
     }
     that.setData({ currentTab: e.detail.current });  
   },
    

  qq:function(){
    var that = this;
    // 请求全部订单

    wx.request({
      url: http + '/Api/Order/getOrderlist', //仅为示例，并非真实的接口地址
      data: {
        // w:'{"status":""}',
        uid: wx.getStorageSync('key').id,
        // uid:1
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.status == 1) {
          for (var i = 0; i < res.data.arr.length; i++) {
            res.data.arr[i].apifields = JSON.parse(res.data.arr[i].apifields);
            res.data.arr[i].carmsg = JSON.parse(res.data.arr[i].carmsg);

          }
          if (res.data.arr.length > 0) {
            that.setData({
              all_data: res.data.arr,
              all_kong: true,
            })
          } else {
            that.setData({
              all_kong: false,
              all_data:[],
            })
          }
        }
      }
    })

    // 请求待付款
    wx.request({
      url: http + '/Api/Order/getOrderlist', //仅为示例，并非真实的接口地址
      data: {
        w: '{"status":"1"}',
        uid: wx.getStorageSync('key').id,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.status == 1) {
          for (var i = 0; i < res.data.arr.length; i++) {
            res.data.arr[i].apifields = JSON.parse(res.data.arr[i].apifields);
            res.data.arr[i].carmsg = JSON.parse(res.data.arr[i].carmsg);
          }
          if (res.data.arr.length > 0) {
            that.setData({
              dfk_data: res.data.arr,
              dfk_kong: true,
            })
          } else {
            that.setData({
              dfk_kong: false,
              dfk_data: [],
            })
          }

        }
      }
    })



    // 请求查询中
    wx.request({
      url: http + '/Api/Order/getOrderlist', //仅为示例，并非真实的接口地址
      data: {
        w: '{"status":"2"}',
        uid: wx.getStorageSync('key').id,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.status == 1) {
          for (var i = 0; i < res.data.arr.length; i++) {
            res.data.arr[i].apifields = JSON.parse(res.data.arr[i].apifields);
            res.data.arr[i].carmsg = JSON.parse(res.data.arr[i].carmsg);
          }

          if (res.data.arr.length > 0) {
            that.setData({
              cx_data: res.data.arr,

              cx_kong: true
            })
          } else {
            that.setData({
              cx_kong: false,
              cx_data: [],
            })


          }
        }
      }
    })


    // 请求报告已出
    wx.request({
      url: http + '/Api/Order/getOrderlist', //仅为示例，并非真实的接口地址
      data: {
        w: '{"status":"3"}',
        uid: wx.getStorageSync('key').id,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.status == 1) {
          for (var i = 0; i < res.data.arr.length; i++) {
            res.data.arr[i].apifields = JSON.parse(res.data.arr[i].apifields);
            res.data.arr[i].carmsg = JSON.parse(res.data.arr[i].carmsg);
          }
          if (res.data.arr.length > 0) {
            that.setData({
              yc_data: res.data.arr,

              yc_kong: true
            })
          } else {
            that.setData({
              yc_kong: false,
              yc_data:[]
            })
          }
        }
      }
    })

  },
  onLoad: function (options) {
    this.initSystemInfo();
   

    this.qq();











  },
  // 触摸开始事件 
  touchStart: function (e) {
    console.log(touchDot = e.touches[0].pageX)
    touchDot = e.touches[0].pageX; // 获取触摸时的原点 
    // 使用js计时器记录时间  
    interval = setInterval(function () {
      time++;
    }, 100);
  },
  // 触摸移动事件 
  touchMove: function (e) {
  
  },
  // 触摸结束事件 
  touchEnd: function (e) {
    console.log(e.changedTouches[0].pageX)
    var touchMove = e.changedTouches[0].pageX;
    console.log("touchMove:" + touchMove + " touchDot:" + touchDot + " diff:" + (touchMove - touchDot));
    // 向左滑动  
    //  && time < 10
    if (touchMove - touchDot <= -30) {
      console.log('向左滑动');
      var that=this;
      if (that.data.currentTab==3){
        that.setData({
          currentTab: 0
        })
        }else{
        that.setData({
          currentTab: that.data.currentTab + 1
        })
        }

       



    }
    // 向右滑动 
    // && time < 10
    if (touchMove - touchDot >= 30 ) {
      console.log('向右滑动');
      var that = this;

      if (that.data.currentTab == 0) {
        that.setData({
          currentTab: 3
        })
      } else {
        that.setData({
          currentTab: that.data.currentTab - 1
        })
      }





    }
    touchMove=0;
    touchDot=0;
    clearInterval(interval); // 清除setInterval 
    time = 0;
  }, 
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
    this.qq();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})