var app = getApp()
var http = app.globalData.http

Page({

  /**
   * 页面的初始数据
   */
  data: {
    cx_lang: {
      error_code: '状态码',
      reason: '提示信息',
      result: '具体内容',
      claimCount: '查询出险次数',
      claimMoney: '理赔总金额',
      repairMoney: '维修总金额',
      repairCount: '维修总件数',
      renewMoney: '换件总金额',
      renewCount: '换件总件数',
      carClaimRecords: '查询结果列表',
      claimDetails: '理赔详情列表',
      itemName: '理赔项名称',
      itemType: '理赔项类型',
      itemAmount: '理赔项金额',
      otherAmount: '其他金额',
      dangerTime: '出险时间',
      licenseNo: '理赔车牌号',
      vehicleMode: '理赔车型',
      frameNo: '理赔车架号',
      damageMoney: '理赔金额',
      repairAmount: '维修金额',
      renewalAmount: '换件金额',
      vehicleModel:"车辆型号"
    },
    //金额字段记录表
    nub_arr: [

      //出险理赔的
      'claimMoney'/*=> '理赔总金额'*/,
      'renewMoney'/*=> '换件总金额'*/,
      'repairMoney'/*=> '维修总金额'*/,
      
      'itemAmount'/*=> '理赔项金额'*/,
      'otherAmount'/*=> '其他金额'*/,
      'damageMoney'/*=> '理赔金额'*/,
      'repairAmount'/*=> '维修金额'*/,
      'renewalAmount'/*=> '换件金额'*/,


      //车辆信息和去年投保信息
      'CheSun'/*=> '车损保额'*/,
      'SanZhe'/*=> '第三方责任险保额'*/,
      'DaoQiang'/*=> '全车盗抢保险保额'*/,
      'SiJi'/*=> '车上人员责任险(司机)保额'*/,
      'ChengKe'/*=> '车上人员责任险(乘客)保额'*/,
      'HuaHen'/*=> '车身划痕损失险保额'*/,
      'ZiRan'/*=> '自燃损失险保额'*/,



    ],
    data_:{},
    toggle_show: 100,
    one_class: [],
    child_class: [],
    is_loadding: true,
    is_status:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {


    console.log(this.data.nub_arr)
    console.log(options.rid)
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    wx.request({
      url: http + '/Api/Report/getReportByRid', //仅为示例，并非真实的接口地址
      data: {
        rid: options.rid,
        uid: wx.getStorageSync('key').id,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        wx.hideLoading()



        console.log(JSON.parse(res.data.arr.report_json).result)
       




        that.setData({
          data_: JSON.parse(res.data.arr.report_json).result,
          is_status: JSON.parse(res.data.arr.report_json)
        })


      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */

  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  show_all: function (e) {
    var that = this;

    console.log(e.target.dataset.gcid)

    if (e.target.dataset.index == that.data.toggle_show) {
      that.setData({
        toggle_show: 100000
      })
    } else {
      that.setData({
        toggle_show: e.target.dataset.index
      })
    }





    // 请求子分类数据

    // 品牌推荐





  }
})