  var app= getApp()
  var http = app.globalData.http
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    ck_1: false,
    ck_2: false,
    ck_3: false,
    ck_4:false,
    show_wx:false,
    show_cp:false,
    show_fd:false,
    data_obj:{},
    vin:'',
    kong:true,
    carno:"",
    eng:"",
    brandName:'',
    familyName:'',
    groupName:'',
    vehicleName:'',
    displacement:'',
    engineModel:'',
    res_obj:{},
   





  },
  get_carno:function(e){
      this.setData({
        carno:e.detail.value
      })
  },
  get_eng: function (e) {
    this.setData({
      eng:e.detail.value
    })
  },
  toggle_ck1:function(){
    var that=this;
      this.setData({
        ck_1: !that.data.ck_1,
      })
      if (that.data.ck_2!=true){
        that.setData({
          show_cp: !that.data.show_cp     
        })
      }
  },
  toggle_ck2: function () {
    var that = this;
    this.setData({
      ck_2: !that.data.ck_2,
      show_fd: !that.data.ck_2
    })
    if (that.data.ck_1!= true) {
      that.setData({
        show_cp: !that.data.show_cp

      })
    }
  },
  toggle_ck3: function () {
    var that = this;
    this.setData({
      ck_3: !that.data.ck_3,
     
    })

  },
  toggle_ck4: function () {
    var that = this;
    this.setData({
      ck_4: !that.data.ck_4,
       show_wx: !that.data.show_wx
    })

  },
  
  submit:function(){
    if (wx.getStorageSync('key')==false){
      wx.showModal({
        title: '提示',
        content: '请前往个人中心登陆',
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      return false

      }


    var that=this;
    var express = /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂学警港澳]{1}$/;
    if (that.data.ck_1){
      if (express.test(that.data.carno)==false){
        wx.showToast({
          title: '请填写正确的车牌号',
          icon: 'none',
          duration: 2000
        })
      return false
            }
      }

    if(that.data.ck_2){
      if (express.test(that.data.carno) == false) {
        wx.showToast({
          title: '请填写正确的车牌号',
          icon: 'none',
          duration: 2000
        })
        return false
      }
      if (that.data.eng.length==0){
        wx.showToast({
          title: '请填写正确的汽车发动机号',
          icon: 'none',
          duration: 2000
        })
        return false
      }
      }

    var data_arr=[{
      stu:that.data.ck_1,
      id:1
    },
      {
        stu: that.data.ck_2,
        id:2
      },
      {
        stu: that.data.ck_3,
        id:3
      },
      {
        stu: that.data.ck_4,
        id:4
      },
    ]
    var str=[];
    var flag=true
    for (var i = 0; i < data_arr.length;i++){
      if (data_arr[i].stu){
              flag=false;
              str.push(data_arr[i].id)
        }
    }

    if (flag){
      wx.showToast({
        title: '请选择需要查询的业务',
        icon: 'none',
        duration: 2000
      })
      return false
    }

    var obj={
      vin:that.data.vin,
      carno:that.data.carno,
      enginno:that.data.eng
    }

    wx.request({
      url: http +'/Api/Order/create', //仅为示例，并非真实的接口地址
      data: {
        aids: str.join(','),
        uid: wx.getStorageSync('key').id,
        apifields: JSON.stringify(obj),
        carmsg:JSON.stringify(that.data.res_obj),
        vin:that.data.vin
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if(res.data.status==1){
                wx.navigateTo({
                  url: '../pay/pay?oid='+res.data.arr.oid+'&order_sn='+res.data.arr.order_sn,
           })

// wx.request({
//   url: http + '/Api/Wxapi/smallapp', //仅为示例，并非真实的接口地址
//   data: {
//     out_trade_no: res.data.arr.order_sn,
//     uid: wx.getStorageSync('key').id,
//     body: '测试',
//     total_fee: 1
//   },
//   header: {
//     'content-type': 'application/json' // 默认值
//   },
//   success: function (res) {
//     console.log(res.data)
//     wx.requestPayment({

//       timeStamp: res.data.timeStamp,

//       nonceStr: res.data.nonceStr,

//       package: res.data.package,

//       signType: 'MD5',

//       paySign: res.data.paySign,

//       success: function (res) {
//         console.log(res)
//         wx.showToast({
//           title: "支付成功!",
//           duration: 2000,
//         });
//       },
//     })

//   }
// })
        }


      }
    })
      
  },
  show_sq:function(){
    wx.showModal({
      title: '授权说明',
      showCancel: false,
      content: '   根据《征信业管理条例》第十八条规定，向征信机构查询个人信息的，应当取得信息主体本人的书面同意并约定用途，但是，法律规定可以不经同意查询的除外，征信机构不得违反前款规定提供个人信息。		 \r\n \n点击查询按钮即表示您获取该查询用户授权，如若发生法律纠纷，我方不承担任何责任。',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        }else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    this.setData({
      vin: options.vin
    })
    var that=this;
    wx.showLoading({
      title: '加载中',
    })
    console.log(options.vin)
    wx.request({
      url: http +'/Api/Api/getVinParse', //仅为示例，并非真实的接口地址
      data: {
        key:'50e982e48a433f71147ccc89d0b30613',
        vin:options.vin
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();        
        console.log(res.data)
          if(res.data.status==1){
            
              that.setData({
                data_obj:res.data.arr.result.vehicleList[0],
                kong:false,
                res_obj: {
                  brandName: res.data.arr.result.vehicleList[0].brandName,
                  familyName: res.data.arr.result.vehicleList[0].familyName,
                  groupName: res.data.arr.result.vehicleList[0].groupName,
                  vehicleName: res.data.arr.result.vehicleList[0].vehicleName,
                  displacement: res.data.arr.result.vehicleList[0].displacement,
                  engineModel: res.data.arr.result.vehicleList[0].engineModel,
                }
              })
          }else{
              that.setData({
                kong:true
              })
            wx.showToast({
              title: '请求失败请,检查您的VIN号',
              icon: 'none',
              duration: 2000
            })

          }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide:function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})



