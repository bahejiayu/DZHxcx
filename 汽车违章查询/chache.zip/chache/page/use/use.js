  var app= getApp()
  var http = app.globalData.http
  var appid = app.globalData.appid
  var secret = app.globalData.secret
  var loginObj= {}
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
        key:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
        this.setData({
          key: wx.getStorageSync('key')
        })
  },
  loo_img:function(e){
    wx.previewImage({
      current:e.target.dataset.url, // 当前显示图片的http链接
      urls: [e.target.dataset.url] // 需要预览的图片http链接列表
    })
  },
  login_: function (e) {
    var that = this;
    wx.getSetting({
      success(res) {
    if (res.authSetting['scope.userInfo']) {
      // 获取用户信息
      wx.showLoading({
        title: '登陆中',
      })
     
      var info_json = JSON.parse(e.detail.rawData);
      wx.login({
        success: function (res) {
          if (res.code) {
            //发起网络请求
            wx.request({
              url: http + '/Api/Login/getsessionkey',
              method: 'POST',
              data: {
                code: res.code
              },
              header: {
                'content-type': 'application/x-www-form-urlencoded' // 默认值
              },
              success: function (res) {
                // openid获取成功
                console.log(res.data)
                var open_Id = res.data.openid;
                var NickName = info_json.nickName;
                var HeadUrl = info_json.avatarUrl;
                var gender = info_json.gender;
                // 请求自己的登录接口
                wx.request({

                  url: http + '/Api/Login/authlogin', //仅为示例，并非真实的接口地址
                  method: 'POST',
                  data: {
                    openid: open_Id,
                    NickName: NickName,
                    HeadUrl: HeadUrl,
                    gender: gender
                  },
                  header: {
                    'content-type': 'application/x-www-form-urlencoded' // 默认值
                  },
                  success: function (res) {
                    console.log(res.data)
                    if (res.data.status == 1) {
                      wx.setStorageSync('key', {
                        id: res.data.arr.ID,
                        tx_img: res.data.arr.HeadUrl,
                        name: res.data.arr.NickName
                      })
                      that.setData({
                        key: wx.getStorageSync('key')
                      })
                    } else {
                      wx.showToast({
                        title: '登陆失败',
                        icon: 'none',
                        duration: 2000
                      })
                    }
                    wx.hideLoading();
                  }
                })
              }
            })
          } else {
            console.log('登录失败！' + res.errMsg)
          }
        }
      });

    }

      }
    })




    console.log(e)
   
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})