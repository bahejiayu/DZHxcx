
var app = getApp()
var http = app.globalData.http


Page({

  /**
   * 页面的初始数据
   */
  data: {
      pay_data:{},
      order_sn:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options.oid)
    this.setData({
      order_sn: options.order_sn
    })
    
var that=this;
    wx.request({
      url: http +'/Api/Order/getOrderdetailbyOid', //仅为示例，并非真实的接口地址
      data: {
        oid: options.oid
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
          if(res.data.status==1){
                that.setData({
                  pay_data:res.data.arr,
                  
                })
          }

      }
    })
  },
  pay_:function(){
      console.log(this.data.order_sn)
        var that=this;
        wx.request({
  url: http + '/Api/Wxapi/smallapp', //仅为示例，并非真实的接口地址
  data: {
    out_trade_no: that.data.order_sn,
    uid: wx.getStorageSync('key').id,
    body: '金北汽车信息查询报告',
    total_fee: that.data.pay_data.price * 100
  
  },
  header: {
    'content-type': 'application/json' // 默认值
  },
  success: function (res) {
    console.log(res.data)
    wx.requestPayment({

      timeStamp: res.data.timeStamp,

      nonceStr: res.data.nonceStr,

      package: res.data.package,

      signType: 'MD5',

      paySign: res.data.paySign,

      success: function (res) {
        console.log(res)
        wx.showToast({
          title: "支付成功!",
          duration: 2000,
        });
        setTimeout(function(){
          wx.switchTab({
            url: '../report/report',
          })


        },1000)

      },
    })

  }
})
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})