  var app= getApp()
  var http = app.globalData.http
  var appid = app.globalData.appid
  var secret = app.globalData.secret
  var loginObj= {}
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    is_status: {},
    toggle_show: 100,
    data_:{},
    tb_lang: {
      BusinessStatus: '成功',
      StatusMessage: '成功状态描述',
      CarUsedType: '使用性质',
      LicenseNo: '车牌号',
      LicenseOwner: '车主姓名',
      PurchasePrice: '新车购置价格',
      IdType: '证件类型',
      CityCode: '城市Id',
      EngineNo: '发动机号',
      ModleName: '品牌型号',
      RegisterDate: '车辆注册日期',
      CarVin: '车辆识别代号',
      ForceExpireDate: '交强险到期时间',
      BusinessExpireDate: '商业险到期时间',
      NextForceStartDate: '下年的交强起保日期',
      NextBusinessStartDate: '下年的商业险起保日期',
      SeatCount: '座位数量',
      RateFactor1: '费率系数1(无赔款系数)',
      RateFactor2: '费率系数2(自主渠道系数)',
      RateFactor3: '费率系数3(自主核保系数)',
      RateFactor4: '	费率系数4(交通违法浮动系数)',
      FuelType: '燃料种类',
      ProofType: '条款种类',
      ClauseType: '条款类型',
      LicenseColor: '号牌底色',
      RunRegion: '行驶区域',
      IsPublic: '是否公车',
      BizNo: '商业险保单号',
      ForceNo: '交强险保单号',
      ExhaustScale: '排量信息',
      AutoMoldCode: '精友码',
      Source: '上年保险公司',
      CheSun: '车损保额',
      SanZhe: '第三方责任险保额',
      DaoQiang: '全车盗抢保险保额',
      SiJi: '车上人员责任险(司机)保额',
      ChengKe: '车上人员责任险(乘客)保额',
      BoLi: "玻璃单独破碎险保额",
      HuaHen: '车身划痕损失险保额',
      BuJiMianCheSun: '不计免赔险(车损)保额',
      BuJiMianSanZhe: '不计免赔险(三者)保额',
      BuJiMianDaoQiang: '不计免赔险(盗抢)保额',
      SheShui: '涉水行驶损失险保额',
      ZiRan: '自燃损失险保额',
      BuJiMianChengKe: '不计免乘客保额',
      BuJiMianSiJi: '不计免司机保额',
      BuJiMianHuaHen: '不计免划痕保额',
      BuJiMianSheShui: '不计免涉水保额',
      BuJiMianZiRan: '不计免自燃保额',
      BuJiMianJingShenSunShi: '不计免精神损失保额',
      HcSanFangTeYue: '机动车无法找到三方特约险保额',
      HcJingShenSunShi: '精神损失险保额',
      HcXiuLiChangType: '指定专修厂类型',
      HcXiuLiChang: '指定修理厂险',
      Fybc: '修理期间每天补偿',
      FybcDays: '天数0-90(含)天',
      SheBeiSunShi: '新增设备损失险保额新增设备损失险相关',
      BjmSheBeiSunShi: '不计免设备损失险保额',
      SheBeis: '列表',
      DN: '设备名称',
      DQ: '价格小计',
      DD: '实际价值',
      DT: '设备类型',
      PD: '购买日期',
    },
    // 使用性质
    f1: {
      1: '家庭自用车(默认)',
      2: '党政机关、事业团体',
      3: '非营业企业客车',
      4: '不区分营业',
      5: '出租租赁(仅支持人保报价)',
      6: '营业货车(仅支持人保报价)',
      7: '非营业货车(仅支持人保报价)',
      8: '城市公交'
    },
    // 证件类型
    f2: {
      0: '没有取到',
      1: '身份证',
      2: '组织机构代码证',
      3: '护照',
      4: '军官证',
      5: '港澳回乡证',
      6: '其他',
      7: '港澳通行证',
      8: '出生证',
      9: '营业执照(社会统一信用代码)',
      10: '税务登记证'
    },
    // 燃料种类
    f3: {
      1: '汽油',
      2: '柴油',
      3: '电',
      4: '混合油',
      5: '天然气',
      6: '液化石油气',
      7: '甲醇',
      8: '乙醇',
      9: '太阳能',
      10: '混合动力',
      11: '无',
      12: '其它',
    },
    // 条款种类
    f4: {
      1: '非营业用汽车用品',
      2: '家庭自用汽车产品',
      3: '营业用汽车产品',
      4: '摩托车产品',
      5: '拖拉机产品',
      6: '特种车产品'
    },
    // 条款类型
    f5: {
      1: '销售发票',
      2: '法院调解书',
      3: '法院仲裁书',
      4: '法院判决书',
      5: '仲裁裁决书',
      6: '相关文书',
      7: '批准文件',
      8: '调拨证明',
      9: '修理发票'
    },
    // 号牌底色
    f6: {
      1: '蓝',
      2: '黑',
      3: '白',
      4: '黄',
      5: '其他'
    },
    // 行驶区域
    f7: {
      1: '境内',
      2: '本省内',
      3: '其他'
    },
    // 是否公用
    f8: {
      0: '续保失败,无法获取该属性', 1: '公车', 2: '私车'
    },
    // 上年保险公司的枚举值
    f9: {
      1:'太平洋',2:'平安',4:'人保',8:'国寿财',16:'中华联合',32:'大地',64:'阳光',128:'太平保险',256:'华安',512:'天安',1024:'英大',2048:'安盛天平'
    },
    // 玻璃单独破碎险保额
    f10:{
      0:'不投保',
      1:'国产',
      2:'进口'
    },
    // 机动车无法找到三方特约险保额,
    f11:{
      1:'代表投保',
      0:'代表不投保'
    },
    // 精神损失险保额
    f12:{
      1:'代表投保', 
      0:'代表不投保'
    },
    // 指定专修厂类型
    f13:{
     '-1':'没有',
      0: '国产',
      1:'(依赖于请求参数)'
    },
    nub_arr: [

      //出险理赔的
      'claimMoney'/*=> '理赔总金额'*/,
      'renewMoney'/*=> '换件总金额'*/,
      'repairMoney'/*=> '维修总金额'*/,

      'itemAmount'/*=> '理赔项金额'*/,
      'otherAmount'/*=> '其他金额'*/,
      'damageMoney'/*=> '理赔金额'*/,
      'repairAmount'/*=> '维修金额'*/,
      'renewalAmount'/*=> '换件金额'*/,


      //车辆信息和去年投保信息
      'CheSun'/*=> '车损保额'*/,
      'SanZhe'/*=> '第三方责任险保额'*/,
      'DaoQiang'/*=> '全车盗抢保险保额'*/,
      'SiJi'/*=> '车上人员责任险(司机)保额'*/,
      'ChengKe'/*=> '车上人员责任险(乘客)保额'*/,
      'HuaHen'/*=> '车身划痕损失险保额'*/,
      'ZiRan'/*=> '自燃损失险保额'*/,
      'PurchasePrice'/*=> '新车购置价格'*/,



    ]

  },

  show_all: function (e) {
    var that = this;

    console.log(e.target.dataset.gcid)

    if (e.target.dataset.index == that.data.toggle_show) {
      that.setData({
        toggle_show: false
      })
    } else {
      that.setData({
        toggle_show: e.target.dataset.index
      })
    }

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options.rid)
    wx.showLoading({
      title: '加载中',
    })
    var that=this;
    wx.request({
      url: http + '/Api/Report/getReportByRid', //仅为示例，并非真实的接口地址
      data: {
        rid: options.rid,
        uid: wx.getStorageSync('key').id,
        // uid:1
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading()
        console.log(res.data)
        console.log(JSON.parse(res.data.arr.report_json))
            that.setData({
              data_: JSON.parse(res.data.arr.report_json),
              is_status: JSON.parse(res.data.arr.report_json)
            })
            console.log(that.data.data_.result.UserInfo)
            
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})