
var app = getApp()
var http = app.globalData.http

Page({

  /**
   * 页面的初始数据
   */
  data: {
        vin:'',
        wx:'',
        cx:'',
        cl:'',
        tb:''
  },
  qc:function(){
    wx.clearStorage()
  },
  da:function(){
    wx.navigateToMiniProgram({
      appId: 'wx4afe23e9d620c14a',
      path: 'pages/index/index',
      extarData: {
        open: 'happy'
      },
      envVersion: 'release',
      success(res) {
        // 打开成功  
      }
    })  

  },
  /**
   * 生命周期函数--监听页面加载
   */
  show_what:function(){
    wx.showModal({
      title: 'VIN',
      showCancel:false,
      content: '   VIN码是由17位字母、数字组成的编码，又称17位识别代码、车架号或17位号。车辆识别代码经过排列组合，可以使同一车型的车在30年之内不会发生重号现象，具有对车辆的唯一识别性，因此可称为"汽车身份证"。 \r\n \n	  车架号（Vehicle Identification Number），中文名叫车辆识别代码， 是制造厂为了识别而给一辆车指定的一组字码。',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  },
  show_bh:function(){
    wx.showModal({
      title: '维修保养记录',
      showCancel: false,
      content: '    车辆维修保养记录，是指包含车辆维修记录、保养记录、事故记录、保险记录、盗抢记录等涉及其自身历史信息的数据进行收集，并进行系统整理、分析判定，以书面形式向委托查询方展现的一种行业文书。   \r\n \n   车辆维修保养记录是对车辆历史情况的综合记录和描述，这些信息可以清楚的反映车辆是否出过事故、有无调表、泡水、火烧等等，帮助委托查询方看清车辆安全问题及车辆的整体情况，适用于二手车消费者和经销商在交易中进行风险评估和购买参考。',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  show_lp: function () {
    wx.showModal({
      title: '出险理赔记录',
      showCancel: false,
      content: '       出险理赔记录，是指车辆发生交通事故后，车主到保险公司理赔所记录的历年理赔的详细信息。主要包含出险次数、理赔时间、理赔金额、理赔具体项目等信息。',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  show_cl:function(){
    wx.showModal({
      title: '车辆信息状态',
      showCancel: false,
      content: '        车辆信息状态，是指该车辆在车管所数据库中详细信息记录。主要包括车辆类型、车架号、发动机号、车辆所有人、初次登记日期、车辆状态等信息。',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  show_xx:function(){
    wx.showModal({
      title: '车辆投保信息',
      showCancel: false,
      content: '         车辆投保信息，是指车辆投保以后，保险公司所记录的上年度详细投保信息。主要包括，上年投保公司、投保项目、各项目保额、投保时间、保险到期时间等信息。',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  get_vin:function(e){
    
      this.setData({
        vin: e.detail.value
      })
  },
  search_:function(){
    var that=this;
        if(that.data.vin.length!='17'){
          wx.showToast({
            title: '请输入17位的VIN号',
            icon: 'none',
            duration: 2000
          })
            return false
        }

        wx.request({
          url: http + '/Api/Api/getVinParse', //仅为示例，并非真实的接口地址
          data: {
            key: '50e982e48a433f71147ccc89d0b30613',
            vin: that.data.vin
          },
          header: {
            'content-type': 'application/json' // 默认值
          },
          success: function (res) {
            console.log(res.data)
            if (res.data.arr.error_code != 0) {
              wx.showToast({
                title: res.data.arr.reason,
                icon: 'none',
                duration: 2000
              })
            } else{

              wx.showLoading({
                title: '提交中',
              })

              setTimeout(function () {
                wx.navigateTo({
                  url: '../info/info?vin=' + that.data.vin,
                })
              }, 1000)

            }


          }
        })
      

















     





  },
  onLoad: function (options) {
    wx.showShareMenu({
      withShareTicket: true
    })
    wx.request({
      url: 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wxe14b2061adc7c448&secret=95bfba457f859c5bfe6b64e918d20e6e',
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res)

      }
    })
    var that=this;
    wx.request({
      url: http +'/Api/Api/getpricesofapi', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data.arr[0].price)
        
          if(res.data.status==1){
                that.setData({
                  wx: res.data.arr[3].price,
                  cx: res.data.arr[2].price,
                  cl: res.data.arr[0].price,
                  tb: res.data.arr[1].price
                })
          }
      }
    })
  
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
        console.log(1)
        var that = this;
        wx.request({
          url: http + '/Api/Api/getpricesofapi', //仅为示例，并非真实的接口地址
          header: {
            'content-type': 'application/json' // 默认值
          },
          success: function (res) {
            console.log(res.data.arr[0].price)

            if (res.data.status == 1) {
              that.setData({
                wx: res.data.arr[3].price,
                cx: res.data.arr[2].price,
                cl: res.data.arr[0].price,
                tb: res.data.arr[1].price
              })
            }
            wx.stopPullDownRefresh()
            
          }
        })

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: '自定义转发标题',
      path: '/page/user?id=123',
      success:function(e){
        console.log(e)
      }
    }
  }
})