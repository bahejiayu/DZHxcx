var app = getApp()
var http = app.globalData.http

Page({

  /**
   * 页面的初始数据
   */
  data: {
    data_:{},
    wx_lang: {
      notify_time: "推送时间",
      total_mileage: '公里数',
      number_of_accidents: '异常次数',
      car_brand: '车辆品牌',
      result_status: '查询结果状态',
      content: '维修项目',
      date: '入店时间',
      materal: '维修材料',
      mileage: '入店公里数',
      remark: '备注'
    },
    is_status:{},
    toggle_show: 100,
    one_class: [],
    child_class: [],
    is_loadding: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   

    console.log(options.rid)
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    wx.request({
      url: http + '/Api/Report/getReportByRid', //仅为示例，并非真实的接口地址
      data: {
        rid: options.rid,
        uid: wx.getStorageSync('key').id,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        wx.hideLoading()

        console.log(JSON.parse(res.data.arr.report_json).result)
        that.setData({
          data_: JSON.parse(res.data.arr.report_json).result,
          is_status: JSON.parse(res.data.arr.report_json)
        })
     

      }
    })


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */

  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  show_all: function (e) {
    var that = this;

   

    if (e.target.dataset.index == that.data.toggle_show){
          console.log(1)
      that.setData({
        toggle_show: 10000
      })
      }else{
      console.log(2)
        
      that.setData({
        toggle_show: e.target.dataset.index
      })
      }
    

 


    // 请求子分类数据

    // 品牌推荐





  }
})