var app = getApp();
var page_ = 1;
var limit_ = 4;


Page({
  data: {
    imgUrls: [],
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    circular: true,
    productData: [],
    proCat: [],
    page: 2,
    index: 2,
    brand: [],
    // 滑动
    imgUrl: [],
    kbs: [],
    lastcat: [],
    course: [],
    uc: false,
    nav: [],
    shu: 10000000,
    b_id:''
  },
  // qc:function(){
  //   wx.clearStorage();
  // },
  //跳转商品列表页   
  listdetail: function (e) {
    console.log(e.currentTarget.dataset.title)
    wx.navigateTo({
      url: '../listdetail/listdetail?title=' + e.currentTarget.dataset.title,
      success: function (res) {
        // success
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
  },
  //跳转商品搜索页  
  suo: function (e) {
    wx.navigateTo({
      url: '../search/search',
      success: function (res) {
        // success
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
  },
  //后四个分类跳转
  other: function (e) {
    var ptype = e.currentTarget.dataset.ptype;
    var title = e.currentTarget.dataset.text;
    if (ptype == 'news') {
      wx.navigateTo({
        url: '../inf/inf'
      });
    } else if (ptype == 'jxys') {
      wx.navigateTo({
        url: '../synopsis/synopsis?title=教学优势&wedId=2'
      });
    } else if (ptype == 'xyfc') {
      wx.navigateTo({
        url: '../student_style/student_style'
      });
    } else if (ptype == 'gywm') {
      wx.navigateTo({
        url: '../synopsis/synopsis?title=关于我们&wedId=1'
      });
    }
  },

  //品牌街跳转商家详情页
  jj: function (e) {
    var id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '../listdetail/listdetail?brandId=' + id,
      success: function (res) {
        // success
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
  },


  tian: function (e) {
    var id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '../works/works',
      success: function (res) {
        // success
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
  },
  //点击加载更多
  getMore: function (e) {
    var that = this;
    var page = that.data.page;
    wx.request({
      url: app.d.ceshiUrl + '/Api/Index/getlist',
      method: 'post',
      data: {
        page: page
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {

        var prolist = res.data.prolist;
        if (prolist == '') {
          wx.showToast({
            title: '没有更多数据！',
            duration: 2000
          });
          return false;
        }
        //that.initProductData(data);
        that.setData({
          page: page + 1,
          productData: that.data.productData.concat(prolist)
        });
        //endInitData
      },
      fail: function (e) {
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      }
    })
  },

  changeIndicatorDots: function (e) {
    this.setData({
      indicatorDots: !this.data.indicatorDots
    })
  },
  changeAutoplay: function (e) {
    this.setData({
      autoplay: !this.data.autoplay
    })
  },
  intervalChange: function (e) {
    this.setData({
      interval: e.detail.value
    })
  },
  durationChange: function (e) {
    this.setData({
      duration: e.detail.value
    })
  },

  onLoad: function (options) {





    var that = this;


    wx.request({
      url: app.d.ceshiUrl + '/Api/Category/getbrands', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.status == 1) {
          that.setData({
            nav: res.data.datalist
          })
        }
      }
    })





    setTimeout(function () {
      console.log(app.globalData.userInfo)
      console.log(app.d.userId)
      if (app.globalData.userInfo) {
        wx.request({
          url: app.d.ceshiUrl + '/Api/User/is_agency', //仅为示例，并非真实的接口地址
          data: {
            uid: app.d.userId
          },
          header: {
            'content-type': 'application/json' // 默认值
          },
          success: function (res) {
            console.log(res.data)
            if (res.data.status == 1) {
              if (res.data.agency == 1) {
                that.setData({
                  uc: true
                })
              } else {
                that.setData({
                  uc: false
                })
              }
            }
          }
        })
      }
    }, 1000)
    // if (app.globalData.userInfo){
    //   var fl = app.globalData.userInfo.agency 
    //   if (fl == '0') {
    //     that.setData({
    //       uc: false
    //     })
    //   } else if (fl == '1') {
    //     that.setData({
    //       uc: true
    //     })
    //   }
    // }






    wx.request({
      url: app.d.ceshiUrl + '/Api/Index/index',
      method: 'post',
      data: {
        page: 1,
        limit: 4
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        var ggtop = res.data.ggtop;
        var procat = res.data.procat;
        var prolist = res.data.prolist;
        var brand = res.data.brand;
        var course = res.data.course;
        //that.initProductData(data);
        that.setData({
          imgUrls: ggtop,
          proCat: procat,
          productData: prolist,
          brand: brand,
          course: course
        });
        //endInitData
      },
      fail: function (e) {
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      },
    })

  },
  mo: function () {
    var that = this;
    page_=1;
    this.setData({
      shu: 10000000
    })
    wx.request({
      url: app.d.ceshiUrl + '/Api/Index/index',
      method: 'post',
      data: {
        page: 1,
        limit: 4
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        var ggtop = res.data.ggtop;
        var procat = res.data.procat;
        var prolist = res.data.prolist;
        var brand = res.data.brand;
        var course = res.data.course;
        //that.initProductData(data);
        that.setData({
          imgUrls: ggtop,
          proCat: procat,
          productData: prolist,
          brand: brand,
          course: course
        });
        //endInitData
      },
      fail: function (e) {
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      },
    })
  },
  get_productData: function (e) {
    page_=1;
    this.setData({
      shu: e.target.dataset.index,
      b_id: e.target.dataset.id
    })
    var that = this;
    wx.request({
      url: app.d.ceshiUrl + '/Api/Product/lists',
      method: 'post',
      data: {
        brand_id: e.target.dataset.id,
        page: 1,
        limit: 4
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {

        console.log(res.data)
        if (res.data.status == 1) {
          that.setData({
            productData: res.data.pro
          })
        }
      },
      error: function (e) {
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      }
    });
  },
  add_car: function (e) {
    wx.showModal({
      title: '提示',
      content: '是否确认加入购物车',
      success: function (res) {
        if (res.confirm) {
          wx.request({
            url: app.d.ceshiUrl + '/Api/Shopping/add', //仅为示例，并非真实的接口地址
            data: {
              uid: app.d.userId,
              pid: e.target.dataset.id,
              num: 1
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success: function (res) {
              console.log(res.data)
            }
          })



        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })


  },
  onShow: function () {
    var that = this;

    setTimeout(function () {
      console.log(app.globalData.userInfo)
      console.log(app.d.userId)
      if (app.globalData.userInfo) {
        wx.request({
          url: app.d.ceshiUrl + '/Api/User/is_agency', //仅为示例，并非真实的接口地址
          data: {
            uid: app.d.userId
          },
          header: {
            'content-type': 'application/json' // 默认值
          },
          success: function (res) {
            console.log(res.data)
            if (res.data.status == 1) {
              if (res.data.agency == 1) {
                that.setData({
                  uc: true
                })
              } else {
                that.setData({
                  uc: false
                })
              }
            }
          }
        })
      }
    }, 1000)


  },
  onReachBottom: function () {
    var that = this;
    page_++
    wx.showLoading({
      title: '加载更多',
    })
    if (that.data.shu == 10000000) {
      wx.request({
        url: app.d.ceshiUrl + '/Api/Index/index',
        method: 'post',
        data: {
          page: page_,
          limit: limit_
        },
        header: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          wx.hideLoading();
          var prolist = res.data.prolist;
         
          //that.initProductData(data);
          that.setData({
            productData: that.data.productData.concat(prolist) 
          });
          //endInitData
        },
        fail: function (e) {
          wx.showToast({
            title: '网络异常！',
            duration: 2000
          });
        },
      })
    } else {
      wx.request({
        url: app.d.ceshiUrl + '/Api/Product/lists',
        method: 'post',
        data: {
          brand_id: that.data.b_id,
          page: page_,
          limit: limit_
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          wx.hideLoading();
          console.log(res.data)
          if (res.data.status == 1) {
            that.setData({
              productData: that.data.productData.concat(res.data.pro) 
            })
          }
        },
        error: function (e) {
          wx.showToast({
            title: '网络异常！',
            duration: 2000
          });
        }
      });







    }



  },
  onShareAppMessage: function () {
    return {
      title: '毅力汽配',
      path: '/pages/index/index',
      success: function (res) {
        // 分享成功
      },
      fail: function (res) {
        // 分享失败
      }
    }
  }



});