http://www.1884.net
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ly: [],
    yy: "",
    area_val: "",
    m1: "../../images/value_add.png",
    m2: "../../images/value_add.png",
    m3: "../../images/value_add.png",
    order_id: "",
    goods_id: "",
    p1: "",
    p2: "",
    p3: "",
    yy_arr: [],
    yy_id: "",
    key: "",
    name_:'',
    phone_:"",
    image_url:"",
    up_url:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {



  },
  get_area: function (e) {
    console.log(e.detail.value)
    this.setData({
      area_val: e.detail.value
    })

  },
  get_name:function(e){
    console.log(e.detail.value)
    this.setData({
      name_: e.detail.value
    })
  },
  get_phone: function (e) {
    console.log(e.detail.value)
    this.setData({
      phone_: e.detail.value
    })
  },

  submit_: function () {
    wx.showLoading({
      title: '提交中',
    })
    var that=this;
    if (that.data.name_==''){
      wx.showToast({
        title: '请填写姓名',
        icon: 'none',
        duration: 2000
      })
      return false
        }
 
    var pattern = /^((1[3,5,8][0-9])|(14[5,7])|(17[0,6,7,8])|(19[7]))\d{8}$/;
    if (!pattern.test(that.data.phone_) || that.data.mob_phone == "") {
      wx.showToast({
        title: '请填写有效的手机号',
        icon: 'none',
        duration: 2000
      })
      return false
    }

    if (that.data.up_url==''){
      wx.showToast({
        title: '请上传营业执照',
        icon: 'none',
        duration: 2000
      })
      return false

    }
    wx.request({
      url: app.d.ceshiUrl+'/Api/User/apply_agency', //仅为示例，并非真实的接口地址
      data: {
        uid: app.d.userId,
        realname: that.data.name_,
        mobile: that.data.phone_,
        license: that.data.up_url,
        message: that.data.area_val
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading()
        console.log(res.data)
            if(res.data.status==0){
              wx.showToast({
                title: res.data.err,
                icon: 'none',
                duration: 2000
              })
            } else if (res.data.status == 1){
              wx.showToast({
                title: '提交成功,等待审核',
                icon: 'none',
                duration: 2000
              })
            }
      }
    })








  
  },
  check_image1: function () {
    var that = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths[0]
        console.log(tempFilePaths)
        wx.uploadFile({
          url: app.d.ceshiUrl+'/Api/User/upload_images', //仅为示例，非真实的接口地址
          filePath: tempFilePaths,
          name: 'input_complain_pic1',
          method: "POST",
          success: function (res) {
            var data = res.data
            //do something
            that.setData({
              m1: tempFilePaths,
              up_url:JSON.parse(data).files[0]
            })
            console.log(JSON.parse(data))
            // console.log()
           
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})