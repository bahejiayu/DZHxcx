  var app = getApp();
  var http = app.globalData.http;
  var session_ = app.globalData.session;
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    h: "",
    show_left:false,
    is_login: false,
    user_info: {},
    longitude: '',
    latitude: '',
    order_list:[],
    kf_phone:''
  },
  phone_kf: function (e) {
    var that = this;
    console.log(123)
    wx.makePhoneCall({
      phoneNumber: that.data.kf_phone //仅为示例，并非真实的电话号码
    })
  },
  back_:function(){
      wx.navigateBack({
        delta:1
      })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  st: function (e) {
    this.setData({
      start_: e.touches[0].clientX
    })
    // console.log(e)
    // console.log(e.touches[0].clientX)
  },
  end: function (e) {
    var that = this;

    var jian = e.changedTouches[0].clientX - this.data.start_;


    if (jian < 0 && jian < -10) {
      that.setData({
        show_left: false
      })
    }


  },
  onLoad: function (options) {
    this.setData({
      kf_phone: wx.getStorageSync('kf_phone')
    })
    var that = this;
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        var latitude = res.latitude
        var longitude = res.longitude
        that.setData({
          longitude: longitude,
          latitude: latitude
        });
        wx.showLoading({
          title: '加载中',
        })
        setInterval(function(){
          that.get_order();
        },1000*30)
        console.log(longitude,latitude)
      },
      fail:function(){
        wx.showToast({
          title: '获取当前坐标失败',
          icon:'none'
        })
      }
    })









    if (wx.getStorageSync('token')) {
      that.setData({
        is_login: true,
        user_info: wx.getStorageSync('user_info')
      })

      // that.is_bind();
    } else {
      that.setData({
        is_login: false
      })
    }
    wx.getSystemInfo({
      success: function (e) {
        that.setData({
          h: e.statusBarHeight

        })
        console.log(e.statusBarHeight)
      }
    })
  },
  go_ge: function () {
    wx.navigateTo({
      url: '../../Customer/user_info/user_info',
    })
  },
  get_order:function(){
    var that=this;
    wx.request({
      url: http + '/hyapi/driver/polling', //仅为示例，并非真实的接口地址
      data: {
        common_param: JSON.stringify({
          lng: that.data.longitude,
          lat: that.data.latitude
        }),
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data)
        if (res.data.errcode == 0) {
          that.setData({
            order_list: res.data.data.new_orders
          })
        }else{
            wx.showToast({
              title: res.data.errmsg,
              icon:"none"
            })
          that.setData({
            order_list: []
          })
        }
      }
    })
  },
  jie_order:function(e){
    wx.showLoading({
      title: '接单中',
    })
    wx.request({
      url: http +'/hyapi/driver/recevieorder', //仅为示例，并非真实的接口地址
      data: {
        common_param:JSON.stringify({
          order_id: e.target.dataset.order_id
        }),
        token:wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if(res.data.errcode==0){
                wx.navigateTo({
                  url: '../dr_map/dr_map?order_id=' + e.target.dataset.order_id,
                })
        }else{
          wx.showToast({
            title: res.data.errmsg,
            icon:'none'
          })
        }
      }
    })
  },
  get_left:function(){
    var that=this;
      this.setData({
        show_left: !that.data.show_left
      })
  },
  hid_left:function(){
    this.setData({
      show_left:false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that=this;
          wx.getLocation({
            type: 'gcj02',
            success: function (res) {
              var latitude = res.latitude
              var longitude = res.longitude
              that.setData({
                longitude: longitude,
                latitude: latitude

              });
              wx.showLoading({
                title: '加载中',
              })
                that.get_order();

             
            },
            fail: function () {
              wx.showToast({
                title: '获取当前坐标失败',
                icon: 'none'
              })
            }
          })
          var that = this;
          wx.request({
            url: http + '/hyapi/passenger/getpersonal', //仅为示例，并非真实的接口地址
            data: {
              token: wx.getStorageSync('token')
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success: function (res) {
              console.log(res.data)
              if (res.data.errcode == 0) {
                that.setData({
                  person_info: res.data.data.user_tel
                })
              }
            }
          })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  login_: function (e) {
    var that = this;
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo']) {

          wx.login({
            success: function (res) {
              if (res.code) {
                //console.log(e.detail)
                wx.showLoading({
                  title: '正在登陆',
                })
                wx.request({
                  url: http + '/hyapi/user/wxminilogin', //仅为示例，并非真实的接口地址
                  data: {
                    common_param: JSON.stringify({
                      code: res.code,
                      userinfo: e.detail

                    }),
                    session: app.globalData.session
                  },
                  header: {
                    'content-type': 'application/json' // 默认值
                  },
                  success: function (res) {
                    console.log(res.data)
                    wx.hideLoading();
                    if (res.data.errcode == 0) {

                      wx.setStorageSync('token', res.data.data.token);
                      wx.setStorageSync('user_info', {
                        name: e.detail.userInfo.nickName,
                        img: e.detail.userInfo.avatarUrl
                      });
                      console.log(wx.getStorageSync('token'))
                      that.setData({
                        is_login: true,
                        user_info: wx.getStorageSync('user_info')
                      })


                    } else {
                      wx.showToast({
                        title: '登陆失败',
                        icon: 'none'
                      })

                    }
                  }
                })

              }
            }
          })


        }

      }
    })

  }
})