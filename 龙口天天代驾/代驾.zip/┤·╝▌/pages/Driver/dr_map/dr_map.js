  var app = getApp();
  var http = app.globalData.http;
  var session_ = app.globalData.session;
  var DzhMiniMap = require('../../../libs/dzhmap/DzhMiniMap.js');
  var PassengerMap = require('../../../libs/dzhmap/PassengerMap.js');
  var lx='';
  var deng_feng = '0';
  var deng_miao = '0';
  var deng_time;
  var order_no='';

Page({
  

  /**
   * 页面的初始数据
   */

  data: {
    b_txt:'',
    h: "",
    show_left: false,
    winWidth: '',
    winHeight: '',
    is_sq:false,
    longitude: '',
    latitude: '',
    ck_info:{},
    order_info:{},
    g_getorder:false,
    go_cker:false,
    hui:false,
    end_:false,
    show_end:false,
    order_id:'',
    map_height:''
  },
  cancel_order:function(){
    var that=this;
    wx.showModal({
      title: '提示',
      content: '是否确认取消该订单',
      success: function (res) {
        if (res.confirm) {
          wx.request({
            url: http + '/hyapi/driver/cancelorder', //仅为示例，并非真实的接口地址
            data: {
              common_param: JSON.stringify({
                order_id: that.data.order_id
              }),
              token: wx.getStorageSync('token')
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success: function (res) {
              console.log(res.data)
              if (res.data.errcode == 0) {
                wx.showToast({
                  title: '取消成功',
                })
                setTimeout(function(){
                    wx.navigateBack({
                      delta:1
                    })
                },1500)

              }
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  back_: function () {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    that.setData({
      order_id:options.order_id
    })
    
    this.mapCtx = wx.createMapContext('mappage_map');
    this.DzhMiniMap = new DzhMiniMap.DzhMiniMap(that, that.mapCtx);
    this.PassengerMap = new PassengerMap.PassengerMap(that, that.mapCtx);
    this.initSystemInfo();
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        var latitude = res.latitude
        var longitude = res.longitude
        that.setData({
          is_sq:true,
          longitude: longitude,
          latitude: latitude
        });
        wx.request({
          url: http + '/hyapi/driver/polling', //仅为示例，并非真实的接口地址
          data: {
            common_param: JSON.stringify({
              lng: that.data.longitude,
              lat: that.data.latitude,
              order_id: that.data.order_id
            }),
            token: wx.getStorageSync('token')
          },
          header: {
            'content-type': 'application/json' // 默认值
          },
          success: function (res) {
            wx.hideLoading();
            console.log(res.data);
            lx = res.data.data.navigate.polyline;
            if (res.data.errcode == 0) {
              order_no = res.data.data.order.out_trade_no;
              if (res.data.data.status_text == "司机已接单"){
                that.setData({
                  ck_info: res.data.data.navigate.passenger_info,
                  order_info: res.data.data.order,
                  g_getorder: true,
                  go_cker: true
                })
                that.setData({
                  longitude: res.data.data.order.origin_location.split(',')[0],
                  latitude: res.data.data.order.origin_location.split(',')[1]
                })
                // 在地图上绘制司机与乘客的位置

              var my_res=res;

              wx.getImageInfo({
                src: http + '/hyapi/user/avatar?src='+that.data.ck_info.wx_info.avatarUrl,
                success: function (res) {
      that.PassengerMap.getckerToPassenger(my_res, '../../../img/mapicon_navi_s.png', res.path, '', '', null, false);
                }
              })
   

              } else if (res.data.data.status_text == "司机已出发"){
                that.setData({
                  ck_info: res.data.data.navigate.passenger_info,
                  order_info: res.data.data.order,
                  g_getorder: true,
                  go_cker: false,
                  hui:true
                })
                that.setData({
                  longitude: res.data.data.order.origin_location.split(',')[0],
                  latitude: res.data.data.order.origin_location.split(',')[1]
                })
                // 在地图上绘制司机与乘客的位置
                var my_res = res;

                wx.getImageInfo({
                  src: http + '/hyapi/user/avatar?src=' + that.data.ck_info.wx_info.avatarUrl,
                  success: function (res) {
                    that.PassengerMap.getckerToPassenger(my_res, '../../../img/mapicon_navi_s.png', res.path, '', '', null, false);
                  }
                })
               
              } else if (res.data.data.status_text == "司机乘客已汇合"){
                  clearTimeout(deng_time);
              deng_feng = res.data.data.order.driver_wait.minute;
              deng_miao = res.data.data.order.driver_wait.second;

                    deng_time = setInterval(function () {
                deng_miao++;
                if (deng_miao == 60) {
                  deng_miao = 0;
                  deng_feng++;
                  deng_feng += '';
                }
                if (deng_miao < 10) {
                  deng_miao = '0' + deng_miao;
                }
                console.log(deng_feng.length)

                if (deng_feng < 10 && deng_feng+''.length == 1) {
                  deng_feng = '0' + deng_feng;
                }
                that.setData({
                  b_txt:'已等待乘客 '+deng_feng + ":" + deng_miao
                });
              }, 1000);
                that.setData({
                  ck_info: res.data.data.navigate.passenger_info,
                  order_info: res.data.data.order,
                  g_getorder: true,
                  go_cker: false,
                  hui: false,
                  start_:true
                })
                that.setData({
                  longitude: res.data.data.order.origin_location.split(',')[0],
                  latitude: res.data.data.order.origin_location.split(',')[1]
                })
                // 在地图上绘制起点终点
                var my_polyline = res.data.data.navigate.polyline;
                that.PassengerMap.drawOrginToDest(my_polyline, '../../../img/mapicon_navi_s.png', '../../../img/mapicon_navi_e.png', '', '', null, false);
              } else if (res.data.data.status_text == "开始行程") {
                that.setData({
                  ck_info: res.data.data.navigate.passenger_info,
                  order_info: res.data.data.order,
                  g_getorder: false,
                  end_: true
                })
                that.setData({
                  longitude: res.data.data.order.origin_location.split(',')[0],
                  latitude: res.data.data.order.origin_location.split(',')[1]
                })
                // 在地图上绘制司机与乘客的位置
                that.PassengerMap.newb(res.data.data.navigate.polyline, '../../../img/mapicon_navi_s.png', '../../../img/mapicon_navi_e.png', '', '', null, false);
              } else if (res.data.data.status_text == "结束行程"){
                that.setData({
                  ck_info: res.data.data.navigate.passenger_info,
                  order_info: res.data.data.order,
                  show_end:true
                })
                that.setData({
                  longitude: res.data.data.order.origin_location.split(',')[0],
                  latitude: res.data.data.order.origin_location.split(',')[1]
                })
                // 在地图上绘制司机与乘客的位置
                that.PassengerMap.drawOrginToDest(res.data.data.navigate.polyline, '../../../img/mapicon_navi_s.png', '../../../img/mapicon_navi_e.png', '', '', null, false);

              }
            }
          }
        })
      },
      fail:function(){
            that.setData({
              is_sq: false,
            })
      }
    })


    wx.getSystemInfo({
      success: function (e) {
        that.setData({
          h: e.statusBarHeight,
          map_height: e.windowHeight - e.statusBarHeight - 50
        })
        console.log(e.statusBarHeight)
      }
    })
  },
  phone_: function (e) {
    console.log(123)
    wx.makePhoneCall({
      phoneNumber: e.target.dataset.phone //仅为示例，并非真实的电话号码
    })
  },
  end_btn:function(){
    var that = this;
    
    wx.showModal({
      title: '提示',
      content: '请选择乘客支付方式',
      cancelText: '线下支付',
      confirmText: '微信支付',
      success: function (res) {
        wx.showLoading({
          title: '请稍等',
        });
        if (res.confirm) {
          wx.request({
            url: http + '/hyapi/driver/endoff', //仅为示例，并非真实的接口地址
            data: {
              common_param: JSON.stringify({
                order_id: that.data.order_id
              }),
              token: wx.getStorageSync('token')
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success: function (res) {
              console.log(res.data)
              wx.hideLoading();
              if (res.data.errcode == 0) {
                that.setData({
                  show_end: true
                })
              }
            }
          });
        } else if (res.cancel) {
          wx.showLoading({
            title: '请稍等',
          });
          wx.request({
            url: http + '/hyapi/order/pay', //仅为示例，并非真实的接口地址
            data: {
              common_param: JSON.stringify({
                out_trade_no: order_no,
                pay_type: 10,
                driver: 1
              }),
              token: wx.getStorageSync('token')
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success: function (res) {
              wx.hideLoading();
              console.log(res.data)
              if (res.data.errcode == 0) {
                that.setData({
                  show_end: true
                });
              } else {
                wx.showToast({
                  title: res.data.errmsg,
                  icon: 'none'
                })
              }
            }
          });
       
        }
      }
    })



 

  },
  again_:function(){
      wx.navigateBack({
        delta:1
      })
  },
  strat_btn:function(){
    var that = this;
    wx.showLoading({
      title: '请稍等',
    })
    wx.request({
      url: http + '/hyapi/driver/startoff', //仅为示例，并非真实的接口地址
      data: {
        common_param: JSON.stringify({
          order_id: that.data.order_id
        }),
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        wx.hideLoading();
        
        
        if (res.data.errcode == 0) {
          clearTimeout(deng_time);
          deng_feng = 0;
          deng_miao = 0;
          that.setData({
            g_getorder: false,
            end_: true,
            b_txt:''
          });
          that.PassengerMap.newb(lx, '../../../img/mapicon_navi_s.png', '../../../img/mapicon_navi_e.png', '', '', null, false);


        }
      }
    });



    wx.request({
      url: http + '/hyapi/driver/polling', //仅为示例，并非真实的接口地址
      data: {
        common_param: JSON.stringify({
          lng: that.data.longitude,
          lat: that.data.latitude,
          order_id: that.data.order_id
        }),
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data);
        lx = res.data.data.navigate.polyline;
        if (res.data.errcode == 0) {
          that.setData({
             order_info: res.data.data.order,
          })
        }
      }
    })











  },
  hui_:function(){
    var that = this;
    wx.showLoading({
      title: '请稍等',
    })
    wx.request({
      url: http + '/hyapi/driver/arriveorigin', //仅为示例，并非真实的接口地址
      data: {
        common_param: JSON.stringify({
          order_id: that.data.order_id
        }),
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        wx.hideLoading();
        
        if (res.data.errcode == 0) {
          that.setData({
            start_: true,
            hui: false
          });
          clearTimeout(deng_time);
          deng_feng = '0';
          deng_miao ='0';

          deng_time = setInterval(function () {
            deng_miao++;
            if (deng_miao == 60) {
              deng_miao = 0;
              deng_feng++;
              deng_feng += '';
            }
            if (deng_miao < 10) {
              deng_miao = '0' + deng_miao;
            }
            console.log(deng_feng.length)

            if (deng_feng < 10 && deng_feng + ''.length == 1) {
              deng_feng = '0' + deng_feng;
            }
            that.setData({
              b_txt: '已等待乘客 ' + deng_feng + ":" + deng_miao
            });
          }, 1000);

        }
      }
    })

  },
  go_cker_btn:function(){
    
      var that=this;
      wx.showLoading({
        title: '请稍等',
      })
      wx.request({
        url: http +'/hyapi/driver/gotopassenger', //仅为示例，并非真实的接口地址
        data: {
          common_param: JSON.stringify({
            order_id: that.data.order_id
          }),
          token:wx.getStorageSync('token')
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success: function (res) {
          console.log(res.data)
          wx.hideLoading();
          
          if(res.data.errcode==0){
            that.setData({
              go_cker: false,
              hui: true
            })

          }
        }
      })
  },
  initSystemInfo: function () {
    var that = this;

    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
  },
  get_left: function () {
    var that = this;
    this.setData({
      show_left: !that.data.show_left
    })
  },
  hid_left: function () {
    this.setData({
      show_left: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})