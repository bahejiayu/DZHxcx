//                    _ooOoo_
//                   o8888888o
//                   88" . "88
//                   (| -_- |)
//                   O\  =  /O
//                ____/`---'\____
//              .'  \\|     |//  `.
//             /  \\|||  :  |||//  \
//            /  _||||| -:- |||||-  \
//            |   | \\\  -  /// |   |
//            | \_|  ''\---/''  |   |
//            \  .-\__  `-`  ___/-. /
//          ___`. .'  /--.--\  `. . __
//       ."" '<  `.___\_<|>_/___.'  >'"".
//      | | :  `- \`.;`\ _ /`;.`/ - ` : | |
//      \  \ `-.   \_ __\ /__ _/   .-` /  /
// ======`-.____`-.___\_____/___.-`____.-'======
//                    `=---='
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//          佛祖保佑       永无BUG
//          佛曰:    
//                  写字楼里写字间，写字间里程序员；    
//                  程序人员写程序，又拿程序换酒钱。    
//                  酒醒只在网上坐，酒醉还来网下眠；    
//                  酒醉酒醒日复日，网上网下年复年。    
//                  但愿老死电脑间，不愿鞠躬老板前；    
//                  奔驰宝马贵者趣，公交自行程序员。    
//                  别人笑我忒疯癫，我笑自己命太贱；    
//                  不见满街漂亮妹，哪个归得程序员？



// *  ┏┓　　　┏┓
//   *┏┛┻━━━┛┻┓
//   *┃　　　　　　　┃ 　
//   *┃　　　━　　　┃
//   *┃　┳┛　┗┳　┃
//   *┃　　　　　　　┃
//   *┃　　　┻　　　┃
//   *┃　　　　　　　┃
//   *┗━┓　　　┏━┛
//   *　　┃　　　┃神兽保佑
// *　　┃　　　┃代码无BUG！
//   *　　┃　　　┗━━━┓
//   *　　┃　　　　　　　┣┓
//   *　　┃　　　　　　　┏┛
//   *　　┗┓┓┏━┳┓┏┛
//   *　　　┃┫┫　┃┫┫
//   *　　　┗┻┛　┗┻┛ 
//   *　　　
//   */
var DzhMiniMap = require('../../../libs/dzhmap/DzhMiniMap.js');
var PassengerMap = require('../../../libs/dzhmap/PassengerMap.js');
var app = getApp();
var http = app.globalData.http;
var session_ = app.globalData.session;
var my_time;
var deng_time;
var data_jw = '';
var now_feng = '0';
var now_miao = '0';
var deng_feng = '0';
var deng_miao = '0';
var order_no ='';
var step_1 = true;
var step_2 = true;
var step_3 = true;
var step_4 = true;
var step_5 = true;
var step_6 = true;
var one_ = true;
var dian_ = false;
var dyc = true;

Page({
  /**
   * 页面的初始数据
   */
  DzhMiniMap: null,
  PassengerMap: null,
  data: {
    is_sj: false,
    start_: 0,
    h: "",
    show_left: false,
    winWidth: '',
    winHeight: '',
    tog_s: true,
    d1: [],
    d2: [],
    d3: [],
    show_time: false,
    is_login: false,
    user_info: {},
    to_txt: '请输入目的地',
    fixed_map_marker_tip: '',
    order_money: '',
    f1: 0,
    f2: 0,
    f3: 0,
    center_address: '',
    // 下单后的倒计时
    show_dan: false,
    time_txt: '00:00',
    xiao_dan: false,
    show_time_cancel: false,
    // 司机接单后
    sj_get_order: false,
    // 司机信息
    driver_info: {},
    // 司机接单后取消订单
    get_order_cancel: false,
    no_fininsh: true,
    order_info: {},
    fk_btn: false,
    hui_btn: true,
    sq: true,
    cx_: false,
    kf_phone: '',
    person_info: "",
    quan: "",
    map_height: '',
    order_id: '',
    login_box: true,
    order_list:[],
    b_txt:"已接单请等待,司机到来..."
  },
  sq: function() {
    dian_ = true
  },
  go_ge: function() {
    wx.navigateTo({
      url: '../user_info/user_info',
    })
  },
  test: function() {
    if (wx.createInnerAudioContext) {
      var i = wx.createInnerAudioContext();
      i.autoplay = true;
      i.src = "/audio/s1.mp3";
      i.onPlay(function() {});
      //setTimeout(function () {
      //   i.destroy();
      // }, 4000);
    }
  },
  // 拨号
  phone_: function(e) {
    console.log(123)
    wx.makePhoneCall({
      phoneNumber: e.target.dataset.phone //仅为示例，并非真实的电话号码
    })
  },
  phone_kf: function(e) {
    var that = this;
    console.log(123)
    wx.makePhoneCall({
      phoneNumber: that.data.kf_phone //仅为示例，并非真实的电话号码
    })
  },
  // 司机接单后取消订单
  der_get_order_cancel: function() {
    this.setData({
      get_order_cancel: true
    })
  },
  st: function(e) {
    this.setData({
      start_: e.touches[0].clientX
    })
    // console.log(e)
    // console.log(e.touches[0].clientX);
  },
  end: function(e) {
    var that = this;

    var jian = e.changedTouches[0].clientX - this.data.start_;


    if (jian < 0 && jian < -10) {
      that.setData({
        show_left: false
      })
    }


  },
  cl_: function(e) {
    var that = this;
    if (e.target.dataset.s == 1) {
      that.setData({
        tog_s: true
      })
    } else {
      that.setData({
        tog_s: false
      })
    }
  },
  show_time: function() {
    this.setData({
      show_time: true
    })
  },
  get_left: function() {
    var that = this;
    this.setData({
      show_left: !that.data.show_left
    })
  },
  hid_left: function() {
    this.setData({
      show_left: false
    })
  },
  hidtime: function() {
    this.setData({
      show_time: false,
      order_money: false
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  back_center: function() {
    this.init();
  },
  go_mudi: function() {
    wx.navigateTo({
      url: '../destination/destination',
    })
  },
  go_cfd: function() {
    wx.navigateTo({
      url: '../search/search',
    })
  },
  onLoad: function(options) {
    var that = this;
    
    one_ = true;
    wx.removeStorageSync('form');
    // wx.removeStorageSync('to');
    setInterval(function(){
      wx.request({
        url: http + '/hyapi/driver/polling', //仅为示例，并非真实的接口地址
        data: {
          common_param: JSON.stringify({
            lng: that.data.longitude,
            lat: that.data.latitude
          }),
          token: wx.getStorageSync('token')
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success: function (res) {
          wx.hideLoading();
          console.log(res.data)
          if (res.data.errcode == 0) {
            that.setData({
              order_list: res.data.data.new_orders
            })
          } else {
           
            that.setData({
              order_list: []
            })
          };
         
          if(that.data.order_list.length!=0){
          
            if (wx.createInnerAudioContext) {
              var i = wx.createInnerAudioContext();
              i.autoplay = true;
              i.src = "/audio/s7.mp3";
              i.onPlay(function () { });
            

            }
            }





        }
      })

    },1000*30)
    
  setTimeout(function(){
    if (that.data.show_dan == false && that.data.sj_get_order == false && that.data.fk_btn == false) {
      wx.request({
        url: http + '/hyapi/driver/polling', //仅为示例，并非真实的接口地址
        data: {
          common_param: JSON.stringify({
            lng: that.data.longitude,
            lat: that.data.latitude
          }),
          token: wx.getStorageSync('token')
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success: function (res) {
          wx.hideLoading();
          console.log(res.data)
          if (res.data.errcode == 0) {
            that.setData({
              order_list: res.data.data.new_orders
            })
          } else {

            that.setData({
              order_list: []
            })
          };

          if (that.data.order_list.length != 0) {

            if (wx.createInnerAudioContext) {
              var i = wx.createInnerAudioContext();
              i.autoplay = true;
              i.src = "/audio/s7.mp3";
              i.onPlay(function () { });
            }
          }
        }
      })


    }

  },3000)
  








    if (!wx.getStorageSync('token')) {
      that.setData({
        login_box: false
      })
    }



    wx.request({
      url: http + '/hyapi/passenger/isdriver', //仅为示例，并非真实的接口地址
      data: {
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function(res) {
        console.log(res.data)

        if (res.data.errcode == 0 && res.data.data == 'Y') {
          that.setData({
            is_sj: true
          })
        } else {
          that.setData({
            is_sj: false
          })
        }
        if (res.data.errmsg == 'token验证失败') {
          wx.clearStorageSync();
          that.setData({
            is_login: false
          })
        }
      }
    });










    wx.request({
      url: http + '/hyapi/article/getarticledetail', //仅为示例，并非真实的接口地址
      data: {
        common_param: JSON.stringify({
          article_id: 169
        }),
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function(res) {
        if (res.data.errcode == 0) {
          that.setData({
            kf_phone: res.data.data.url
          });
          wx.setStorageSync('kf_phone', res.data.data.url);
        }
      }
    })
    that.get_status();
    wx.authorize({
      scope: 'scope.userLocation',
      success() {
        wx.getLocation({
          type: 'gcj02',
          success: function(res) {
            var latitude = res.latitude
            var longitude = res.longitude
            that.setData({
              longitude: longitude,
              latitude: latitude
            });
          },
        })
      },
      fail: function() {
        console.log(132)
        that.setData({
          sq: false
        })
      },
    })






    this.mapCtx = wx.createMapContext('mappage_map');
    var that = this;

    this.DzhMiniMap = new DzhMiniMap.DzhMiniMap(that, that.mapCtx);
    this.PassengerMap = new PassengerMap.PassengerMap(that, that.mapCtx);



    if (wx.getStorageSync('token')) {
      that.setData({
        is_login: true,
        user_info: wx.getStorageSync('user_info')
      })

      // that.is_bind();
    } else {
      that.setData({
        is_login: false
      })
    }
    var myDate = new Date();
    var my_date = [];
    var mj = myDate.getDate();
    for (var i = myDate.getMonth() + 1; i <= 12; i++) {
      for (var j = mj; j <= 31; j++) {
        if (i == 2 && j == 30) {
          continue;
        }
        if (i == 2 && j == 31) {
          continue;
        }

        if (i == 4 && j == 31) {
          continue;
        }
        if (i == 6 && j == 31) {
          continue;
        }
        if (i == 9 && j == 31) {
          continue;
        }
        if (i == 11 && j == 31) {
          continue;
        }
        mj = 1;
        my_date.push(i + "月" + j + "日");
      }
    }
    // console.log(my_date);
    this.setData({
      d1: my_date
    })

    var d2 = [];
    for (var i = 0; i <= 23; i++) {
      if (i < 10) {
        d2.push('0' + i + '点');
      } else {
        d2.push(i + '点');
      }

    }
    console.log(myDate.getHours());
    this.setData({
      d2: d2
    })
    // console.log(d2)

    var d3 = [];
    for (var i = 0; i <= 59; i += 5) {
      if (i < 10) {
        d3.push('0' + i + '分')
      } else {
        d3.push(i + '分')
      }

    }
    this.setData({
      d3: d3
    })



    this.initSystemInfo();
    var that = this;
    wx.getSystemInfo({

      success: function(e) {
        that.setData({
          h: e.statusBarHeight,
          map_height: e.windowHeight - e.statusBarHeight - 50
        })
        console.log(e.screenHeight)
      }
    })











    //add 2018-8-9
    //定时从服务器轮询数据
    //
    setInterval(function() {
      // that.simulation_driver();
      that.get_status();
    }, 1000 * 10);





    that.PassengerMap.init();

 

  },
  // /测试 模拟司机操作(正式上线时删掉)

  simulation_driver: function() {
    var out_trade_no = wx.getStorageSync('test_out_trade_no');
    if (out_trade_no) {
      var that = this;
      wx.request({
        url: http + "/hyapi/testdriver/polling",
        data: {
          common_param: JSON.stringify({
            out_trade_no: out_trade_no
          })
        },
        success: function(res) {
          if (res.data.errcode == 0) {}
        }
      })
    }
  },
  init: function() {
    var _this = this;
    wx.getLocation({
      type: 'gcj02',
      success: function(res) {
        var latitude = res.latitude
        var longitude = res.longitude
        //console.log(latitude, longitude)
        _this.setData({
          longitude: longitude,
          latitude: latitude
        });
        // console.log(_this._pageContext.data.longitude);
        // console.log(_this._pageContext.data.latitude);
      }
    })
  },
  get_status: function() {
    var that = this;
    wx.request({
      url: http + "/hyapi/passenger/polling",
      data: {
        common_param: JSON.stringify({
          //lng: "113.40079",
          //lat: "23.117508"
          out_trade_no: order_no
        }),
        token: wx.getStorageSync('token')
      },
      success: function(res) {
        if (res.data.errcode == 0) {
              if(!res.data.data){
                //显示附近司机
                that.PassengerMap.drawDriversLocation(http + "/hyapi/passenger/polling2", { token: wx.getStorageSync('token') });
              }


          if (res.data.data && res.data.data.status_text) {
            clearTimeout(deng_time);
            
            console.log(res.data)
            that.setData({
              order_id: res.data.data.order.order_id
            })
            if (one_ == true) {
              that.setData({
                show_dan: false,
                xiao_dan: true,
              });
            }
            // if (res.data.data.status_text == '待司机接单' && one_ == true) {
            //   that.setData({
            //     show_dan: true,
            //     xiao_dan: true
            //   })


            // }
            //  console.log(one_)

            if (res.data.data.status_text == '待司机接单' && one_ == true) {
              that.setData({
                b_txt: "已接单请等待,司机到来...",
                show_dan: true,
                xiao_dan: true
              });


              console.log(res.data.data.order.out_trade_no)
              one_ = false;
              clearTimeout(my_time);
              order_no = res.data.data.order.out_trade_no;

              now_feng = res.data.data.order.wait.minute + "";
              var lx = res.data.data.navigate.polyline;
              now_miao = res.data.data.order.wait.second;

              var get_url = res.data.data.navigate.polyline;

              wx.getImageInfo({
                src: http + '/hyapi/user/avatar?src=' + wx.getStorageSync('user_info').img,
                success: function(res) {

                  that.PassengerMap.drawOrginToDest(get_url, res.path, '../../../img/mapicon_navi_e.png');
                }
              })



              // order_no = res.data.data.out_trade_no;
              my_time = setInterval(function() {
                now_miao++;
                if (now_miao == 60) {
                  now_miao = 0;
                  now_feng++;
                  now_feng += '';
                }
                if (now_miao < 10) {
                  now_miao = '0' + now_miao;
                }
                if (now_feng < 10 && now_feng.length == 1) {
                  // console.log(123)
                  now_feng = '0' + now_feng;
                }
                that.setData({
                  time_txt: now_feng + ":" + now_miao
                })
                if (now_feng >= 3 && now_feng >= 0) {
                  clearTimeout(my_time);
                  wx.request({
                    url: http + '/hyapi/passenger/cancelorder',
                    data: {
                      common_param: JSON.stringify({
                        out_trade_no: order_no
                      }),
                      token: wx.getStorageSync('token')
                    },
                    success: function (res) {
                      wx.hideLoading();
                      if (res.data.errcode == 0) {
                        wx.showToast({
                          title: '取消成功',
                          icon: 'none'
                        });
                        clearInterval(my_time);
                        that.PassengerMap.clearMap();
                        now_feng = '0';
                        now_miao = '0';
                        that.setData({
                          show_time_cancel: false,
                          xiao_dan: false,
                          show_dan: false,
                          sj_get_order: false,
                          order_money: false,
                          time_txt: '00:00'
                        });
                        wx.showModal({
                          title: '提示',
                          content: '等待时间超过三分钟订单自动取消,请重新下单',
                          success: function (res) {
                            if (res.confirm) {
                              console.log('用户点击确定')
                            } else if (res.cancel) {
                              console.log('用户点击取消')
                            }
                          }
                        })
                      } else {
                        wx.showToast({
                          title: '取消失败',
                          icon: 'none'
                        })
                      }
                    }
                  })
                }
              }, 1000)

            } else if (res.data.data.status_text == '司机已接单') {
              that.setData({
                show_dan: false,
                xiao_dan: true,
                b_txt: "已接单请等待,司机到来...",
                
              });

              if (step_1) {
                if (wx.createInnerAudioContext) {
                  var i = wx.createInnerAudioContext();
                  i.autoplay = true;
                  i.src = "/audio/s1.mp3";
                  i.onPlay(function() {});
                  //setTimeout(function () {
                  //   i.destroy();
                  // }, 4000);
                  step_1 = false;

                }
              }





              clearInterval(my_time);
              now_feng = '0';
              now_miao = '0';
              that.setData({
                time_txt: '00:00'
              })
              // console.log(res.data.data.navigate.driver_info)
              that.setData({
                driver_info: res.data.data.navigate.driver_info,
                sj_get_order: true,
                order_info: res.data.data.order
              });
              order_no = res.data.data.order.out_trade_no;
              var img_url = '';
              var get_url = res.data.data.navigate.polyline;
              wx.getImageInfo({
                src: http + '/hyapi/user/avatar?src=' + wx.getStorageSync('user_info').img,
                success: function(res) {
                  // that.PassengerMap.drawOrginToDest(get_url, res.path, '../../../img/mapicon_navi_e.png');
                  that.PassengerMap.drawOrginToDest(get_url, res.path, '../../../img/mapicon_navi_e.png');
                }
              })


            } else if (res.data.data.status_text == '司机已出发') {
              that.setData({
                show_dan: false,
                xiao_dan: true,
                b_txt: "已接单请等待,司机到来...",
                
              });
              if (step_2) {
                if (wx.createInnerAudioContext) {
                  var i = wx.createInnerAudioContext();
                  i.autoplay = true;
                  i.src = "/audio/s2.mp3";
                  i.onPlay(function() {});
                  //setTimeout(function () {
                  //   i.destroy();
                  // }, 4000);
                  step_2 = false;

                }
              }


              // 1.乘客的图片
              // 2.司机的图片
              // 3.出发地
              // 4.目的地
              that.setData({
                driver_info: res.data.data.navigate.driver_info,
                sj_get_order: true,
                order_info: res.data.data.order,
              })
              order_no = res.data.data.order.out_trade_no;
              var my_res = res;
              var zjy_img = '';
              var ck_img = '';
              wx.getImageInfo({
                src: http + '/hyapi/user/avatar?src=' + that.data.driver_info.wx_info.avatarUrl,
                success: function(res) {

                  zjy_img = res.path;
                  wx.getImageInfo({
                    src: http + '/hyapi/user/avatar?src=' + wx.getStorageSync('user_info').img,
                    success: function(res) {
                      // ck_img=res.path;
                      that.PassengerMap.getDriverToPassenger(my_res, res.path, zjy_img, '../../../img/mapicon_navi_s.png', '../../../img/mapicon_navi_e.png');

                    }
                  })
                }
              })

              //未到达
              //画出司机到乘客线路



            } else if (res.data.data.status_text == '司机乘客已汇合') {
              that.setData({
                show_dan: false,
                xiao_dan: true,
                // b_txt: '司机到达出发地正在等待您'
              });
              if (step_3) {
                if (wx.createInnerAudioContext) {
                  var i = wx.createInnerAudioContext();
                  i.autoplay = true;
                  i.src = "/audio/s3.mp3";
                  i.onPlay(function() {});
                
                  step_3 = false;

                }
              }
              that.setData({
                driver_info: res.data.data.navigate.driver_info,
                sj_get_order: true,
                order_info: res.data.data.order,
              })
              order_no = res.data.data.order.out_trade_no;
              var my_res = res;
              var get_url = res.data.data.navigate.polyline;

              wx.getImageInfo({
                src: http + '/hyapi/user/avatar?src=' + wx.getStorageSync('user_info').img,
                success: function(res) {

                  that.PassengerMap.drawOrginToDest(get_url, res.path, '../../../img/mapicon_navi_e.png');
                }
              });



              clearTimeout(deng_time);
              deng_feng = res.data.data.order.driver_wait.minute;
              deng_miao = res.data.data.order.driver_wait.second;


              deng_time = setInterval(function () {
                deng_miao++;
                if (deng_miao == 60) {
                  deng_miao = 0;
                  deng_feng++;
                  deng_feng += '';
                }
                if (deng_miao < 10) {
                  deng_miao = '0' + deng_miao;
                }
                console.log(deng_feng.length)

                if (deng_feng < 10 && deng_feng.length == 1) {
                  deng_feng = '0' + deng_feng;
                }
                that.setData({
                  b_txt:'司机到达出发地已等待 '+deng_feng + ":" + deng_miao
                });
              }, 1000)







            } else if (res.data.data.status_text == '开始行程') {
              that.setData({
                show_dan: false,
                xiao_dan: true,
                b_txt: "已接单请等待,司机到来...",
                
              });

              if (step_4) {
                if (wx.createInnerAudioContext) {
                  var i = wx.createInnerAudioContext();
                  i.autoplay = true;
                  i.src = "/audio/s4.mp3";
                  i.onPlay(function() {});
                  //setTimeout(function () {
                  //   i.destroy();
                  // }, 4000);
                  step_4 = false;

                }
              }

              that.setData({
                fk_btn: true,
                sj_get_order: false
              })
              that.setData({
                driver_info: res.data.data.navigate.driver_info,
                // sj_get_order: true,
                order_info: res.data.data.order,
              })
              order_no = res.data.data.order.out_trade_no;
              var my_res = res;
              var get_url = res.data.data.navigate.polyline;

              wx.getImageInfo({
                src: http + '/hyapi/user/avatar?src=' + wx.getStorageSync('user_info').img,
                success: function(res) {

                  that.PassengerMap.drawOrginToDest(get_url, res.path, '../../../img/mapicon_navi_e.png');
                }
              })
            } else if (res.data.data.status_text == '结束行程') {
              that.setData({
                show_dan: false,
                xiao_dan: true,
                b_txt: "已接单请等待,司机到来...",
                
              });
              if (step_5) {
                if (wx.createInnerAudioContext) {
                  var i = wx.createInnerAudioContext();
                  i.autoplay = true;
                  i.src = "/audio/s5.mp3";
                  i.onPlay(function() {});
                  //setTimeout(function () {
                  //   i.destroy();
                  // }, 4000);
                  step_5 = false;

                }
              }

              that.setData({
                driver_info: res.data.data.navigate.driver_info,
                order_info: res.data.data.order,
                hui_btn: false,
                fk_btn: true,
                sj_get_order: false
              })
              order_no = res.data.data.order.out_trade_no;
              var get_url = res.data.data.navigate.polyline;

              wx.getImageInfo({
                src: http + '/hyapi/user/avatar?src=' + wx.getStorageSync('user_info').img,
                success: function(res) {
                  that.PassengerMap.drawOrginToDest(get_url, res.path, '../../../img/mapicon_navi_e.png');
                }
              })

            } else if (res.data.data.status_text == '已关闭') {

              that.setData({
                show_dan: false,
                xiao_dan: true,
                b_txt: "已接单请等待,司机到来...",
                
              });
              if (step_6) {
                if (wx.createInnerAudioContext) {
                  var i = wx.createInnerAudioContext();
                  i.autoplay = true;
                  i.src = "/audio/s6.mp3";
                  i.onPlay(function() {});
                  //setTimeout(function () {
                  //   i.destroy();
                  // }, 4000);
                  step_6 = false;

                }
              }
              order_no = '';
              that.setData({
                cx_: true
              })
            }
          }
        }
      }
    })

  },
  cx_dan: function() {
    clearTimeout(deng_time);
    wx.redirectTo({
      url: '../index/index'
    })
  },
  regionchange: function(e) {

    // console.log(dyc)

    var that = this;
    if (dyc == true) {
      setTimeout(function() {
        if (that.data.xiao_dan == false) {
          that.PassengerMap.getCenterAddress(http + "/hyapi/map/getaddress", e.type, function(addr, lng, lat) {
            data_jw = lng + ',' + lat;
            console.log('1',data_jw);
              // that.setData({
              //   longitude:lng,
              //   latitude:lat
              // })
          });
        }
      }, 2000)
      dyc = false;
    } else {

      if (that.data.xiao_dan == false) {
        that.PassengerMap.getCenterAddress(http + "/hyapi/map/getaddress", e.type, function(addr, lng, lat) {
          data_jw = lng + ',' + lat;
          console.log('2',data_jw);
          // that.setData({
          //   longitude: lng,
          //   latitude: lat
          // })
        });
      }
    }

    // console.log(dyc)
    //     if(dyc==true){
    //         console.log('go')
    //       if (that.data.xiao_dan == false) {
    //         dyc=false;
    //         that.PassengerMap.getCenterAddress(http + "/hyapi/map/getaddress", e.type, function (addr, lng, lat) {

    //           data_jw = lng + ',' + lat;
    //           dyc=true
    //           console.log('aa')
    //         });
    //       }

    //     }



  },
  again_de: function() {
    this.setData({
      get_order_cancel: false
    })
  },
  dan_: function() {
    var that = this;
    if (!wx.getStorageSync('token')) {
      wx.showToast({
        title: '请登陆',
        icon: 'none'
      })
      that.setData({
        show_left: true
      })
      return false
    }

    if (that.data.person_info == '' && !wx.getStorageSync('person_info')) {
      wx.navigateTo({
        url: '../phone/phone?b=123',
      });
      return false;
    }



    if (that.data.to_txt == "请输入目的地") {
      wx.showToast({
        title: '请输入目的地',
        icon: 'none'
      })
      return false;
    }

    var that = this;
    console.log(that.data.fixed_map_marker_tip)
    // 目的地
    if (wx.getStorageSync('to')) {
      var txt_arr = wx.getStorageSync('to').split('*');
      console.log(txt_arr);
      that.setData({
        to_txt: txt_arr[1] + " " + txt_arr[0]
      })
      that.PassengerMap.getCenterAddress(http + "/hyapi/map/getaddress", "", function(addr) {

        //return; //test

        /*
        that.setData({
          fixed_map_marker_tip: addr
        })
        */

        console.log(addr);
        wx.showLoading({
          title: '正在计算价格',
        })
        wx.request({
          url: http + '/hyapi/order/paymentorder',
          data: {
            common_param: JSON.stringify({
              skus: "1:1",
              coupon_id: 0,
              order_type: 1,
              origin_address: that.data.fixed_map_marker_tip,
              dest_address: that.data.to_txt,
              origin_location: data_jw,
              dest_location: txt_arr[2],
              appointment_time: ''
            }),
            token: wx.getStorageSync('token')
          },
          success: function(res) {
            wx.hideLoading();
            console.log(res.data)

            if (res.data.errcode == 0) {
              that.setData({
                order_money: res.data.data.pay_money,
                quan: res.data.data.coupon_money
              })
            } else {
              wx.showToast({
                title: res.data.errmsg,
                icon: 'none'
              })
              return false;
            }
            wx.showModal({
              title: '提示',
              content: '预算金额为' + that.data.order_money + '元,是否确认下单',
              success: function(res) {
                if (res.confirm) {
                  if (wx.getStorageSync('to')) {
                    wx.showLoading({
                      title: '正在生成订单',
                    })
                    var txt_arr = wx.getStorageSync('to').split('*');
                    console.log(txt_arr);
                    that.setData({
                      to_txt: txt_arr[1] + " " + txt_arr[0]
                    })
                    that.PassengerMap.getCenterAddress(http + "/hyapi/map/getaddress", "", function(addr) {

                      //return; //test

                      /*
                      that.setData({
                        fixed_map_marker_tip: addr
                      })
                      */

                      console.log(addr);
                      wx.request({
                        url: http + '/hyapi/order/paymentorder',
                        data: {
                          common_param: JSON.stringify({
                            skus: "1:1",
                            coupon_id: 0,
                            order_type: 1,
                            origin_address: that.data.fixed_map_marker_tip,
                            dest_address: that.data.to_txt,
                            origin_location: data_jw,
                            dest_location: txt_arr[2],
                            appointment_time: ''
                          }),
                          token: wx.getStorageSync('token')
                        },
                        success: function(res) {
                          console.log(res.data)
                          if (res.data.errcode == 0) {
                            wx.request({
                              url: http + '/hyapi/order/create',
                              data: {
                                token: wx.getStorageSync('token')
                              },
                              success: function(res) {
                                wx.hideLoading();
                                that.setData({
                                  show_time: false
                                })
                                if (res.data.errcode == 0) {
                                  step_1 = true;
                                  step_2 = true;
                                  step_3 = true;
                                  step_4 = true;
                                  step_5 = true;
                                  step_6 = true;
                                  one_ = false;

                                  console.log(res.data)
                                  wx.showToast({
                                    title: '成功生成订单',
                                  })

                                  var get_url = res.data.data.polyline;

                                  wx.getImageInfo({
                                    src: http + '/hyapi/user/avatar?src=' + wx.getStorageSync('user_info').img,
                                    success: function(res) {

                                      that.PassengerMap.drawOrginToDest(get_url, res.path, '../../../img/mapicon_navi_e.png');
                                    }
                                  })
                                  that.setData({
                                    show_dan: true,
                                    xiao_dan: true
                                  })
                                  order_no = res.data.data.out_trade_no;
                                  wx.setStorageSync('test_out_trade_no', order_no);

                                  var now_shi = 0;
                                  clearTimeout(my_time);
                                  my_time = setInterval(function() {
                                    now_miao++;
                                    if (now_miao == 60) {
                                      now_miao = 0;
                                      now_feng++;
                                      now_feng += '';
                                    }
                                    if (now_miao < 10) {
                                      now_miao = '0' + now_miao;
                                    }
                                    console.log(now_feng.length)

                                    if (now_feng < 10 && now_feng.length == 1) {
                                      now_feng = '0' + now_feng;
                                    }
                                    that.setData({
                                      time_txt: now_feng + ":" + now_miao
                                    });
                                     
                                    if (now_feng >= 3 && now_feng >= 0) {
                                      clearTimeout(my_time);
                                   
                                      wx.request({
                                        url: http + '/hyapi/passenger/cancelorder',
                                        data: {
                                          common_param: JSON.stringify({
                                            out_trade_no: order_no
                                          }),
                                          token: wx.getStorageSync('token')
                                        },
                                        success: function (res) {
                                          wx.hideLoading();
                                          if (res.data.errcode == 0) {
                                            wx.showToast({
                                              title: '取消成功',
                                              icon: 'none'
                                            });
                                            clearInterval(my_time);
                                            that.PassengerMap.clearMap();
                                            now_feng = '0';
                                            now_miao = '0';
                                            that.setData({
                                              show_time_cancel: false,
                                              xiao_dan: false,
                                              show_dan: false,
                                              sj_get_order: false,
                                              order_money: false,
                                              time_txt: '00:00'
                                            });
                                            wx.showModal({
                                              title: '提示',
                                              content: '等待时间超过三分钟订单自动取消,请重新下单',
                                              success: function (res) {
                                                if (res.confirm) {
                                                  console.log('用户点击确定')
                                                } else if (res.cancel) {
                                                  console.log('用户点击取消')
                                                }
                                              }
                                            })
                                          }else{
                                            wx.showToast({
                                              title: '取消失败',
                                              icon: 'none'
                                            })
                                          }
                                        }
                                      })
                                    }
                                    
                                  }, 1000)
                                } else {
                                  wx.showToast({
                                    title: '订单生成失败',
                                    icon: "none"
                                  })
                                }
                              }
                            })
                          }
                        }
                      })
                    });
                  }
                } else if (res.cancel) {
                  console.log('用户点击取消')
                  that.setData({
                    order_money: false
                  })
                }
              }
            })
          }
        })
      });
    } else {

      wx.showToast({
        title: '下单失败',
        icon: 'none'
      })
    }
  },
  initSystemInfo: function() {
    var that = this;
    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight - that.data.h
        });
      }
    });
  },
  bindChange: function(e) {
    // console.log(e.detail);
    this.setData({
      f1: e.detail.value[0],
      f2: e.detail.value[1],
      f3: e.detail.value[2]
    })


  },
  sure_time: function() {
    var that = this;
    wx.showLoading({
      title: '正在生成订单',
    })

    console.log(that.data.d1[that.data.f1]);
    console.log(that.data.d2[that.data.f2]);
    console.log(that.data.d3[that.data.f3]);
    if (wx.getStorageSync('to')) {
      var txt_arr = wx.getStorageSync('to').split('*');
      console.log(txt_arr);
      that.setData({
        to_txt: txt_arr[1] + " " + txt_arr[0]
      })
      that.PassengerMap.getCenterAddress(http + "/hyapi/map/getaddress", "", function(addr) {


        //return; //test


        /*
        that.setData({
          center_address: addr
        })
        */

        console.log(addr);
        wx.request({
          url: http + '/hyapi/order/paymentorder',
          data: {
            common_param: JSON.stringify({
              skus: "1:1",
              coupon_id: 0,
              order_type: 1,
              origin_address: that.data.fixed_map_marker_tip,
              dest_address: that.data.to_txt,
              origin_location: data_jw,
              dest_location: txt_arr[2],
              appointment_time: that.data.d1[that.data.f1] + "," + that.data.d2[that.data.f2] + "," + that.data.d3[that.data.f3]
            }),
            token: wx.getStorageSync('token')
          },
          success: function(res) {

            if (res.data.errcode == 0) {
              wx.request({
                url: http + '/hyapi/order/create',
                data: {
                  token: wx.getStorageSync('token')
                },
                success: function(res) {
                  wx.hideLoading();
                  that.setData({
                    show_time: false
                  })
                  if (res.data.errcode == 0) {
                    wx.showToast({
                      title: '成功生成订单',
                    })
                    step_1 = true;
                    step_2 = true;
                    step_3 = true;
                    step_4 = true;
                    step_5 = true;
                    step_6 = true;
                    one_ = false;


                    var get_url = res.data.data.polyline;

                    wx.getImageInfo({
                      src: http + '/hyapi/user/avatar?src=' + wx.getStorageSync('user_info').img,
                      success: function(res) {

                        that.PassengerMap.drawOrginToDest(get_url, res.path, '../../../img/mapicon_navi_e.png');
                      }
                    })
                    that.setData({
                      show_dan: true,
                      xiao_dan: true
                    });
                    order_no = res.data.data.out_trade_no;
                    wx.setStorageSync('test_out_trade_no', order_no);
                    var now_shi = 0;

                    my_time = setInterval(function() {
                      now_miao++;
                      if (now_miao == 60) {
                        now_miao = 0;
                        now_feng++;
                        now_feng += '';
                      }
                      if (now_miao < 10) {
                        now_miao = '0' + now_miao;
                      }
                      // console.log(now_feng.length)

                      if (now_feng < 10 && now_feng.length == 1) {
                        now_feng = '0' + now_feng;
                      }
                      that.setData({
                        time_txt: now_feng + ":" + now_miao
                      })

                    }, 1000)
                  } else {
                    wx.showToast({
                      title: '订单生成失败',
                      icon: "none"
                    })
                  }
                }
              })
            }
          }
        })
      });
    }


  },
  // 倒机时取消订单
  cancel_order: function() {
    this.setData({
      show_time_cancel: true
    })
  },
  // 取消倒计时等待
  can_wait: function() {
    console.log(order_no)
    var that = this;
    wx.showLoading({
      title: '取消中',
    })
    wx.request({
      url: http + '/hyapi/passenger/cancelorder',
      data: {
        common_param: JSON.stringify({
          out_trade_no: order_no
        }),
        token: wx.getStorageSync('token')
      },
      success: function(res) {
        wx.hideLoading();
        if (res.data.errcode == 0) {

          wx.showToast({
            title: '取消成功',
            icon: 'none'
          });
          clearInterval(my_time);
          clearTimeout(deng_time);
          
          that.PassengerMap.clearMap();
          now_feng = '0';
          now_miao = '0';
          that.setData({
            show_time_cancel: false,
            xiao_dan: false,
            show_dan: false,
            sj_get_order: false,
            order_money: false,
            time_txt: '00:00',
            
          });




        } else {
          wx.showToast({
            title: '取消失败',
            icon: 'none'
          })
        }
      }
    })
  },
  // 司机接单后取消订单
  de_wait: function() {
    var that = this;
    wx.request({
      url: http + '/hyapi/passenger/cancelorder',
      data: {
        common_param: JSON.stringify({
          out_trade_no: order_no
        }),
        token: wx.getStorageSync('token')
      },
      success: function(res) {
        if (res.data.errcode == 0) {
          wx.showToast({
            title: '取消成功',
            icon: 'none'
          });
          that.PassengerMap.clearMap();
          that.setData({
            xiao_dan: false,
            show_dan: false,
            sj_get_order: false,
            get_order_cancel: false,
            order_money: false

          });
          now_feng = '0';
          now_miao = '0';


        } else {
          wx.showToast({
            title: '取消失败',
            icon: 'none'
          })
        }
      }
    })
  },
  pay_: function() {
    var that = this;
    wx.showLoading({
      title: '请稍等',
    })
    wx.request({
      url: http + '/hyapi/order/pay', //仅为示例，并非真实的接口地址
      data: {
        common_param: JSON.stringify({
          out_trade_no: order_no,
        }),
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data)
        if (res.data.errcode == 0) {
          wx.requestPayment({
            'timeStamp': res.data.data.timeStamp,
            'nonceStr': res.data.data.nonceStr,
            'package': res.data.data.package,
            'signType': res.data.data.signType,
            'paySign': res.data.data.paySign,
            'success': function (res) {
              that.PassengerMap.clearMap();
              that.setData({
                xiao_dan: false,
                show_dan: false,
                sj_get_order: false,
                get_order_cancel: false,
                fk_btn: false,
                order_money: false
              });
              wx.showToast({
                title: '付款成功',
                icon: 'none'
              })
            },
            'fail': function (res) { }
          })
        } else {
          wx.showToast({
            title: '发起支付失败',
            icon: 'none'
          })
        }
      }
    });
    // wx.showModal({
    //   title: '提示',
    //   content: '请选择支付发送',
    //   cancelText: '线下支付',
    //   confirmText: '微信支付',
    //   success: function(res) {
    //     if (res.confirm) {
      
    //     } else if (res.cancel) {
    //       wx.request({
    //         url: http + '/hyapi/order/pay', //仅为示例，并非真实的接口地址
    //         data: {
    //           common_param: JSON.stringify({
    //             out_trade_no: order_no,
    //             pay_type:10
    //           }),
    //           token: wx.getStorageSync('token')
    //         },
    //         header: {
    //           'content-type': 'application/json' // 默认值
    //         },
    //         success: function (res) {
    //           wx.hideLoading();
    //           console.log(res.data)
    //           if (res.data.errcode == 0) {
    //             that.PassengerMap.clearMap();
    //             that.setData({
    //               xiao_dan: false,
    //               show_dan: false,
    //               sj_get_order: false,
    //               get_order_cancel: false,
    //               fk_btn: false,
    //               order_money: false
    //             });
    //             wx.showToast({
    //               title: '完成',
                
    //             })
    //           }else{
    //             wx.showToast({
    //               title: '发起支付失败',
    //               icon: 'none'
    //             })
    //           }
    //         }
    //       });
    //     }
    //   }
    // })


  },
  again_wait: function() {
    this.setData({
      show_time_cancel: false,
    })
  },
  get_left: function() {
    var that = this;
    this.setData({
      show_left: !that.data.show_left
    })
  },
  hid_left: function() {
    this.setData({
      show_left: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var jw;
    // 出发地
    var that = this;
    // that.setData({
    //   show_left: false
    // })

    if (wx.getStorageSync('form')) {

      // console.log(options.from)
      var form_arr = wx.getStorageSync('form').split('*')[2];
      var form_txt = wx.getStorageSync('form').split('*');
      console.log(form_arr);
      jw = form_arr.split(',');
      that.setData({
        longitude: jw[0],
        latitude: jw[1],
        fixed_map_marker_tip: form_txt[1] + " " + form_txt[0]
      })
      data_jw = jw[0] + ',' + jw[1];


    }


    if (wx.getStorageSync('to')) {
      var txt_arr = wx.getStorageSync('to').split('*');
      console.log(txt_arr);
      that.setData({
        to_txt: txt_arr[1] + " " + txt_arr[0]
      })
    }

    if (dian_) {
      wx.getSetting({
        success(res) {
          if (!res.authSetting['scope.userLocation']) {
            console.log('未授权')
          } else {
            console.log('授权');
            that.setData({
              sq: true
            })
            wx.getLocation({
              type: 'gcj02',
              success: function(res) {

                var latitude = res.latitude
                var longitude = res.longitude
                that.setData({
                  longitude: longitude,
                  latitude: latitude
                });

              },
            })
          }
        }
      });
      dian_ = false;
    }





    var that = this;
    wx.request({
      url: http + '/hyapi/passenger/getpersonal', //仅为示例，并非真实的接口地址
      data: {
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function(res) {
        console.log(res.data);
        if (res.data.errcode == 0) {
          that.setData({
            person_info: res.data.data.user_tel
          })
          wx.setStorageSync('person_info', res.data.data.user_tel)
        } else {
          if (res.data.errmsg == 'token验证失败' || '用户未登录') {
            wx.clearStorageSync();
            // wx.hideToast('请登陆')
            wx.showToast({
              title: '请登陆',
              icon: 'none'
            })
          }
        }
      }
    })
    wx.request({
      url: http + '/hyapi/passenger/isdriver', //仅为示例，并非真实的接口地址
      data: {
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function(res) {
        console.log(res.data)

        if (res.data.errcode == 0 && res.data.data == 'Y') {
          that.setData({
            is_sj: true
          })
        } else {
          that.setData({
            is_sj: false
          })
        }

      }
    })











  },




  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  login_: function(e) {
    var that = this;
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo']) {
          wx.login({
            success: function(res) {
              if (res.code) {
                //console.log(e.detail)
                wx.showLoading({
                  title: '正在登陆',
                })
                wx.request({
                  url: http + '/hyapi/user/wxminilogin', //仅为示例，并非真实的接口地址
                  data: {
                    common_param: JSON.stringify({
                      code: res.code,
                      userinfo: e.detail
                    }),
                    session: app.globalData.session
                  },
                  header: {
                    'content-type': 'application/json' // 默认值
                  },
                  success: function(res) {
                    console.log(res.data)
                    wx.hideLoading();
                    if (res.data.errcode == 0) {
                      wx.setStorageSync('token', res.data.data.token);
                      wx.setStorageSync('user_info', {
                        name: e.detail.userInfo.nickName,
                        img: e.detail.userInfo.avatarUrl
                      });
                      console.log(wx.getStorageSync('token'))
                      that.setData({
                        is_login: true,
                        user_info: wx.getStorageSync('user_info'),
                        show_left: false,
                        login_box: true
                      })



                      wx.request({
                        url: http + '/hyapi/passenger/isdriver', //仅为示例，并非真实的接口地址
                        data: {
                          token: wx.getStorageSync('token')
                        },
                        header: {
                          'content-type': 'application/json' // 默认值
                        },
                        success: function(res) {
                          console.log(res.data)

                          if (res.data.errcode == 0 && res.data.data == 'Y') {
                            that.setData({
                              is_sj: true
                            })
                          } else {
                            that.setData({
                              is_sj: false
                            })
                            if (res.data.errmsg == 'token验证失败') {
                              wx.clearStorageSync();
                              that.setData({
                                is_login: false
                              })
                            }
                          }
                        }
                      })











                    } else {
                      wx.showToast({
                        title: '登陆失败',
                        icon: 'none'
                      })
                    }
                  }
                })
              }
            }
          })
        }
      }
    })
  }
})