var app = getApp();
var http = app.globalData.http;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    h: "",
    show_left: false,
    longitude: '',
    latitude: "",
    des_address: '',
    address_list: [],
    ad1: null,
    ad2: null,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    wx.getSystemInfo({
      success: function(e) {
        that.setData({
          h: e.statusBarHeight

        })
        console.log(e.statusBarHeight)
      }
    })
    // 获取用户当前位置


    wx.getLocation({
      type: 'gcj02',
      success: function(res) {
        var latitude = res.latitude
        var longitude = res.longitude
        //console.log(latitude, longitude)
        that.setData({
          longitude: longitude,
          latitude: latitude
        });
      }
    })



  },
  // 获取用户输入的目的地
  get_address: function(e) {
    this.setData({
      des_address: e.detail.value
    });

    var that=this;
    wx.request({
      url: http + '/hyapi/map/getinputtip',
      data: {
        common_param: JSON.stringify({
          keywords: that.data.des_address,
          location: that.data.longitude + "," + that.data.latitude
        })
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data.status)
        if (res.data.errcode == 0 && res.data.data.status == 1) {
          that.setData({
            address_list: res.data.data.tips
          })
          console.log(that.data.address_list)
        }
      }
    });
    if(that.data.des_address==''){
            console.log(123)
            that.setData({
              address_list:[]
            })
      }
  },
  // 搜索
  search_: function() {
    var that = this;
    if (that.data.des_address == '') {
      wx.showToast({
        title: '请输入目的地',
        icon: 'none'
      })
      return false;
    }
    wx.showLoading({
      title: '搜索中',
    })
    wx.request({
      url: http + '/hyapi/map/getinputtip',
      data: {
        common_param: JSON.stringify({
          keywords: that.data.des_address,
          location: that.data.longitude + "," + that.data.latitude
          //location:'121.461891,37.470956'
          
        })
      },
      success: function(res) {
        wx.hideLoading();
        console.log(res.data.status)
        if (res.data.errcode == 0 && res.data.data.status==1) {
          that.setData({
            address_list: res.data.data.tips
          })
          console.log(that.data.address_list)
        } else {
            wx.showToast({
              title: '抱歉,没有找到相关的地址',
              icon:'none'
            })

        }
      }
    })


  },
  to_index:function(e){
    // wx.redirectTo({
    //   url: '../index/index?to='+e.target.dataset.obj
    // })

    wx.setStorageSync('to', e.target.dataset.obj);
    wx.navigateBack({
      delta:1
    })


  },
  back_: function() {
    wx.navigateBack({
      delta: 1
    })
  },
  get_left: function() {
    var that = this;
    this.setData({
      show_left: !that.data.show_left
    })
  },
  hid_left: function() {
    this.setData({
      show_left: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: http + '/hyapi/passenger/getaddress1', //仅为示例，并非真实的接口地址
      data: {
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.errcode == 0 && res.data.data) {
          res.data.data.address = res.data.data.detail.split('*')[0];

          that.setData({
            ad1: res.data.data
          })
        } else {
          that.setData({
            ad1: null
          })
        }
      }
    })
    wx.request({
      url: http + '/hyapi/passenger/getaddress2', //仅为示例，并非真实的接口地址
      data: {
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data)
        if (res.data.errcode == 0 && res.data.data) {
          res.data.data.address = res.data.data.detail.split('*')[0];

          that.setData({
            ad2: res.data.data
          })
        } else {
          that.setData({
            ad2: null
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})