

var app = getApp();
var http = app.globalData.http;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    h: "",
    show_left: false,
    name: '',
    idcard: '',
    phone: "",
    no: '',
    date: '',
    address: '',
    jjphone: ''
  },
  back_:function(){
      wx.navigateBack({
        delta:1
      })
  },
  bindDateChange:function(e){
    this.setData({
      date: e.detail.value
    })
      
  },
  sub_mit: function () {
    var that = this;
    if (that.data.name == '') {
      wx.showToast({
        title: '请填写姓名',
        icon: 'none'
      })
      return false;
    }
    var format = /^(([1][1-5])|([2][1-3])|([3][1-7])|([4][1-6])|([5][0-4])|([6][1-5])|([7][1])|([8][1-2]))\d{4}(([1][9]\d{2})|([2]\d{3}))(([0][1-9])|([1][0-2]))(([0][1-9])|([1-2][0-9])|([3][0-1]))\d{3}[0-9xX]$/;
    if (!format.test(that.data.idcard)) {
      wx.showToast({
        title: '身份证号码格式错误',
        icon: 'none'
      })
      return false;
    }


    var pattern = /^((1[3,5,7,8][0-9])|(14[5,7])|(17[0,6,7,8])|(19[7]))\d{8}$/;

    if (!pattern.test(that.data.phone)) {
      wx.showToast({
        title: '手机号码格式错误',
        icon: 'none'
      })
      return false;
    }

    if (that.data.no==''){
      wx.showToast({
        title: '请输入驾照档案编号',
        icon: 'none'
      })
      return false;
    }

    if (that.data.date == '') {
      wx.showToast({
        title: '输入驾照申领日期',
        icon: 'none'
      })
      return false;
    }

    if (that.data.address == '') {
      wx.showToast({
        title: '请输入要做代驾司机的城市',
        icon: 'none'
      })
      return false;
    }
    if (!pattern.test(that.data.jjphone)) {
      wx.showToast({
        title: '紧急联系人手机号码格式错误',
        icon: 'none'
      })
      return false;
    }

    wx.showLoading({
      title: '提交中',
    })
    wx.request({
      url: http +'/hyapi/passenger/tobedriver', //仅为示例，并非真实的接口地址
      data: {
        common_param:JSON.stringify({
          realname: that.data.name,
          id_card: that.data.idcard,
          driving_file_number:that.data.no,
          driving_license_date: that.data.date,
          work_address: that.data.address,
          emergency_call: that.data.jjphone
        }),
        token:wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data);
          if(res.data.errcode==0){
                that.setData({
                  show_g:true
                })
          }else{
              wx.showToast({
                title: res.data.errmsg,
                icon:'none'
              })
          }
      }
    })



  },
  again_wait:function(){
      wx.navigateBack({
          delta:1
      })
      this.setData({
        show_g: false
        
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getSystemInfo({
      success: function (e) {
        that.setData({
          h: e.statusBarHeight

        })
        console.log(e.statusBarHeight)
      }
    })
  },
  back_: function () {
    wx.navigateBack({
      delta: 1
    })
  },
  get_left: function () {
    var that = this;
    this.setData({
      show_left: !that.data.show_left
    })
  },
  hid_left: function () {
    this.setData({
      show_left: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  get_name: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  get_idcard: function (e) {
    this.setData({
      idcard: e.detail.value
    })
  },
  get_phone: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },
  get_date: function (e) {
    this.setData({
      date: e.detail.value
    })
  },
  get_address: function (e) {
    this.setData({
      address: e.detail.value
    })
  },
  get_jjphone: function (e) {
    this.setData({
      jjphone: e.detail.value
    })
  },
  get_no:function(e){
    this.setData({
      no: e.detail.value
    })
  }

})