
var app = getApp();
var http = app.globalData.http;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    h: "",
    show_left: false,
    realname: '',
    id_card: '',
    engine_number: '',
    carframe_number: '',
    license_plate_area: "",
    license_plate_number: "",
    car_type: '',
    pai: '京',
    array: [
      '京', '津', '沪', '渝', '蒙', '新', '藏', '宁', '桂', '港', '澳', '黑', '吉', '辽', '晋',
      '冀', '青', '鲁', '豫', '苏', '皖', '浙', '闽', '赣', '湘', '鄂', '粤', '琼', '甘', '陕', '贵', '云', '川'
    ]
  },
  back_: function () {
    wx.navigateBack({
      delta: 1
    })
  },
  sub_mit: function() {
    var that = this;
    var express = /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂学警港澳]{1}$/;

    var format = /^(([1][1-5])|([2][1-3])|([3][1-7])|([4][1-6])|([5][0-4])|([6][1-5])|([7][1])|([8][1-2]))\d{4}(([1][9]\d{2})|([2]\d{3}))(([0][1-9])|([1][0-2]))(([0][1-9])|([1-2][0-9])|([3][0-1]))\d{3}[0-9xX]$/;
    if (that.data.realname == '') {
      wx.showToast({
        title: '请填写姓名',
        icon: 'none'
      })
      return false;
    }
    if (!format.test(that.data.id_card)) {
      wx.showToast({
        title: '身份证号码格式错误',
        icon: 'none'
      })
      return false;
    }


    if (that.data.engine_number == '') {
      wx.showToast({
        title: '请填写发动机号',
        icon: 'none'
      })
      return false;
    }
    if (that.data.carframe_number == '') {
      wx.showToast({
        title: '请填写车架号',
        icon: 'none'
      })
      return false;
    }
    if (!express.test(that.data.pai + that.data.license_plate_number)) {
      wx.showToast({
        title: '车牌号错误',
        icon: 'none'
      })
      return false;
    }
    if (that.data.car_type == '') {
      wx.showToast({
        title: '请填写车型',
        icon: 'none'
      })
      return false;
    }
    wx.showLoading({
      title: '提交中',
    })

    wx.request({
      url: http +'/hyapi/passenger/carownerauth', //仅为示例，并非真实的接口地址
      data: {
        common_param:JSON.stringify({
          realname: that.data.realname,
          id_card: that.data.id_card,
          engine_number: that.data.engine_number,
          carframe_number: that.data.carframe_number,
          license_plate_area:that.data.pai,
          license_plate_number: that.data.license_plate_number,
          car_type: that.data.car_type
        }),
        token:wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data)
        if(res.data.errcode==0){
            wx.showToast({
              title: '提交成功',
            })
        }else{
          wx.showToast({
            title: res.data.errmsg,
          })
        }
      }
    })







  },
  bindPickerChange: function(e) {
    console.log(e)
    var that = this;
    this.setData({
      pai: that.data.array[e.detail.value]
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    wx.getSystemInfo({
      success: function(e) {
        that.setData({
          h: e.statusBarHeight

        })
        console.log(e.statusBarHeight)
      }
    })
  },
  get_left: function() {
    var that = this;
    this.setData({
      show_left: !that.data.show_left
    })
  },
  hid_left: function() {
    this.setData({
      show_left: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  get_realname: function(e) {
    this.setData({
      realname: e.detail.value
    })
  },
  get_id_card: function(e) {
    this.setData({
      id_card: e.detail.value
    })
  },
  get_engine_number: function(e) {
    this.setData({
      engine_number: e.detail.value
    })
  },
  get_carframe_number: function(e) {
    this.setData({
      carframe_number: e.detail.value
    })
  },
  get_license_plate_number: function(e) {
    this.setData({
      license_plate_number: e.detail.value
    })
  },
  get_car_type: function(e) {
    this.setData({
      car_type: e.detail.value
    })
  },
})