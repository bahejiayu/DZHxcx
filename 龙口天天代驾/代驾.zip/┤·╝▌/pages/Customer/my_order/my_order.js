var app = getApp();
var http = app.globalData.http;
var session_ = app.globalData.session;
Page({


  /**
   * 页面的初始数据
   */
  data: {
    h: "",
    show_left: false,
    winWidth: '',
    winHeight: '',
    order_list: []
  },
  formatDateTime: function (timeStamp) {
    var date = new Date();
    date.setTime(timeStamp * 1000);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    var minute = date.getMinutes();
    var second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    return y + '年' + m + '月' + d + '日  ' + h + ':' + minute;
  },
  go_detail: function (e) {
    wx.navigateTo({
      url: '../order_info/order_info?order_id=' + e.target.dataset.id,
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.initSystemInfo();
    var that = this;
    wx.getSystemInfo({
      success: function (e) {
        that.setData({
          h: e.statusBarHeight

        })
        console.log(e.statusBarHeight)
      }
    })
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: http + '/hyapi/order/getalllist',
      data: {
        common_param: JSON.stringify({
          page_index: 1,
          page_size: 0
        }),
        token: wx.getStorageSync('token')
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.errcode == 0) {
          for (var i = 0; i < res.data.data.data.length; i++) {
            res.data.data.data[i].create_time = that.formatDateTime(res.data.data.data[i].create_time)
          }
          console.log(res.data.data.data)
          that.setData({
            order_list: res.data.data.data
          })
        }else{
            wx.showToast({
              title: res.data.errmsg,
              icon:'none'
            })
        }
      }
    })
  },
  back_: function (e) {
    console.log(e)
    if (e.target.dataset.name == '已关闭') {
      return false;
    }
    wx.navigateBack({
      delta: 1
    })
  },
  initSystemInfo: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
  },
  get_left:function () {
    var that = this;
    this.setData({
      show_left: !that.data.show_left
    })
  },
  hid_left:function(){
    this.setData({
      show_left: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})