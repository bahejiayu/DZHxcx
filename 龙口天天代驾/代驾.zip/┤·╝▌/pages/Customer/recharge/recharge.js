
var app = getApp();
var http = app.globalData.http;


Page({

  /**
   * 页面的初始数据
   */
  data: {
    h: "",
    show_left: false,
    index_:1,
    money:200
  },
  back_:function(){
    wx.navigateBack({
      delta:1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getSystemInfo({
      success: function (e) {
        that.setData({
          h: e.statusBarHeight

        })
        console.log(e.statusBarHeight)
      }
    })
  },
  submit: function () {
    var that = this;
    if (!wx.getStorageSync('token')) {
      wx.showToast({
        title: '请前往个人中心登陆',
        icon: 'none',
        duration: 2000
      })
      // setTimeout(function () {
      //   wx.switchTab({
      //     url: '../user/user'
      //   })
      // }, 1000)
      return false
    }

    if(that.data.index_==4&&that.data.money==''){
              wx.showToast({
                title: '请选择或输入充值金额',
                icon:'none'
              })
              return false;
    }
    if (that.data.money<=0){
      wx.showToast({
        title: '请输入正确的充值金额',
        icon: 'none'
      })
      return false;
    }

    wx.showLoading({
      title: '请稍等',
    })
    wx.request({
      url: http + '/hyapi/order/paymentorder', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        common_param: JSON.stringify({
          skus:"2:1",
          money: that.data.money,
          order_type: 3
        }),
        token: wx.getStorageSync('token')
      },
      success: function (res) {
        if (res.data.errcode == '0') {
          wx.request({
            url: http + '/hyapi/order/create', //仅为示例，并非真实的接口地址
            data: {
              token: wx.getStorageSync('token')
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success: function (res) {
              if (res.data.errcode == 0) {
                wx.request({
                  url: http + '/hyapi/order/pay', //仅为示例，并非真实的接口地址
                  data: {
                    common_param: JSON.stringify({
                      out_trade_no: res.data.data.out_trade_no
                    }),
                    token: wx.getStorageSync('token')
                  },
                  header: {
                    'content-type': 'application/json' // 默认值
                  },
                  success: function (res) {
                    wx.hideLoading();
                    console.log(res.data)
                    if (res.data.errcode == 0) {

                      console.log(res.data.data.timeStamp)
                      wx.requestPayment({
                        'timeStamp': res.data.data.timeStamp,
                        'nonceStr': res.data.data.nonceStr,
                        'package': res.data.data.package,
                        'signType': res.data.data.signType,
                        'paySign': res.data.data.paySign,
                        'success': function (res) {
                          console.log(res.data)
                          that.setData({
                            show_g: true
                          })

                        },
                        'fail': function (res) { }
                      })


                    }else{
                        wx.showToast({
                          title: res.data.errmsg,
                          icon:"none"
                        })
                    }
                  }
                })



              }
              console.log(res.data)
            }
          })






        } else {
          wx.showToast({
            title: res.data.errmsg,
            icon: 'none'
          })
        }
      }
    })












  },
  inp_money:function(e){
      this.setData({
        money:e.detail.value
      })
  },
  tog_money:function(e){
      this.setData({
        index_:e.target.dataset.index,
      })
      var that=this;
      if (that.data.index_<4){
        that.setData({
          money: e.target.dataset.money,
        })
      }
      if (that.data.index_ == 4) {
        that.setData({
          money:'',
        })
      }

  },
  get_left: function () {
    var that = this;
    this.setData({
      show_left: !that.data.show_left
    })
  },
  hid_left: function () {
    this.setData({
      show_left: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})