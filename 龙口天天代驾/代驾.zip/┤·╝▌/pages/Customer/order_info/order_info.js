var DzhMiniMap = require('../../../libs/dzhmap/DzhMiniMap.js');
var PassengerMap = require('../../../libs/dzhmap/PassengerMap.js');
var app = getApp();
var http = app.globalData.http;
var session_ = app.globalData.session;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    h: "",
    show_left: false,
    winWidth: '',
    winHeight: '',
    start_:5,
    show_pj:false,
    data_obj:{},
    show_info:false,
    longitude:'',
    latitude:'',
    markers:[],
    order_id:0,
    is_pl:true,
    map_height: ''
  },
  show_pj:function(){
      this.setData({
        show_pj:true
      })
  },
  hid_pl:function(){
    this.setData({
      show_pj: false
    })
  },
  sub_pl:function(){
    var that=this;
    wx.showLoading({
      title: '提交中',
    })
    wx.request({
      url: http +'/hyapi/order/addgoodsevaluate', //仅为示例，并非真实的接口地址
      data: {
        common_param:JSON.stringify({
          order_id: that.data.order_id,
          evaluate:[
            {
              // 
              is_anonymous:false,
              scores: that.data.start_,
              explain_type:1,
              order_goods_id: that.data.data_obj.order_goods[0].goods_id,
              content:'',
            }
          ]
        }),
        token:wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data)
            if(res.data.errcode==0){
                that.setData({
                  is_pl:false
                })
                  wx.showToast({
                    title: '感谢您的评价',
                    icon:'none'
                  })
            }else{
              wx.showToast({
                title: '评价失败',
                icon: 'none'
              })
            }
            that.setData({
              show_pj: false
            })
      }
    })

  },
  back_:function(){
      wx.navigateBack({
        delta: 1,
      })
  },
  get_start:function(e){
      this.setData({
        start_:e.target.dataset.index
      })
  },
  formatDateTime: function (timeStamp) {
    var date = new Date();
    date.setTime(timeStamp * 1000);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    var minute = date.getMinutes();
    var second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    return y + '年' + m + '月' + d + '日  ' + h + ':' + minute;
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.mapCtx = wx.createMapContext('mappage_map');
    var that = this;
      that.setData({
        order_id: options.order_id
      })
    this.DzhMiniMap = new DzhMiniMap.DzhMiniMap(that, that.mapCtx);
    this.PassengerMap = new PassengerMap.PassengerMap(that, that.mapCtx);
    console.log(options)
    this.initSystemInfo();
   
    wx.getSystemInfo({
      success: function (e) {
        that.setData({
          h: e.statusBarHeight,
          map_height: e.windowHeight - e.statusBarHeight - 50
        })
        console.log(e.statusBarHeight)
      }
    })


// 127
      wx.showLoading({
        title: '加载中',
      })
      wx.request({
        url: http +'/hyapi/order/getdetail',
        data:{
          common_param:JSON.stringify({
            order_id: options.order_id
          }),
          token:wx.getStorageSync('token')
        },
        success:function(res){
          wx.hideLoading();
          if(res.data.errcode==0){
            res.data.data.create_time = that.formatDateTime(res.data.data.create_time);
            console.log(res.data)
            
              that.setData({
                show_info:true,
                data_obj:res.data.data
              })
        
              // origin_location
              that.setData({
                longitude: res.data.data.origin_location.split(',')[0],
                latitude: res.data.data.origin_location.split(',')[1]
              })
              that.PassengerMap.newb(res.data.data.polyline, '../../../img/mapicon_navi_s.png', '../../../img/mapicon_navi_e.png');

          }
        }
      })















  },
  phone_: function (e) {
    wx.makePhoneCall({
      phoneNumber: e.target.dataset.phone //仅为示例，并非真实的电话号码
    })
  },
  initSystemInfo: function () {
    var that = this;

    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
  },
  get_left: function () {
    var that = this;
    this.setData({
      show_left: !that.data.show_left
    })
  },
  hid_left: function () {
    this.setData({
      show_left: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})