// pages/info/info.js

var app = getApp();
var http = app.globalData.http;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    is_bind: false,
    user_info: {},
    phone_: '',
    code_: '',
    email: "",
    vic_code: '',
    time: 60,
    is_post: false,
    h:''
  },
  back_:function(){
      wx.navigateBack({
        delta:1
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.b){
          wx.showToast({
            title: '请绑定手机号',
            icon:"none"
          })
      }
    var that = this;
    wx.getSystemInfo({
      success: function (e) {
        that.setData({
          h: e.statusBarHeight

        })
        console.log(e.statusBarHeight)
      }
    })


  },
  get_phone: function (e) {
    this.setData({
      phone_: e.detail.value
    })
  },
  get_code: function (e) {
    this.setData({
      code_: e.detail.value
    })
  },
  get_email: function (e) {
    this.setData({
      email: e.detail.value
    })
  },
  post_code: function () {
    var that = this;
    var pattern = /^((1[3,5,8][0-9])|(14[5,7])|(17[0,6,7,8])|(19[7]))\d{8}$/;
    if (!pattern.test(that.data.phone_)) {
      wx.showToast({
        title: '请填写有效的手机号',
        icon: 'none',
        duration: 2000
      })
      return false
    }
    wx.showLoading({
      title: '正在获取短信验证码',
    })
    wx.request({
      url: http + '/hyapi/user/sendmobilevcode', //仅为示例，并非真实的接口地址
      data: {
        common_param: JSON.stringify({
          mobile: that.data.phone_
        }),
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data)
        if (res.data.errcode == 0) {
          wx.showToast({
            title: '已发送',
          })
          that.setData({
            is_post: true
          })
          var d_time = setInterval(function () {
            var now_time = that.data.time;
            now_time--;
            if (now_time <= 0) {
              clearInterval(d_time);
              that.setData({
                time: 60,
                is_post: false
              })
              return false;

            } else {
              that.setData({
                time: now_time,
                is_post: true
              })
            }



          }, 1000)
        } else {
          wx.showToast({
            title: '短信发送失败',
            icon: 'none'
          })
        }
      }
    })



  },
  sub_mit: function () {
    var that = this;
    var pattern = /^((1[3,5,8][0-9])|(14[5,7])|(17[0,6,7,8])|(19[7]))\d{8}$/;
    if (!pattern.test(that.data.phone_)) {
      wx.showToast({
        title: '请填写有效的手机号',
        icon: 'none',
        duration: 2000
      })
      return false
    }

    if (that.data.code_ == '') {
      wx.showToast({
        title: '请填写短信验证码',
        icon: 'none',
        duration: 2000
      })
      return false

    }

 
    wx.showLoading({
      title: '提交中',
    })
    wx.request({
      url: http + '/hyapi/user/savemobile', //仅为示例，并非真实的接口地址
      data: {
        common_param: JSON.stringify({
          mobile: that.data.phone_,
          email: that.data.email,
          vcode: that.data.code_
        }),
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        if (res.data.errcode == 0) {
          wx.showToast({
            title: '提交成功',
          })
      setTimeout(function(){
            wx.navigateBack({
              delta:1
            })
      },1500)

        } else {
          wx.showToast({
            title: res.data.errmsg,
            icon: 'none'
          })
        }
        console.log(res.data)
      }
    })


  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})