var app = getApp();
var http = app.globalData.http;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    h: "",
    show_left: false,
    phone: ""
  },

  back_: function () {
    wx.navigateBack({
      delta: 1
    })
  },
  get_phone: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },
  submit: function () {
    var that = this;
    var pattern = /^((1[3,5,7,8][0-9])|(14[5,7])|(17[0,6,7,8])|(19[7]))\d{8}$/;
    if (!pattern.test(that.data.phone)) {
      wx.showToast({
        title: '手机号码格式错误',
        icon: 'none'
      })
      return false;
    }
    wx.showLoading({
      title: '提交中',
    })
    wx.request({
      url: http + '/hyapi/passenger/editinfo', //仅为示例，并非真实的接口地址
      data: {
        common_param: JSON.stringify({
          emergency_call: that.data.phone
        }),
        token: wx.getStorageSync('token')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data)
        if (res.data.errcode == 0) {
          wx.showToast({
            title: '提交成功',
          })
          setTimeout(function () {
            wx.navigateBack({
              delta: 1
            })
          }, 1500)
        }else{
          wx.showToast({
            title: res.data.errmsg,
            icon:'none'
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getSystemInfo({
      success: function (e) {
        that.setData({
          h: e.statusBarHeight

        })
        console.log(e.statusBarHeight)
      }
    })
  },
  get_left: function () {
    var that = this;
    this.setData({
      show_left: !that.data.show_left
    })
  },
  hid_left: function () {
    this.setData({
      show_left: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})