var DzhMiniMap = require('../../libs/dzhmap/DzhMiniMap.js');
var PassengerMap = require('../../libs/dzhmap/PassengerMap.js');

Page({

  DzhMiniMap: null,
  PassengerMap: null,

  data: {},

  onLoad: function () {

    this.mapCtx = wx.createMapContext('mappage_map')
    var that = this;

    this.DzhMiniMap = new DzhMiniMap.DzhMiniMap(that, that.mapCtx);
    this.PassengerMap = new PassengerMap.PassengerMap(that, that.mapCtx);
    //初始化乘客地图
    this.PassengerMap.init();
    //司机接单后，获取司机的当前位置
    this.PassengerMap.getDriverLocation('http://wanyu.d1.natapp.cc/mapapi/getdriverlocation.php', { location: "113.256578,23.148156" }, 10, function (data) {
      console.log(data);
      if (data.navigate.is_arrive == true) {
        console.log("已到达目的地附近");
      }
    });
  },
  regionchange: function (e) {
    this.PassengerMap.getCenterAddress("http://wanyu.d1.natapp.cc/mapapi/getaddr.php", e.type);
  },
})


