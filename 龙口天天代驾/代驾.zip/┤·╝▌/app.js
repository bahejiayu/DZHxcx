App({

  /**
   * 当小程序初始化完成时，会触发 onLaunch（全局只触发一次）
   */
  onLaunch: function () {

    var that = this;
    wx.request({
      // url: 'http://www.2030.net/hyapi/user/getsessionid',
    
      url: 'https://s2030.wanyuwl.net/hyapi/user/getsessionid',
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        if (res.data.errcode == 0) {
          that.globalData.session = res.data.data
        }
      }
    })
    
  },

  /**
   * 当小程序启动，或从后台进入前台显示，会触发 onShow
   */
  onShow: function (options) {
    
  },
  /**
   * 当小程序从前台进入后台，会触发 onHide
   */
  onHide: function () {
    
  },
  /**
   * 当小程序发生脚本错误，或者 api 调用失败时，会触发 onError 并带上错误信息
   */
  onError: function (msg) {
    
  },
  globalData: {
    session: '',
    // http: "http://www.2030.net"
    http: "https://s2030.wanyuwl.net"
  }
})
