
var app = getApp()
var http = app.globalData.http
var appid = app.globalData.appid
var secret = app.globalData.secret
var loginObj = {}

Page({

  /**
   * 页面的初始数据
   */
  data: {
    openid:"",
    use_data:false,
    is_zc:false,
    cs_data:{},
    dj:false,
    play_:false,
    game_rule:[],
    show_r:true,
    my_gold:'',
    bz:false
  },
  ll: function () {
    var a = this;

    if (wx.createInnerAudioContext) {
      var i = wx.createInnerAudioContext();
      i.autoplay = true, i.src = "/music/success.mp3", i.onPlay(function () { }), setTimeout(function () {
        i.destroy();
      }, 4000);
    }

  },
  zjy: function () {
    var a = this;

    if (wx.createInnerAudioContext) {
      var i = wx.createInnerAudioContext();
      i.autoplay = true, i.src = "/music/ability_fail.mp3", i.onPlay(function () { }), setTimeout(function () {
        i.destroy();
      }, 3000);
    }

  },
  gift_bag_func: function () {
    var a = this;
    
    if (wx.createInnerAudioContext) {
      var i = wx.createInnerAudioContext();
      i.autoplay = true, i.src = "/music/gift.mp3", i.onPlay(function () { }), setTimeout(function () {
        i.destroy();
      }, 1000);
    }

  },
  answer_wrong_func: function (t) {
    
    var a = this;
  
    if (wx.createInnerAudioContext) {
      var i = wx.createInnerAudioContext();
      i.autoplay = true, i.src = "/music/error.mp3", i.onPlay(function () { }), setTimeout(function () {
        i.destroy();
      }, 1000);
    }
    
    
  },
  abc:function(){
    this.ll()
  },
  show_rule:function(){
      this.setData({
        show_r:false
      })
  },
  popup_rule_end_func:function(){
    this.setData({
      show_r: true
    })
  },
  login_: function (e) {
    // 获取用户信息
    // wx.showLoading({
    //   title: '登陆中',
    // })
    console.log(e)



    var that = this;
    wx.login({
      success: function (res) {
        wx.request({
          url: http + 'userInfo', //仅为示例，并非真实的接口地址
          data: {
            openid: that.data.openid,
            encryptedData: e.detail.encryptedData,
            iv: e.detail.iv,
            code:res.code
          },
          method: "POST",
          header: {
            'content-type': 'application/json' // 默认值
          },
          success: function (res) {
            console.log(res.data)
              if(res.data.status==1){
                wx.login({
                  success: function (res) {
                    if (res.code) {

                      that.get_all();
                    } else {
                      console.log('登录失败！' + res.errMsg)
                    }
                  }
                });
              }
          }
        })
      }})

   


  },
  cancel_bz:function(){

        this.setData({
          bz:false
        })
        console.log(this.data.bz)
  },
  to_game:function(){
      var that=this;
      if (that.data.my_gold < that.data.cs_data.cut_gold){
        that.setData({
          bz:true
        })
        return false;
      }

      this.setData({
        dj:true
      })
      wx.navigateTo({
        url: '../game/game',
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  get_all:function(){
    var openid = '';
    var that = this;
    wx.login({
      success: function (res) {
        if (res.code) {

          wx.request({
            url: http + 'user', //仅为示例，并非真实的接口地址
            data: {
              code: res.code,

            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success: function (res) {
              console.log(res.data)
              that.setData({
                openid: res.data.openid
              })

              // 初始化
              wx.request({
                url: http + 'index', //仅为示例，并非真实的接口地址

                header: {
                  'content-type': 'application/json' // 默认值
                },
                data: {
                  openid: that.data.openid
                },
                success: function (res) {
                  console.log(res.data)
                  that.setData({
                    cs_data: res.data,
                    game_rule: JSON.parse(res.data.init.game_rule),
                    my_gold: res.data.user.gold,

                  })
                  wx.setStorageSync('cs', res.data.user);
                  wx.setStorageSync('init', res.data.init);
                }
              })






              if (res.data.head_img) {
                wx.setStorageSync('key', res.data);
                that.setData({
                  is_zc: true,
                  use_data: res.data
                })
               

              } else {
                that.setData({
                  is_zc: false
                })
              }
            }
          })
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    });

  },
  onLoad: function (options) {
    wx.showLoading({
      title: '打开中',
    })
    wx.showShareMenu && wx.showShareMenu({
      withShareTicket: true
    });
    this.get_all();
  setTimeout(function(){
    wx.hideLoading()
  },2000)
   


    // 开始游戏
    // 初始化
 



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
   

    this.get_all();
    this.setData({
      dj:false
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var e = this, n = wx.getStorageSync("init"), o = JSON.parse(n.share_img), i = o[0].img;
    return {
      title: n.share_title,
      path: "/pages/index/index",
      imageUrl: i,
      success: function (a) {
        console.log(a)
        var o = a.shareTickets;
        if (!a.shareTickets || void 0 == o.length || 0 == o.length) return wx.showToast({
          icon: "none",
          title: "分享到群，有机会获得金币"
        }), false;
        wx.showLoading({
          title: "正在处理"
        }), wx.login({
          success: function (a) {
            wx.getShareInfo({
              shareTicket: o[0],
              success: function (o) {
                var i = o.encryptedData;
                wx.request({
                  url: http + "share?encryptedData=" + encodeURIComponent(i) + "&code=" + a.code + "&iv=" + o.iv,
                  method: "POST",
                  success: function (t) {
                    if (wx.hideLoading(), 1 == t.data.status) {
                      wx.showToast({
                        title: "分享成功",
                        icon: "success"
                      });
                      var o = parseInt(n.share_gold);
                       e.setData({
                        popup_gold: true,
                        my_gold: e.data.my_gold+o,
                        popup_countdown: true,
                        bz: false                                              
                      }), 0 == e.data.tip_off && e._interval_func();
                  
                    } else wx.showToast({
                      title: t.data.msg,
                      icon: "none"
                    });
                  },
                  fail: function (t) {
                    wx.hideLoading(), wx.showToast({
                      icon: "none",
                      title: "您的网络出问题了"
                    });
                  }
                });
              }
            });
          }
        });
      }
    };
  }
})



