
var app = getApp()
var http = app.globalData.http
var appid = app.globalData.appid
var secret = app.globalData.secret
var loginObj = {}
var set_time
var test_time
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bz:false,
    ok:false,
    go:false,
    winWidth: '',
    winHeight: '',
    game_data: {},
    G: 0,
    zd: 0,
    dui: false,
    cuo: false,
    my_gold: 0,
    de: 0,
    k: 0,
    nub: 0,
    jd_arr: '',
    test_gold:10000,
    play_:true,
    offer:false,
    tap:true,
    time:10,
    tiem_end:false,
    fh:0,
    tip:"答题时间已结束"
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
    zjy: function () {
    // var a = this;
    
    // if (wx.createInnerAudioContext) {
    //   var i = wx.createInnerAudioContext();
    //   i.autoplay = true, i.src = "/music/ability_fail.mp3", i.onPlay(function () { }), setTimeout(function () {
    //     i.destroy();
    //   }, 3000);
    // }

  },
    time321: function () {
      var a = this;

      if (wx.createInnerAudioContext) {
        var i = wx.createInnerAudioContext();
        i.autoplay = true, i.src = "/music/time321.mp3", i.onPlay(function () { }), setTimeout(function () {
          i.destroy();
        }, 4000);
      }

    },
    ll: function () {
      var a = this;

      if (wx.createInnerAudioContext) {
        var i = wx.createInnerAudioContext();
        i.autoplay = true, i.src = "/music/success.mp3", i.onPlay(function () { }), setTimeout(function () {
          i.destroy();
        }, 4000);
      }

    },
  gift_bag_func: function () {
    var a = this;

    if (wx.createInnerAudioContext) {
      var i = wx.createInnerAudioContext();
      i.autoplay = true, i.src = "/music/gift.mp3", i.onPlay(function () { }), setTimeout(function () {
        i.destroy();
      }, 1000);
    }

  },
  answer_wrong_func: function (t) {

    var a = this;
    
    if (wx.createInnerAudioContext) {
      var i = wx.createInnerAudioContext();
      i.autoplay = true, i.src = "/music/error.mp3", i.onPlay(function () { }), setTimeout(function () {
        i.destroy();
      }, 1000);
    }


  },
  onLoad: function (options) {
    test_time=setInterval(function(){
        console.log(1)
    },1000)
    // wx.showShareMenu && wx.showShareMenu({
    //   withShareTicket: false
    // });

    wx.hideShareMenu()
    
    // var i = wx.createInnerAudioContext();
    // i.autoplay = true, i.src = "/music/error.mp3", i.onPlay(function () { }), setTimeout(function () {
    //   i.destroy();
    // }, 500);

    
    var that = this;
    that.get_game();
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
    // that.setData({
    //   my_gold: wx.getStorageSync('cs').gold
    // })


  },
  get_game:function(){
    // wx.showLoading({
    //   title: '加载中',
    // })
    var that = this;
    wx.request({
      url: http + 'startgame', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        openid: wx.getStorageSync('key').openid
      },
      success: function (res) {
          console.log(res.data)
          if (res.data.sub_data){
            that.setData({
              offer: false
            })
            for (var i = 0; i < res.data.sub_data.length; i++) {
              res.data.sub_data[i].arr = [];
              for (var j = 0; j < res.data.sub_data[i].p_answers.length; j++) {
                res.data.sub_data[i].arr[j] = {};
                res.data.sub_data[i].arr[j].name = res.data.sub_data[i].p_answers[j];
                res.data.sub_data[i].arr[j].g = false;
                res.data.sub_data[i].arr[j].r = false;
                res.data.sub_data[i].arr[j].add = false;
                res.data.sub_data[i].arr[j].down = false;
                
              }
            }

          }else{  
              that.setData({
                offer:true
              })

          }


  
        that.setData({
          game_data: res.data,
          G: res.data.defaultnum || 0,
          jd_arr: res.data.old_str||[],
          my_gold: res.data.gold||0,
          time:10
        })
         if(that.data.offer==false){
           set_time = setInterval(function () {
             
             var this_time = that.data.time - 1;
             if (this_time == 3) {
              
               that.time321()
             }
             
             if (this_time < 0) {

               clearInterval(set_time)
               that.setData({
                 tiem_end: true,
                 tip: '答题时间已结束'
               })
              that.zjy();

             }else{
               that.setData({
                 time: this_time
               })
             }


           }, 1000)

         }
        console.log(res.data)
        // wx.hideLoading();
      }
    })
  },
  jie_shi:function(){
    var that=this;
    var tiem_ji = that.data.time-1;
    var dsq;
    console.log('dsq', tiem_ji)
    
      
      
        that.time321()
     



  },
  popup_countdown_func:function(){
   
    this.setData({
      tiem_end:false
    })
    // wx.navigateTo({
    //   url: '../index/index',
    // })
  },
  jx:function(){
        var that=this;
        var shu = that.data.my_gold - parseInt(wx.getStorageSync('init').relive_gold) 
        if (shu>0){
          var fh_nb=that.data.fh+1;
          wx.showToast({
            title: '复活成功',
            icon: 'none',
            duration: 2000
          })
          that.setData({
              my_gold:shu,
              fh:fh_nb,
              tiem_end:false,
              time:10
          })

          set_time = setInterval(function () {
            console.log(1)
            var this_time = that.data.time - 1;
            if (this_time == 3) {

              that.time321()
            }
            if (this_time < 0) {

              clearInterval(set_time)
              that.setData({
                tiem_end: true,
                tip: '答题时间已结束'
              })

              that.zjy();
              
            } else {
              that.setData({
                time: this_time
              })
            }

           
          }, 1000)
          console.log(that.data.fh)

        }else{
          wx.showToast({
            title: '金币不足不能复活',
            icon: 'none',
            duration: 2000
          })
        }
  },
  return_:function(){
    wx.navigateBack({
      delta: 1
    });
      // this.setData({
      //     tiem_end:false
      // })
  },
  nex_guang:function(){
    this.get_game();
    this.setData({
      ok: false,
    })
        
  },
  sub: function (e) {
    var that = this;
    // 本题需要的金币
    if (that.data.tap){
      that.setData({
        tap:false
      })
      setTimeout(function(){
        that.setData({
          tap: true
        })
      },500)

      var obj = that.data.game_data;
      var fan=true;
      console.log(obj)
      for (var i = 0; i < obj.sub_data[that.data.G].arr.length;i++){
        if (obj.sub_data[that.data.G].arr[i].g==true){
                  
                     return false
              }
      }
          console.log(fan)
      if (obj.sub_data[that.data.G].arr[e.target.dataset.index].r == true){
              return false;
      }


      var ben = that.data.game_data.gold;
      if (that.data.my_gold <= 0) {
        that.setData({
          bz: true,
        })
        // clearInterval(set_time)
        setTimeout(function () {
          that.setData({
            bz: false
          })

        }, 2000)
        return false
      }

      // 答对获取的金币

      var de = that.data.game_data.get_gold;
      this.setData({
        de: de
      })

      // 答错扣除的金币
      var k = that.data.game_data.del_gold;
      this.setData({
        k: k
      })




      // 判断答对
      if (e.target.dataset.index == e.target.dataset.an) {
        that.gift_bag_func()
        clearInterval(set_time)
        







        // 答对总金币增加
        var sm_arr = that.data.jd_arr;
        sm_arr += e.target.dataset.index
        that.setData({
          jd_arr: sm_arr,
          my_gold: that.data.my_gold + de
        })
        console.log(that.data.jd_arr)


        that.setData({
          dui: true
        })
        setTimeout(function () {
          that.setData({
            dui: false
          })
        }, 800)


        // 添加类
        obj.sub_data[that.data.G].arr[e.target.dataset.index].g = true;
        obj.sub_data[that.data.G].arr[e.target.dataset.index].add = true;
        setTimeout(function () {


          obj.sub_data[that.data.G].arr[e.target.dataset.index].add = false;
          that.setData({
            game_data: obj
          })
          that.setData({
            go: true
          })

        }, 1000)
        // 跳转下一题
        setTimeout(function () {
          
          var a = that.data.G + 1;
          if (a == 20) {
            that.ll();            
            that.up_an();
            that.setData({
              ok: true,
              go: false
            })
            return false;
          }

          that.setData({
            G: a,
            go: false,
            time:10
          })
          

          set_time = setInterval(function () {
            console.log(1)
            var this_time = that.data.time - 1;
            if (this_time == 3) {

              that.time321()
            }
            if (this_time < 0) {

              clearInterval(set_time)
              that.setData({
                tiem_end: true,
                tip:'答题时间已结束'
              })
              that.zjy();
              

            } else {
              that.setData({
                time: this_time
              })
            }


          }, 1000)
          console.log(123)

        }, 2000)

      } else {
        // wx.vibrateLong();
        that.answer_wrong_func()
        // 答错扣分
        var y = that.data.nub + 1
        that.setData({
          my_gold: that.data.my_gold - k < 0 ? 0 : that.data.my_gold - k,
          nub: y
        })
        if (that.data.my_gold <= 0) {
          // 提交答案
          clearTimeout(set_time)          
          that.up_an();
          that.setData({
            tiem_end: true,
            tip:"金币已全部用完"            
          })      
          that.zjy();          
        }


        console.log(that.data.nub)
        // 添加扣分类
        obj.sub_data[that.data.G].arr[e.target.dataset.index].r = true;
        obj.sub_data[that.data.G].arr[e.target.dataset.index].down = true;
        that.setData({
          cuo: true
        })
        setTimeout(function () {
          obj.sub_data[that.data.G].arr[e.target.dataset.index].down = false;
          that.setData({
            game_data: obj
          })
          that.setData({
            cuo: false
          })

        }, 800)

      }


      // 重新渲染
      that.setData({
        game_data: obj
      })

     
    }

   





  },
 
  // {
  //   if(wx.createInnerAudioContext) {
  //     var i = wx.createInnerAudioContext();
  //     i.autoplay = true, i.src = "/music/error.mp3", i.onPlay(function () { }), setTimeout(function () {
  //       i.destroy();
  //     }, 500);
  //   }
  // }
  up_an:function(){
    var that=this;
    if (that.data.offer==false){
      wx.request({
        url: http + 'sendanswer', //仅为示例，并非真实的接口地址
        method: 'POST',
        data: {
          openid: wx.getStorageSync('key').openid,
          answer_incor: that.data.nub,
          record_answer: that.data.jd_arr,
          relive_incor: that.data.fh

        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success: function (res) {
          console.log(res.data)
          if (res.data.status == 1) {
            wx.showToast({
              title: '游戏保存成功',
              icon: 'none',
              duration: 2000
            })


          }

        }
      })

    }


  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // this.play_loop && this.play_loop.destroy()
    var t = this
    console.log(t)
    t.play_loop && t.play_loop.play(), wx.createInnerAudioContext && !t.play_loop && (t.play_loop = wx.createInnerAudioContext(),
      t.play_loop.autoplay = true, t.play_loop.src = "/music/play_loop.mp3", t.play_loop.onPlay(function () { }),
      t.play_loop.loop = true)
      console.log(t)
  },
  gb:function(){
    var a = this
    a.play_loop.destroy();
    console.log(a)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
   
    this.up_an();
   
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    clearInterval(test_time)
    clearInterval(set_time)
    var a=this;
    console.log(a)
    a.time321_music && a.time321_music.destroy(), a.play_loop && a.play_loop.destroy(),
      a.countdown && clearInterval(a.countdown), a.gift && a.gift.destroy();
    this.up_an();
        
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (a) {
    
    var e = this, n = wx.getStorageSync("init"), o = JSON.parse(n.share_img), i = o[0].img;
    return {
      title: n.share_title,
      path: "/pages/index/index",
      imageUrl: i,
      success: function (a) {
          console.log(a)
        var o = a.shareTickets;
        if (!a.shareTickets || void 0 == o.length || 0 == o.length) return wx.showToast({
          icon: "none",
          title: "分享到群，有机会获得金币"
        }), false;
        wx.showLoading({
          title: "正在处理"
        }), wx.login({
          success: function (a) {
            wx.getShareInfo({
              shareTicket: o[0],
              success: function (o) {
                var i = o.encryptedData;
                wx.request({
                  url: http+ "share?encryptedData=" + encodeURIComponent(i) + "&code=" + a.code + "&iv=" + o.iv,
                  method: "POST",
                  success: function (t) {
                    if (wx.hideLoading(), 1 == t.data.status) {
                      wx.showToast({
                        title: "分享成功",
                        icon: "success"
                      });
                      var a = e.data.game_data, o = parseInt(n.share_gold);
                      a.gold = o + a.gold, e.setData({
                        time:10,
                        my_gold: a.gold,
                        tiem_end:false
                       
                      });
                        set_time = setInterval(function () {
                        console.log(1)
                        var this_time = e.data.time - 1;
                        if (this_time == 3) {

                          that.time321()
                        }
                        if (this_time < 0) {

                          clearInterval(set_time)
                          e.setData({
                            tiem_end: true,
                            tip:'答题时间已结束'
                          })
                          that.zjy();
                            

                        } else {
                          e.setData({
                            time: this_time
                          })
                        }


                      }, 1000)
                      
                       0 == e.data.tip_off && e._interval_func();

                    } else wx.showToast({
                      title: t.data.msg,
                      icon: "none"
                    });
                  },
                  fail: function (t) {
                    wx.hideLoading(), wx.showToast({
                      icon: "none",
                      title: "您的网络出问题了"
                    });
                  }
                });
              }
            });
          }
        });
      }
    };
  }
})