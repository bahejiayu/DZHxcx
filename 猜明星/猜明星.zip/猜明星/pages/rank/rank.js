
var app = getApp()
var http = app.globalData.http
var appid = app.globalData.appid
var secret = app.globalData.secret
var loginObj = {}


Page({

  /**
   * 页面的初始数据
   */
  data: {
    rank_list:{},
    winWidth:'',
    winHeight:'',
    currentTab:0,
    my_info:{
      world:10000,
       wulgar:10000
      
    }
  },
  set_:function(e){
      this.setData({
        currentTab:e.target.dataset.index
      })
  },
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  initSystemInfo: function () {
    var that = this;

    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
  },
  onLoad: function (options) {

    var that=this;
    this.initSystemInfo();
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: http + 'worldrank', //仅为示例，并非真实的接口地址

      header: {
        'content-type': 'application/json' // 默认值
      },
      data:{
        openid: wx.getStorageSync('key').openid
      },
      success: function (res) {
        wx.hideLoading()
        console.log(res.data)
        that.setData({
          rank_list:res.data,
          my_info:res.data.my
        })
      }
      
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var e = this, n = wx.getStorageSync("init"), o = JSON.parse(n.share_img), i = o[0].img;
    return {
      title: n.share_title,
      path: "/pages/index/index",
      imageUrl: i,
      success: function (a) {
        console.log(a)
        var o = a.shareTickets;
        if (!a.shareTickets || void 0 == o.length || 0 == o.length) return wx.showToast({
          icon: "none",
          title: "分享到群，有机会获得金币"
        }), false;
        wx.showLoading({
          title: "正在处理"
        }), wx.login({
          success: function (a) {
            wx.getShareInfo({
              shareTicket: o[0],
              success: function (o) {
                var i = o.encryptedData;
                wx.request({
                  url: http + "share?encryptedData=" + encodeURIComponent(i) + "&code=" + a.code + "&iv=" + o.iv,
                  method: "POST",
                  success: function (t) {
                    if (wx.hideLoading(), 1 == t.data.status) {
                      wx.showToast({
                        title: "分享成功",
                        icon: "success"
                      });
                      var a = e.data.game_data, o = parseInt(n.share_gold);
                      a.gold = o + a.gold, e.setData({
                        popup_gold: true,
                        my_gold: a.gold,
                        popup_countdown: true
                      }), 0 == e.data.tip_off && e._interval_func();
                    } else wx.showToast({
                      title: t.data.msg,
                      icon: "none"
                    });
                  },
                  fail: function (t) {
                    wx.hideLoading(), wx.showToast({
                      icon: "none",
                      title: "您的网络出问题了"
                    });
                  }
                });
              }
            });
          }
        });
      }
    };
  }
})