// pages/tie/tie.js
var app = getApp();
var http = app.globalData.http;
var curr_page=1;
var has_page=true
Page({

  /**
   * 页面的初始数据
   */
  data: {
      tie_list:[],
      url: http
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;

    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: http +'/index.php/api/list', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data:{
        cid	:91,
        pages: curr_page,
        limit:6
      },
      success: function (res) {
        console.log(res.data);
        wx.hideLoading();
        if(res.data.state==200){
          for (var i = 0; i < res.data.data.length;i++ ){
            res.data.data[i].img = res.data.data[i].data.imagegroup.split('***')[0]
            //   res.data.data[i].data = JSON.stringify(res.data.data[i])
          }
            that.setData({
              tie_list: res.data.data
            })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
     curr_page = 1;
     has_page = true
     var that = this;
     wx.showLoading({
       title: '正在刷新',
     })
     wx.request({
       url: http + '/index.php/api/list', //仅为示例，并非真实的接口地址
       header: {
         'content-type': 'application/json' // 默认值
       },
       data: {
         cid: 91,
         pages: curr_page,
         limit: 6
       },
       success: function (res) {
         console.log(res.data);
         wx.hideLoading();
         wx.stopPullDownRefresh();
         if (res.data.state == 200) {
           for (var i = 0; i < res.data.data.length; i++) {
             res.data.data[i].img = res.data.data[i].data.imagegroup.split('***')[0]
             //   res.data.data[i].data = JSON.stringify(res.data.data[i])
           }
           that.setData({
             tie_list: res.data.data
           })
         }
       }
     })

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that=this;
    if (has_page){
        wx.showLoading({
          title: '正在加载更多',
        })
        curr_page++;
        wx.request({
          url: http + '/index.php/api/list', //仅为示例，并非真实的接口地址
          header: {
            'content-type': 'application/json' // 默认值
          },
          data: {
            cid: 91,
            pages: curr_page,
            limit: 6
          },
          success: function (res) {
            console.log(res.data);


            wx.hideLoading();
            if (res.data.state == 200) {
              if (res.data.data.length <= 0) {
                has_page = false
                // wx.showToast({
                //   title: '没有更多贴吧',
                //   icon:'none'
                // })
              } else {
                for (var i = 0; i < res.data.data.length; i++) {
                  res.data.data[i].img = res.data.data[i].data.imagegroup.split('***')[0]
                }
                that.setData({
                  tie_list: that.data.tie_list.concat(res.data.data)
                })

              }




            }
          }
        })
      }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})