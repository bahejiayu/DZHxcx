// pages/message/message.js

var app = getApp();
var http = app.globalData.http;

Page({

  /**
   * 页面的初始数据
   */
  data: {
        area:'',
        phone:'',
        id_:''
  },
  sub_mit:function(){
      var that=this;
      if (that.data.area.length<=0){
          wx.showToast({
            title: '留言不能为空',
            icon:'none'

          })
          return false;
      }

      var pattern = /^((1[3,5,7,8][0-9])|(14[5,7])|(17[0,6,7,8])|(19[7]))\d{8}$/;
      if (!pattern.test(that.data.phone)){
        wx.showToast({
          title: '电话号码格式错误',
          icon: 'none'

        })
        return false;
      }
        wx.showLoading({
          title: '提交中',
        })
      wx.request({
        url: http +'/index.php/api/liuyan', //仅为示例，并非真实的接口地址
        data: {
          cid: that.data.id_,
          phone: that.data.phone,
          content: that.data.area
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success: function (res) {
          console.log(res.data);
          wx.hideLoading();
            if(res.data.code==1){
                wx.showToast({
                  title: '留言成功',
                })
                  setTimeout(function(){
                    wx.navigateBack({
                      delta: 1
                    })

                  },1500)
            }else{  
              wx.showToast({
                title: '留言失败',
                icon:'none'
              })

            }

        }
      })


  },
  get_area:function(e){
      this.setData({
        area:e.detail.value
      })
  },
  get_phone:function(e){
    this.setData({
      phone: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      // 196
    this.setData({
      id_: options.id
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})