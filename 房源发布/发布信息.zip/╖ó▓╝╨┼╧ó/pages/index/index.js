var app = getApp();
var http = app.globalData.http;
var index_;
var data_obj = {};
Page({

  /**
   * 页面的初始数据
   */
  data: {
    set_txt: '',
    nav_list: [],
    tit: '',
    type_house: false,
    type_zhao: false,
    type_hun: false,
    my_data: [],
    url: http,
    show_sm: false,
    all_nav: [],
    er_nav: 0,
    san_list: [],
    banner_list:[],
    show_login:false,
    phone_show:false
  },
  getPhoneNumber: function (e) {
        wx.showToast({
          title: '请稍等',
        });
        var that=this;
         wx.request({
                    url: http + '/index.php/api/login/get_phone', //仅为示例，并非真实的接口地址
                        data: {
                          sessionKey: wx.getStorageSync('user_obj').session_key,
                          encryptedData: e.detail.encryptedData,
                          iv: e.detail.iv,
                          access_token:wx.getStorageSync('token')
                        },
                        header: {
                          'content-type': 'application/json' // 默认值
                        },
                        success(res) {
                          wx.hideLoading();
                          console.log(res.data)
                          if (res.data.code == 1) {
                                // wx.showToast({
                                //   title: '获取成功',
                                // })
                          }else{
                            // wx.showToast({
                            //   title: '获取失败',
                            //   icon:'none'
                            // });
                          };
                          that.setData({
                            phone_show:false
                          });
                        }
                      })
    console.log(e.detail.errMsg)
    console.log(e.detail.iv)
    console.log(e.detail.encryptedData)
  },
  get_new_data: function (e) {
    var that = this;
    var my_san = that.data.all_nav;
    // console.log(my_san)
    // console.log(index_)
    // console.log(my_san.data[index_]);
    // console.log(e.target.dataset.txt)
  
    
    if (e.target.dataset.txt == '最新发布' || e.target.dataset.txt == '最久发布'){
      if (e.target.dataset.txt == '最新发布'){
        var sx ='id asc';
        }else{
        var sx ='id desc';
          
        }

      that.setData({
        show_sm: false
      })
      wx.showLoading({
        title: '加载中',
      })
      data_obj.orderby=sx;
      data_obj.cid = that.data.n_id;
      wx.request({
        url: http + '/index.php/api/list', //仅为示例，并非真实的接口地址
        header: {
          'content-type': 'application/json' // 默认值
        },
        data: data_obj,
        success: function (res) {
          wx.hideLoading();
          var new_arr = [];
          if (res.data.state == 200) {
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data) {
                new_arr.push(res.data.data[i])
              }
            }
            // that.data.er_nav='';
            that.setData({
              er_nav: ''
            })
            res.data.data = new_arr;



            if (that.data.tit == '二手房') {
              for (var i = 0; i < res.data.data.length; i++) {
                if (res.data.data[i].data.esimages) {
                  res.data.data[i].img = res.data.data[i].data.esimages.split('***')[0]
                }
              }
            } else if (that.data.tit == '投资·新楼盘') {
              for (var i = 0; i < res.data.data.length; i++) {
                if (res.data.data[i].data.ysimages) {
                  res.data.data[i].img = res.data.data[i].data.ysimages.split('***')[0]
                }
              }
            } else if (that.data.tit == '商铺') {
              for (var i = 0; i < res.data.data.length; i++) {
                if (res.data.data[i].data.spimages) {
                  res.data.data[i].img = res.data.data[i].data.spimages.split('***')[0]
                }
              }
            } else if (that.data.tit == '出租') {
              for (var i = 0; i < res.data.data.length; i++) {
                if (res.data.data[i].data.czimages) {
                  res.data.data[i].img = res.data.data[i].data.czimages.split('***')[0]
                }
              }
            } else if (that.data.tit == '婚介') {
              for (var i = 0; i < res.data.data.length; i++) {

                if (res.data.data[i].data.grimage) {
                  res.data.data[i].img = res.data.data[i].data.grimage.split('***')[0]
                }
              }

            }


            for (var i = 0; i < res.data.data.length; i++) {
              res.data.data[i].date = that.formatDateTime(res.data.data[i].create_time);
            }



            that.setData({
              my_data: res.data.data
            })
          }
        }
      })
    return false;


    }else{
      my_san[index_].title = e.target.dataset.txt;
      console.log(my_san)

      that.setData({
        all_nav: my_san
      })
    }








    data_obj[e.target.dataset.key] = e.target.dataset.txt;
    data_obj.cid = that.data.n_id
    console.log(data_obj)
    that.setData({
      show_sm:false
    })
      wx.showLoading({
        title: '加载中',
      })
    wx.request({
      url: http + '/index.php/api/list', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: data_obj,
      success: function (res) {
        wx.hideLoading();
        var new_arr=[];
        if (res.data.state == 200) {
        // that.data.er_nav = '';
          that.setData({
            er_nav:''
          })
          for(var i=0;i<res.data.data.length;i++){
            if (res.data.data[i].data){
              new_arr.push(res.data.data[i])
              }
          }

          res.data.data = new_arr;



          if (that.data.tit == '二手房') {
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data.esimages) {
                res.data.data[i].img = res.data.data[i].data.esimages.split('***')[0]
              }
            }
          } else if (that.data.tit == '投资·新楼盘') {
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data.ysimages) {
                res.data.data[i].img = res.data.data[i].data.ysimages.split('***')[0]
              }
            }
          } else if (that.data.tit == '商铺') {
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data.spimages) {
                res.data.data[i].img = res.data.data[i].data.spimages.split('***')[0]
              }
            }
          } else if (that.data.tit == '出租') {
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data.czimages) {
                res.data.data[i].img = res.data.data[i].data.czimages.split('***')[0]
              }
            }
          } else if (that.data.tit == '婚介') {
            for (var i = 0; i < res.data.data.length; i++) {

              if (res.data.data[i].data.grimage) {
                res.data.data[i].img = res.data.data[i].data.grimage.split('***')[0]
              }
            }

          }


          for (var i = 0; i < res.data.data.length; i++) {
            res.data.data[i].date = that.formatDateTime(res.data.data[i].create_time);
          }



          that.setData({
            my_data: res.data.data
          })
        }
      }
    })












  },
  sel_nav: function (e) {
    var that = this;
    index_ = e.target.dataset.index;
    console.log(index_)
    if (that.data.er_nav == e.target.dataset.cid){
        that.setData({
          show_sm:false,
          er_nav:''
        })
        return false
  }else{
      that.setData({
        er_nav: e.target.dataset.cid,
        show_sm: true
      })

  }



    if (that.data.show_sm == false) {
      return false;
    }
    if (e.target.dataset.cid == 'mo') {
      var bb={
        data: ['最新发布', '最久发布']
      }
      that.setData({
        san_list: bb
      })
      console.log(that.data.san_list)
      
      return false
    }
    wx.request({
      url: http + '/index.php/api/filter', //仅为示例，并非真实的接口地址
      data: {
        cid: that.data.er_nav,
        level: 2
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.code == 1) {
          that.setData({
            san_list: res.data
          })
        }
      }
    })







  },
  formatDateTime: function (timeStamp) {
    var date = new Date();
    date.setTime(timeStamp * 1000);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    var minute = date.getMinutes();
    var second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    return m + '-' + d;
  },

  get_ser: function (e) {
    this.setData({
      set_txt: e.detail.value
    })
  },
  ser_btn: function () {
    var that = this;
    if (that.data.set_txt.length <= 0) {
      wx.showToast({
        title: '请填写搜索内容',
        icon:'none'
      })
      return false;
    }
    wx.navigateTo({
      url: '../list/list?tit=' + that.data.tit + '&id=' + that.data.n_id + '&key=' + that.data.set_txt,

    })



  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    if(wx.getStorageSync('token')){
          that.setData({
            show_login: false
          })
    }else{
      that.setData({
        show_login: true
      })
    }
   
  wx.request({
    url:http+'/index.php/api/banner_list',
    header: {
      'content-type': 'application/json' // 默认值
    },
    success:function(res){
      console.log(res)
      if(res.data.code==1){
          that.setData({
            banner_list:res.data.data
          })
      }
      
    }
  })

    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: http + '/index.php/api/catlist', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        cid: 92,
      },
      success: function (res) {
        console.log(res.data);
        that.setData({
          nav_list: res.data.data,
          n_id: res.data.data[0].id,
          tit: res.data.data[0].title
        })
        // 请求的一个的筛选栏目
        wx.request({
          url: http + '/index.php/api/filter', //仅为示例，并非真实的接口地址
          data: {
            cid: that.data.n_id,
            level: 1
          },
          header: {
            'content-type': 'application/json' // 默认值
          },
          success: function (res) {
            console.log(res.data)
            if (res.data.code == 1) {
              that.setData({
                all_nav: res.data.data
              })
            }
          }
        })


        // 请求的一个的内容数据
        wx.request({
          url: http + '/index.php/api/list', //仅为示例，并非真实的接口地址
          header: {
            'content-type': 'application/json' // 默认值
          },
          data: {
            cid: res.data.data[0].id


            // pages: curr_page,
            // limit: 6
          },
          success: function (res) {
            wx.hideLoading();
            console.log(res.data);
            wx.hideLoading();
            if (res.data.state == 200) {

              if (that.data.tit == '二手房' || that.data.tit == '投资·新楼盘' || that.data.tit == '商铺' || that.data.tit == '出租') {
                that.setData({
                  type_house: true
                })
              } else if (that.data.tit == '招聘') {
                that.setData({
                  type_zhao: true,
                })
              } else if (that.data.tit == '婚介') {
                that.setData({
                  type_hun: true,
                })
              }











              if (that.data.tit == '二手房') {
                console.log(1)
                for (var i = 0; i < res.data.data.length; i++) {
                  if (res.data.data[i].data.esimages) {
                    res.data.data[i].img = res.data.data[i].data.esimages.split('***')[0]
                  }
                }
              } else if (that.data.tit == '投资·新楼盘') {


                for (var i = 0; i < res.data.data.length; i++) {
                  if (res.data.data[i].data.ysimages) {
                    res.data.data[i].img = res.data.data[i].data.ysimages.split('***')[0]
                  }
                }
              } else if (that.data.tit == '商铺') {
                for (var i = 0; i < res.data.data.length; i++) {
                  if (res.data.data[i].data.spimages) {
                    res.data.data[i].img = res.data.data[i].data.spimages.split('***')[0]
                  }
                }
              } else if (that.data.tit == '出租') {
                for (var i = 0; i < res.data.data.length; i++) {
                  if (res.data.data[i].data.czimages) {
                    res.data.data[i].img = res.data.data[i].data.czimages.split('***')[0]
                  }
                }
              } else if (that.data.tit == '婚介') {
                if (res.data.data[i].data.grimage) {
                  res.data.data[i].img = res.data.data[i].data.grimage.split('***')[0]
                }
              }


              for (var i = 0; i < res.data.data.length; i++) {
                res.data.data[i].date = that.formatDateTime(res.data.data[i].create_time);
              }



              that.setData({
                my_data: res.data.data
              })
            }
          }
        })












      }
    });





  },
  login_: function (e) {
    var that = this;
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo']) {
          console.log(11111)
          wx.login({
            success: function (res) {
              if (res.code) {
                wx.showLoading({
                  title: '登陆中',
                });
                var code_ = res.code;
                var nickname_ = e.detail.userInfo.nickName;
                var headimage_ = e.detail.userInfo.avatarUrl;
                var sex_ = e.detail.userInfo.gender;
                wx.request({
                  url: http + '/index.php/api/login/wxlogin', //仅为示例，并非真实的接口地址
                  data: {
                    code: code_,
                    nickname: nickname_,
                    headimage: headimage_,
                    sex: sex_
                  },
                  header: {
                    'content-type': 'application/json' // 默认值
                  },
                  success(res) {
                    wx.hideLoading();
                    console.log(res.data);
                    if (res.data.code == 1) {
                      wx.setStorageSync('user_obj', res.data.data[0].user);
                      wx.setStorageSync('token', res.data.data[0].access_token);
                      that.setData({
                        user_info: wx.getStorageSync('user_obj')
                      });
                      that.setData({
                        phone_show:true,
                        show_login:false
                      });
                      // wx.request({
                      //   url: http + '/index.php/api/member/index', //仅为示例，并非真实的接口地址
                      //   data: {
                      //     access_token: wx.getStorageSync('token')
                      //   },
                      //   header: {
                      //     'content-type': 'application/json' // 默认值
                      //   },
                      //   success(res) {
                      //     console.log(res.data)
                      //     if (res.data.code == 1) {
                      //       that.setData({
                      //         other_info: res.data.data[0]
                      //       })
                      //     }
                      //   }
                      // })
                    } else {
                      wx.showToast({
                        title: '登陆失败',
                        icon: 'none'
                      });
                    }
                  }
                })


              }
            }
          })
        } else {
          console.log(222)
        }
      }
    })

  },
  tog_nav: function (e) {
    var that = this;
     data_obj = {};
 

    index_ = e.target.dataset.index;
    this.setData({
      n_id: e.target.dataset.id,
      tit: e.target.dataset.tit,
      show_sm: false,
      er_nav:''
  
    })

    wx.request({
      url: http + '/index.php/api/filter', //仅为示例，并非真实的接口地址
      data: {
        cid: that.data.n_id,
        level: 1
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.code == 1) {
          that.setData({
            all_nav: res.data.data
          })
        }
      }
    })
    wx.showLoading({
      title: '加载中',
    })

    if (e.target.dataset.tit == '二手房' || e.target.dataset.tit == '投资·新楼盘' || e.target.dataset.tit == '商铺' || e.target.dataset.tit == '出租') {
      that.setData({
        type_house: true,
        type_zhao: false,
        type_hun: false
      })
    } else if (e.target.dataset.tit == '招聘') {
      that.setData({
        type_zhao: true,
        type_house: false,
        type_hun: false
      })
    } else if (e.target.dataset.tit == '婚介') {
      that.setData({
        type_hun: true,
        type_zhao: false,
        type_house: false

      })
    }
    wx.request({
      url: http + '/index.php/api/list', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        cid: e.target.dataset.id,


        // pages: curr_page,
        // limit: 6
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data);
        wx.hideLoading();
        if (res.data.state == 200) {
          if (e.target.dataset.tit == '二手房') {
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data.esimages) {
                res.data.data[i].img = res.data.data[i].data.esimages.split('***')[0]
              }
            }
          } else if (e.target.dataset.tit == '投资·新楼盘') {
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data.ysimages) {
                res.data.data[i].img = res.data.data[i].data.ysimages.split('***')[0]
              }
            }
          } else if (e.target.dataset.tit == '商铺') {
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data.spimages) {
                res.data.data[i].img = res.data.data[i].data.spimages.split('***')[0]
              }
            }
          } else if (e.target.dataset.tit == '出租') {
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data.czimages) {
                res.data.data[i].img = res.data.data[i].data.czimages.split('***')[0]
              }
            }
          } else if (e.target.dataset.tit == '婚介') {
            for (var i = 0; i < res.data.data.length; i++) {

              if (res.data.data[i].data.grimage) {
                res.data.data[i].img = res.data.data[i].data.grimage.split('***')[0]
              }
            }

          }


          for (var i = 0; i < res.data.data.length; i++) {
            res.data.data[i].date = that.formatDateTime(res.data.data[i].create_time);
          }



          that.setData({
            my_data: res.data.data
          })
        }
      }
    })

















  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})