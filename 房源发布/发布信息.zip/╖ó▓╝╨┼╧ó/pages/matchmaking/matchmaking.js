// pages/house_detail/house_detail.js

var app = getApp();
var http = app.globalData.http;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    nub: 0,
    banner_list:[],
    data:{},
    url:http
  },
  bo_: function (e) {
    wx.makePhoneCall({
      phoneNumber: e.target.dataset.phone //仅为示例，并非真实的电话号码
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    that.setData({
      id_: options.id
    })
    wx.request({
      url: http + '/index.php/api/content', //仅为示例，并非真实的接口地址
      data: {
        id: options.id
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data)
        if(res.data.state==200){
          var list_ = res.data.data.grimage.split('***');
          list_.pop();


            that.setData({
              banner_list: list_,
              data:res.data.data
            })
        }
      }
    })



  },
  bindChange: function (e) {
    var that = this;
    that.setData({
      nub: e.detail.current
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  go_message: function () {
    var that = this;
    wx.navigateTo({
      url: '../message/message?id=' + that.data.id_,
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;
    return {
      title: '',
      path: '/pages/matchmaking/matchmaking?id=' + that.data.id_,
    }

  }
})