// pages/list/list.js
  var app = getApp();
  var http = app.globalData.http;
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
      type_house:false,
      type_zhao:false,
      type_hun:false,
      my_data:[],
      url: http,
      tit:''
  },
  formatDateTime: function (timeStamp) {
    var date = new Date();
    date.setTime(timeStamp * 1000);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    var minute = date.getMinutes();
    var second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    return m + '-' + d;
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    wx.setNavigationBarTitle({
      title: options.tit,
    })
    that.setData({
      tit: options.tit
    })
    console.log(options)
    if (options.tit == '二手房' || options.tit == '投资·新楼盘' || options.tit == '商铺' || options.tit == '出租'){
          that.setData({
            type_house:true
          })
    } else if (options.tit =='招聘'){
        that.setData({
          type_zhao: true,
        })
    } else if (options.tit == '婚介'){
      that.setData({
        type_hun: true,
      })
    }
    wx.showLoading({
      title: '搜索中',
    })
    wx.request({
      url: http + '/index.php/api/list', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        cid: options.id,
        keyword: options.key

        // pages: curr_page,
        // limit: 6
      },
      success: function (res) {
        console.log(res.data);
        wx.hideLoading();
        if (res.data.state == 200) {
          if (options.tit == '二手房'){
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data.esimages) {
                res.data.data[i].img = res.data.data[i].data.esimages.split('***')[0]
              }
            }
          } else if (options.tit == '投资·新楼盘'){
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data.ysimages) {
                res.data.data[i].img = res.data.data[i].data.ysimages.split('***')[0]
              }
            }
          } else if (options.tit == '商铺') {
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data.spimages) {
                res.data.data[i].img = res.data.data[i].data.spimages.split('***')[0]
              }
            }
          }else if (options.tit == '出租') {
            for (var i = 0; i < res.data.data.length; i++) {
              if (res.data.data[i].data.czimages) {
                res.data.data[i].img = res.data.data[i].data.czimages.split('***')[0]
              }
            }
          } else if (options.tit == '婚介') {
            for (var i = 0; i < res.data.data.length; i++) {
            if (res.data.data[i].data.grimage) {
              res.data.data[i].img = res.data.data[i].data.grimage.split('***')[0]
              }
            }
          }


          for (var i = 0; i < res.data.data.length; i++) {
            res.data.data[i].date = that.formatDateTime(res.data.data[i].create_time);
          }
         


              that.setData({
                my_data:res.data.data
              })
        }
      }
    })


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})