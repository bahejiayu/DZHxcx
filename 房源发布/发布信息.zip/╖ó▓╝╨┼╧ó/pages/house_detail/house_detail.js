// pages/house_detail/house_detail.js
var app = getApp();
var http = app.globalData.http;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    nub:0,
    data_:{},
    banner_list:[],
    url: http,
    zjy:'',
    btn_txt:'',
    id_:''
  },
  bo_: function (e) {
    wx.makePhoneCall({
      phoneNumber: e.target.dataset.phone //仅为示例，并非真实的电话号码
    })
  },
  t2: function (timeStamp) {
    var date = new Date();
    date.setTime(timeStamp * 1000);
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? ('0' + m) : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    var h = date.getHours();
    h = h < 10 ? ('0' + h) : h;
    var minute = date.getMinutes();
    var second = date.getSeconds();
    minute = minute < 10 ? ('0' + minute) : minute;
    second = second < 10 ? ('0' + second) : second;
    return y + '-' + m + '-' + d;
  },
  go_message:function(){
    var that=this;
      wx.navigateTo({
        url: '../message/message?id=' + that.data.id_,
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  


    var that=this;
      that.setData({
        id_: options.id
      })

    that.setData({
      zjy: options.name
    })
    if (options.type == 1) {
        that.setData({
          btn_txt:'出售登记'
        })
    } else if (options.type == 2){
      that.setData({
        btn_txt:'商铺登记'
      })
    } else if (options.type == 3){
      that.setData({
        btn_txt: '出租登记'
      })
    }
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: http + '/index.php/api/content', //仅为示例，并非真实的接口地址
      data: {
        id: options.id
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        wx.hideLoading();
        if(res.data.state==200){
          if (res.data.data.esimages){
            var list_ = res.data.data.esimages.split('***')
          } else if (res.data.data.ysimages){
            var list_ = res.data.data.ysimages.split('***');
          } else if (res.data.data.spimages){
            var list_ = res.data.data.spimages.split('***');
          } else if (res.data.data.czimages){
            var list_ = res.data.data.czimages.split('***');
            
          }

          
          res.data.data.update_time = that.t2(res.data.data.update_time);
          
          list_.pop()
            that.setData({
              data_:res.data.data,
              banner_list: list_
            })
        
        }

      }
    })

  },
  bindChange: function (e) {
    var that = this;
    that.setData({
      nub: e.detail.current
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that=this;
    return {
      title: '',
      path: '/pages/house_detail/house_detail?id=' + that.data.id_,
      }
  }
})