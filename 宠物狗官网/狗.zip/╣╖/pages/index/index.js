
  var app = getApp()
  var http = app.globalData.http


Page({

  /**
   * 页面的初始数据
   */
  data: {
    show_vi:false,
    banner:[],
    ht: http,
    about_us:{},
    dog_list:{},
    cat_list:{},
    vid:"",
    ping_list:{},
    link:''
  },
  show_video:function(){
      this.setData({
        show_vi:true
      })
  },
  close_vi:function(){
    this.setData({
      show_vi: false
    })
  },
  b1:function(){
    wx.redirectTo({
      url: '../index/index'
    })
  },
  b2: function () {
    wx.makePhoneCall({
      phoneNumber: wx.getStorageSync('phone') //仅为示例，并非真实的电话号码
    })
  },
  b3: function () {
    wx.navigateTo({
      url: '../lx/lx'
    })
  },
  b4: function () {
    wx.navigateTo({
      url: '../concat/concat'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this;

    // wx.chooseVideo({
    //   sourceType: ['album', 'camera'],
    //   maxDuration: 60,
    //   camera: 'back',
    //   success(res) {
    //     console.log(res.tempFilePath);

    //     that.setData({
    //       link: res.tempFilePath
    //     })


    //   }
    // })
    // 获取banner
    wx.request({
      url: http +'/index.php/Api/banner', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
          if(res.data.state==200){
            that.setData({
              banner:res.data.data
            })
          }

      }
    })


      // 获取首页关于我们内容
    wx.request({
      url: http + '/index.php/Api/type', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data:{
        typeid:30
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.state == 200) {
            that.setData({
              about_us:res.data.data
            })
        }

      }
    })

      // 狗
    wx.request({
      url: http + '/index.php/Api/list', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        cid: 20,
        limit:6
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.state == 200) {
            that.setData({
              dog_list:res.data.data
            })
        }

      }
    })


    // 猫
    wx.request({
      url: http + '/index.php/Api/list', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        cid: 81,
        limit: 6
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.state == 200) {
          that.setData({
            cat_list: res.data.data
          })
        }

      }
    })

    wx.request({
      url: http + '/index.php/Api/list', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        cid: 87,
        limit: 6
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.state == 200) {
          that.setData({
            ping_list: res.data.data
          })
        }

      }
    })
    // 请求电话
    wx.request({
      url: http + '/index.php/Api/content', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        id: 195
      
      },
      success: function (res) {
        console.log(res.data)
        if(res.data.state==200){
          wx.setStorageSync('phone', res.data.data.phone);
          that.setData({
            vid: res.data.data.txvid
          })
        }
      }
    })







  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

var that=this;
    // 获取banner
    wx.request({
      url: http + '/index.php/Api/banner', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.state == 200) {
          that.setData({
            banner: res.data.data
          })
        }

      }
    })


    // 获取首页关于我们内容
    wx.request({
      url: http + '/index.php/Api/type', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        typeid: 30
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.state == 200) {
          that.setData({
            about_us: res.data.data
          })
        }

      }
    })



    wx.request({
      url: http + '/index.php/Api/list', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        cid: 87,
        limit: 6
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.state == 200) {
          that.setData({
            ping_list: res.data.data
          })
        }

      }
    })






    // 狗
    wx.request({
      url: http + '/index.php/Api/list', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        cid: 20,
        limit: 6
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.state == 200) {
          that.setData({
            dog_list: res.data.data
          })
        }

      }
    })


    // 猫
    wx.request({
      url: http + '/index.php/Api/list', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        cid: 81,
        limit: 6
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.state == 200) {
          that.setData({
            cat_list: res.data.data
          })
        }

      }
    })

    // 请求电话
    wx.request({
      url: http + '/index.php/Api/content', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data: {
        id: 195

      },
      success: function (res) {
        console.log(res.data)
        if (res.data.state == 200) {
          wx.setStorageSync('phone', res.data.data.phone);
          that.setData({
            vid: res.data.data.txvid
          })
        }
      }
    })




  setTimeout(function(){
    wx.stopPullDownRefresh();
  },1000)











  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})