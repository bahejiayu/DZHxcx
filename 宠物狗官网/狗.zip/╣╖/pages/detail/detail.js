


  var app = getApp()
  var http = app.globalData.http
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    show_vi: false,
    data_info:{},
    ht: http,
    txt:"",
    img_arr:[],
    have_:false
  },
  look_img:function(e){
    var that=this;
    var img_list=[]
    for (var i = 0; i < that.data.img_arr.length;i++){
      img_list[i] = that.data.ht + that.data.img_arr[i]
    }
    wx.previewImage({
      current: e.target.dataset.img, // 当前显示图片的http链接
      urls: img_list // 需要预览的图片http链接列表
    })
  },
  b1: function () {
    wx.redirectTo({
      url: '../index/index'
    })
  },
  b2: function () {
    wx.makePhoneCall({
      phoneNumber: wx.getStorageSync('phone')  //仅为示例，并非真实的电话号码
    })
  },
  b3: function () {
    wx.navigateTo({
      url: '../lx/lx'
    })
  },
  b4: function () {
    wx.navigateTo({
      url: '../concat/concat'
    })
  },
  show_video: function () {
    this.setData({
      show_vi: true
    })
  },
  close_vi: function () {
    this.setData({
      show_vi: false
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    wx.showLoading({
      title: '加载中',
    })

    wx.request({
      url: http + '/index.php/Api/content', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      data:{
        id: options.id
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data)
        if (res.data.state == 200) {
             if (res.data.data.piclist){
               var my_arr = res.data.data.piclist.split("***");   
               var b = my_arr.pop();
               that.setData({
                 img_arr: my_arr
               })
             }
             if (JSON.parse(res.data.data.xcontent).length>0){
              var str = JSON.parse(res.data.data.xcontent)[0].data;
              that.setData({
                txt: str,
              })
            }
             if (res.data.data.txvid != ''){
                  that.setData({
                      have_:true
                  })
               }else{
               that.setData({
                 have_: false
               })
               }
            that.setData({
              data_info: res.data.data,
            })
        }

      }
    })







  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})